#include <jni.h>
#include <android/log.h>
#include <list>
#include <string>
#include "common.h"
#include "bookprocessfactory.h"
#include "dnotebookinfo.h"
#include "notebookinfo.h"
#include "notepage.h"
#include "noteedititem.h"
#include "item.h"

using namespace std;
static INoteBookProcess* process = BookProcessFactory::createNoteBookProcess(
		false);//TODO db close is in process destroy function. make it another function to call.

extern "C" void Java_com_zeleisoft_wifishare_operator_NoteBookOperator_setStorageFilePath(
		JNIEnv *env, jobject thiz, jstring path) {
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "setStorageFilePath");
	char* dbPath = jstringToString(env, path);
	process->setStorageFilePath(string(dbPath));
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "setStorageFilePath %s\n",
			dbPath);
	free(dbPath);
}

extern "C" jobject dNoteBookInfoToJDNoteBookInfo(JNIEnv* env,
		DNoteBookInfo info) {
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/DNoteBookInfo");
	jmethodID methodId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, methodId);
	jmethodID setBookIdMethodId = env->GetMethodID(cls, "setBookId", "(Ljava/lang/String;)V");
	jstring bookid = stringToJString(env, info.getBookId().c_str());
	env->CallVoidMethod(object, setBookIdMethodId, bookid);
	env->DeleteLocalRef(bookid);
	jmethodID setBookNameMethodId = env->GetMethodID(cls, "setBookName", "(Ljava/lang/String;)V");
	jstring bookname = stringToJString(env, info.getBookName().c_str());
	env->CallVoidMethod(object, setBookNameMethodId, bookname);
	env->DeleteLocalRef(bookname);
	jmethodID setWidthMethodId = env->GetMethodID(cls, "setWidth", "(I)V");
	env->CallVoidMethod(object, setWidthMethodId, info.getWidth());
	jmethodID setHeightMethodId = env->GetMethodID(cls, "setHeight", "(I)V");
	env->CallVoidMethod(object, setHeightMethodId, info.getHeight());
	if(info.getCover()!=NULL){
		jmethodID setCoverMethodId = env->GetMethodID(cls, "setCover", "([BI)V");
		jbyteArray byteArray = stringToJByteArray(env, info.getCover(), info.getCvSize());
		env->CallVoidMethod(object, setCoverMethodId, byteArray, info.getCvSize());
		env->DeleteLocalRef(byteArray);
	}
	if(info.getBackground() != NULL){
		jmethodID setBackgroundMethodId = env->GetMethodID(cls, "setBackground", "([BI)V");
		jbyteArray byteArray = stringToJByteArray(env, info.getBackground(), info.getBgSize());
		env->CallVoidMethod(object ,setBackgroundMethodId, byteArray, info.getBgSize());
		env->DeleteLocalRef(byteArray);
	}
	env->DeleteLocalRef(cls);
	return object;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_NoteBookOperator_getDNoteBookInfo(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "id %s\n",
			id);
	DNoteBookInfo* info = process->getDNoteBookInfo(string(id));

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "info %s\n",
			info->toString().c_str());
	jobject jinfo = dNoteBookInfoToJDNoteBookInfo(env, *info);
	delete info;
	info = NULL;
	free(id);
	return jinfo;
}
extern "C" jobject noteBookInfoToJNoteBookInfo(JNIEnv* env, NoteBookInfo info) {
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/NoteBookInfo");
	jmethodID methodId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, methodId);
	jmethodID setBookIdMethodId = env->GetMethodID(cls, "setBookId", "(Ljava/lang/String;)V");
	jstring bookid = stringToJString(env, info.getBookId().c_str());
	env->CallVoidMethod(object, setBookIdMethodId, bookid);
	env->DeleteLocalRef(bookid);
	jmethodID setBookNameMethodId = env->GetMethodID(cls, "setBookName", "(Ljava/lang/String;)V");
	jstring bookname = stringToJString(env, info.getBookName().c_str());
	env->CallVoidMethod(object, setBookNameMethodId, bookname);
	env->DeleteLocalRef(bookname);
	if(info.getThumb()!=NULL){
		jmethodID setThumbMethodId = env->GetMethodID(cls, "setThumb", "([BI)V");
		jbyteArray byteArray = stringToJByteArray(env, info.getThumb(), info.getThumbSize());
		env->CallVoidMethod(object, setThumbMethodId, byteArray, info.getThumbSize());
		env->DeleteLocalRef(byteArray);
	}
	env->DeleteLocalRef(cls);
	return object;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_NoteBookOperator_getNoteBookInfoList(
		JNIEnv* env, jobject thiz) {
	list<NoteBookInfo*> infoList = process->getNoteBookInfoList();

	jclass cls = env->FindClass("java/util/ArrayList");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject jlist = env->NewObject(cls, metholdId);
	jmethodID addMethodId = env->GetMethodID(cls, "add",
			"(Ljava/lang/Object;)Z");

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "notebookinfo list size %d\n",
			infoList.size());
	for (list<NoteBookInfo*>::iterator it = infoList.begin(); it != infoList.end(); it++) {
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "notebookinfo %s\n",
				(*it)->toString().c_str());
		jobject noteBookInfo = noteBookInfoToJNoteBookInfo(env, *(*it));
		env->CallBooleanMethod(jlist, addMethodId,
				noteBookInfo);
		env->DeleteLocalRef(noteBookInfo);
	}

	env->DeleteLocalRef(cls);

	for (list<NoteBookInfo*>::iterator it = infoList.begin(); it != infoList.end(); ) {
			list<NoteBookInfo*>::iterator it2 = it;
			it++;
			delete *it2;
	}
	infoList.clear();

	return jlist;
}
extern "C" jint Java_com_zeleisoft_wifishare_operator_NoteBookOperator_getLocalMaxOprId(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	int maxId = process->getLocalMaxOprId(string(id));
	free(id);
	return maxId;
}

extern "C" jobject noteEditItemToJNoteEditItem(JNIEnv* env, NoteEditItem item){

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "noteEditItemToJNoteEditItem \n");
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/NoteEditItem");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);
	jmethodID setOprIdMethodId = env->GetMethodID(cls, "setOprId", "(I)V");
	env->CallVoidMethod(object, setOprIdMethodId, item.getOprId());
	jmethodID setPageIdMethodId = env->GetMethodID(cls, "setPageId","(I)V");
	env->CallVoidMethod(object, setPageIdMethodId, item.getPageId());
	jmethodID setEditItemMethodId = env->GetMethodID(cls, "setEditItem", "(Lcom/zeleisoft/wifishare/operator/EditItem;)V");
	jobject editItem = editItemToJEditItem(env, item);
	env->CallVoidMethod(object, setEditItemMethodId, editItem);
	env->DeleteLocalRef(cls);
	env->DeleteLocalRef(editItem);
	return object;
}
extern "C" jobject notePageToJNotePage(JNIEnv* env, NotePage page) {

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "notePageToJNotePage \n");

	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/NotePage");
	jmethodID methodId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, methodId);
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before  setNotePageId\n");
	jmethodID setNotePageIdMethodId = env->GetMethodID(cls, "setNotePageId", "(I)V");
	env->CallVoidMethod(object, setNotePageIdMethodId, page.getNotePageId());
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "after  setNotePageId\n");

	jmethodID addItemMethodId = env->GetMethodID(cls, "addItem", "(Lcom/zeleisoft/wifishare/operator/Item;)V");
	list<Item*> items = page.getItems();
	for(list<Item*>::iterator it = items.begin(); it != items.end(); it++){
		if((*it)==NULL){
			__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "*it null\n");
		}else{
			__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "*it not null\n");
		}
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before dynamic_cast %p\n", (*it));

		NoteEditItem* item = dynamic_cast<NoteEditItem*>(*it);
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before CallVoidMethod \n");
		jobject editItem = noteEditItemToJNoteEditItem(env, *item);
		env->CallVoidMethod(object, addItemMethodId, editItem);
		env->DeleteLocalRef(editItem);

	}

	env->DeleteLocalRef(cls);
	return object;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_NoteBookOperator_getNotePageList(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	list<NotePage*> pageList = process->getNotePageList(string(id));

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "pageList  size %d\n",
			pageList.size());
	jclass cls = env->FindClass("java/util/ArrayList");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject jlist = env->NewObject(cls, metholdId);
	jmethodID addMethodId = env->GetMethodID(cls, "add",
			"(Ljava/lang/Object;)Z");

	for (list<NotePage*>::iterator it = pageList.begin(); it != pageList.end(); it++) {
		jobject notepage = notePageToJNotePage(env, *(*it));
		env->CallBooleanMethod(jlist, addMethodId, notepage);
		env->DeleteLocalRef(notepage);
	}

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "after add all NotePage \n");


	env->DeleteLocalRef(cls);
	free(id);
/*
	for (list<NotePage*>::iterator it = pageList.begin(); it != pageList.end(); ) {
		list<NotePage*>::iterator it2 = it;
		it++;
		delete *it2;//TODO Program received signal SIGSEGV, Segmentation fault.From  ~NotePage delete it2.
	}
	pageList.clear();
*/
	return jlist;
}

extern "C" jboolean Java_com_zeleisoft_wifishare_operator_NoteBookOperator_syncNoteBook(
		JNIEnv* env, jobject thiz, jstring username, jstring useragent,
		jstring bookid, int width, int height) {
	char* name = jstringToString(env, username);
	char* agent = jstringToString(env, useragent);
	char* id = jstringToString(env, bookid);
	bool result = process->syncNoteBook(string(name),
			string(agent), string(id), width, height);
	free(name);
	free(agent);
	free(id);
	return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" jboolean Java_com_zeleisoft_wifishare_operator_NoteBookOperator_syncAllNoteBook(
		JNIEnv* env, jobject thiz, jstring username, jstring useragent,
		int width, int height) {
	char* name = jstringToString(env, username);
	char* agent = jstringToString(env, useragent);
	bool result = process->syncAllNoteBook(string(name), string(agent), width,
			height);
	free(name);
	free(agent);
	return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" void Java_com_zeleisoft_wifishare_operator_NoteBookOperator_closeDB(JNIEnv* env, jobject thiz){
	process->closeDB();
}
