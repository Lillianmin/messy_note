#ifndef BOOKINFO_H
#define BOOKINFO_H

#include <string>

using namespace std;

class BookInfo{
public:
	BookInfo();
	BookInfo(const BookInfo&);
	virtual ~BookInfo();
	void setBookId(string bookid);
	string getBookId() const;
	void setBookName(string bookname);
	string getBookName() const;
	virtual string toString();
private:
	string bookId;
	string bookName;
};
#endif
