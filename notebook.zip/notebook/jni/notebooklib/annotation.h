#ifndef ANNOTATION_H
#define ANNOTATION_H

#include <string>
#include <stdio.h>
#include "item.h"
using namespace std;

enum AnnotationType{
	TEXT,
	HANDWRITE
};

class Annotation : public Item{
public:
	Annotation();
	virtual ~Annotation();

	void setPartId(int id);
	int getPartId() const;

	void setStartPos(int pos);
	int getStartPos() const;

	void setEndPos(int pos);
	int getEndPos() const;

	void setQuote(string);
	string getQuote() const;

	void setAnnotationType(AnnotationType type);
	AnnotationType getAnnotationType() const;
	
	virtual string toString();

private:
    int partId;
    int startPos;
    int endPos;
    string quote;
    AnnotationType annotationType;
};

#endif // Annotation_h
