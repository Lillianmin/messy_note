#ifndef TRACK_H
#define TRACK_H

#include <list>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

struct Point{
	Point()
	{
		x = 0;
		y = 0;
	}
	Point(const Point& p)
	{
		x = p.x;
		y = p.y;
	}
	~Point()
	{
	}
	int x;
	int y;
	string toString(){
		char s[128]; 
		memset(s, 0, 128); 
		sprintf(s, " x: %d y:%d\t ", x, y);
		return string(s);
	}
};

class EditItem;

class Track {
public:
	Track();
	Track(const Track&);
	~Track();

    void setPenWidth(int w);
    int getPenWidth() const;

    void addPoint(Point p);
	void addPoints(list<Point*> pointList);
	void addPoints(list<Point> pointList);
    list<Point> getPoints() const;
	string toString();
	void clear();

private:
    int penWidth;
    list<Point> points;
};
#endif
