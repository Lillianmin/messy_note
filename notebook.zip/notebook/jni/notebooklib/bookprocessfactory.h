#ifndef BOOKPROCESSFACTORY_H
#define BOOKPROCESSFACTORY_H
#include "interface/inotebookprocess.h"
#include "interface/snotebookprocess.h"
#include "interface/notebookprocess.h"
#include "interface/ibookcommentprocess.h"
#include "interface/bookcommentprocess.h"

class BookProcessFactory{
	public:
		BookProcessFactory(){
		};
		~BookProcessFactory(){
		};

		static INoteBookProcess* createNoteBookProcess(bool simulation){
			if(simulation){
				return new SNoteBookProcess();
			}else{
				return new NoteBookProcess();
			}
		};
	
		static IBookCommentProcess* createBookCommentProcess(){
				return new BookCommentProcess();
		}


};
#endif
