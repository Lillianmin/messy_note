#!/bin/sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../thirdpart/tinyxml2:../thirdpart/curl/install/lib:../thirdpart/libb64/src:../sqlitewrapper/lib:../thirdpart/sqlite/install/lib:$LD_LIBRARY_PATH
