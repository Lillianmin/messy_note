#ifndef DBOOKINFO_H
#define DBOOKINFO_H
#include "bookinfo.h"
class DBookInfo : public BookInfo{
public:
	DBookInfo();
	DBookInfo(const DBookInfo&);
	virtual ~DBookInfo();
	void setWidth(int w);
	int getWidth() const;
	void setHeight(int h);
	int getHeight() const;
	virtual string toString();
private:
	int width;
	int height;
};
#endif
