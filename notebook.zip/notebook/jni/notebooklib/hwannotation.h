#ifndef HWANNOTATION_H
#define HWANNOTATION_H

#include <list>

#include "annotation.h"
#include "edititem.h"

using namespace std;
class HWAnnotation : public Annotation, public EditItem {
public:
	HWAnnotation();
	HWAnnotation(const HWAnnotation&);
	HWAnnotation(const Annotation&);
	~HWAnnotation();
	void setEditItem(const EditItem&);
	string toString();
};

#endif
