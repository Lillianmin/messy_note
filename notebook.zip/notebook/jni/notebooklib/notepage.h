#ifndef NOTEPAGE_H
#define NOTEPAGE_H

#include <list>
#include <string>
#include "item.h"
#include "noteedititem.h"
using namespace std;

class NotePage {
public:
	NotePage(int id);
	NotePage(const NotePage&);
	~NotePage();

    void addItem(Item *item);
	void addItemList(list<Item*> itemList);
	void addItemList(list<NoteEditItem*> itemList);
    list<Item*> getItems() const;

	
    void setNotePageId(int id);
    int getNotePageId() const;
	string toString();
private:
    int notePageId;
    list<Item*> items;
};
#endif
