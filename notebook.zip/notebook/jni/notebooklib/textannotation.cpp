#include "textannotation.h"
#include <stdlib.h>
#include <string.h>
#include <iostream>
TextAnnotation::TextAnnotation()
{
	setAnnotationType(TEXT);
	comment = "";
}
TextAnnotation::TextAnnotation(const TextAnnotation& annotation){
	setAnnotationType(TEXT);
	comment = "";
	setOprId(annotation.getOprId());	
	setPartId(annotation.getPartId());
	setStartPos(annotation.getStartPos());
	setEndPos(annotation.getEndPos());
	setQuote(annotation.getQuote());
	setComment(annotation.getComment());

}
TextAnnotation::TextAnnotation(const Annotation& annotation)
{
	setAnnotationType(TEXT);
	comment = "";
	setOprId(annotation.getOprId());	
	setPartId(annotation.getPartId());
	setStartPos(annotation.getStartPos());
	setEndPos(annotation.getEndPos());
	setQuote(annotation.getQuote());
}


TextAnnotation::~TextAnnotation()
{
}

void TextAnnotation::setComment(string comm)
{
	comment = comm;
}

string TextAnnotation::getComment() const
{
	return comment;
}

string TextAnnotation::toString(){
	char s[1024]; 
	memset(s, 0, 1024); 
	sprintf(s, "%s\t %s\t comment: %s\n", __FILE__, Annotation::toString().c_str(), comment.c_str());
	return s;
	string str;
	str.append(__FILE__);
	str.append(Annotation::toString());
	str.append("\t");
	str.append(comment);
	str.append("\n");
	return str;
}
