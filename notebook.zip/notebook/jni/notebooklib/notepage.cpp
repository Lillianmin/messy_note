#include "notepage.h"
#include "item.h"
#include <iostream>
NotePage::NotePage(int id)
{
	notePageId = id;
}
NotePage::NotePage(const NotePage& page)
{
	setNotePageId(page.getNotePageId());
	addItemList(page.getItems());	
}

NotePage::~NotePage()
{
	for(list<Item*>::iterator it = items.begin(); it != items.end(); ){
		list<Item*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	items.clear();
}

void NotePage::addItem(Item *item)
{
	items.push_back(item);
}

void NotePage::addItemList(list<Item*> itemList){
	for(list<Item*>::iterator it = itemList.begin(); it != itemList.end(); it++){
		items.push_back(*it);
	}
}

void NotePage::addItemList(list<NoteEditItem*> itemList){
	for(list<NoteEditItem*>::iterator it = itemList.begin(); it != itemList.end(); it++){
		items.push_back(*it);
	}
}
list<Item*> NotePage::getItems() const
{
	return items;
}

void NotePage::setNotePageId(int id)
{
	notePageId = id;
}

int NotePage::getNotePageId() const
{
    return notePageId;
}

string NotePage::toString(){
	char s[128];
	memset(s, 0 , 128);
	sprintf(s, "%s\t%s\t%d", __FILE__, __FUNCTION__, notePageId);
	string str;
	str = " pageId " + string(s) +  "\n";
/*	for(list<Item*>::iterator it = items.begin(); it != items.end(); it++){
		str.append((*it)->toString());
	}*/
	return str;
}
