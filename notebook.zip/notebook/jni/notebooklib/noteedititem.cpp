#include "noteedititem.h"
#include <stdlib.h>
#include <iostream>
NoteEditItem::NoteEditItem(){
	pageId = 0;
}
NoteEditItem::NoteEditItem(const NoteEditItem& item){
	pageId = 0;
	setOprId(item.getOprId());
	setPageId(item.getPageId());
	setEditType(item.getEditType());
	list<Track> tracks = item.getTracks();
	list<Track>::iterator trackIt;
	trackIt = tracks.begin();
	while(trackIt != tracks.end()){
		addTrack(*trackIt);
		trackIt++;
	}

}
NoteEditItem::NoteEditItem(const EditItem& item){
	setEditType(item.getEditType());
	list<Track> tracks = item.getTracks();
	list<Track>::iterator trackIt;
	trackIt = tracks.begin();
	while(trackIt != tracks.end()){
		addTrack(*trackIt);
		trackIt++;
	}
}

NoteEditItem::~NoteEditItem(){
}
void NoteEditItem::setPageId(int pid){
	pageId = pid;
}
int NoteEditItem::getPageId() const{
	return pageId;
}

string NoteEditItem::toString(){
	char s[128]; 
	memset(s, 0, 128); 
	sprintf(s, "\tpageId: %d\t", pageId);
	string str;
	str.append(__FILE__);
	str.append("\t");
	str.append(s);	
	str.append("\t");
	str.append(Item::toString());
	str.append("\t");
	str.append(EditItem::toString());
	str.append("\n");
	return str;
}
