#ifndef IBOOKCOMMENTPROCESS_H
#define IBOOKCOMMENTPROCESS_H

#include <string>
#include <list>
#include "../dbookinfo.h" 
#include "../bookinfo.h"  
#include "../annotation.h"
using namespace std;
class IBookCommentProcess{
public:
	virtual ~IBookCommentProcess(){};
	virtual void setStorageFilePath(string path) = 0;
	virtual void addDBookInfo(DBookInfo* info)=0;
	virtual DBookInfo* getDBookInfo(string bookid)=0;
	virtual list<BookInfo*> getBookInfoList()=0;
	virtual int getLocalMaxOprId(string bookid)=0;
	virtual void saveAnnotation(string bookid, Annotation* annotation)=0;
	virtual list<Annotation*> getPartAnnotationList(string bookid, int partid)=0;
	virtual list<Annotation*> getAnnotationList(string bookid)=0;
	virtual bool syncBookComment(string username, string useragent, string bookid, int width, int height)=0;
	virtual bool syncAllBookComment(string username, string useragent, int width, int height)=0;
	virtual void closeDB(){};	
};
#endif
