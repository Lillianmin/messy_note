#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../dnotebookinfo.h"
#include "snotebookprocess.h"
#include "sqlitewrapper.h"
#include "../noteedititem.h"
#include "../track.h"

#define BUF_SIZE 128
SNoteBookProcess::SNoteBookProcess(){
}

SNoteBookProcess::~SNoteBookProcess(){

}
void SNoteBookProcess::setStorageFilePath(string path){
	storageFilePath = path;
	SQLiteWrapper db;		
	db.open(storageFilePath);
	
	std::string sql;
	sql = "CREATE TABLE notebook(id INTEGER PRIMARY key AUTOINCREMENT, notebookid TEXT UNIQUE, notebookname TEXT , background BLOB, cover BLOB, pagewidth INTEGER, pageheight INTEGER);";
	if(getenv("ZLS_DEBUG") != NULL)
		fprintf(stderr, "SNoteBookProcess::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);

	sql = "CREATE TABLE notepage(id INTEGER PRIMARY key AUTOINCREMENT, notebook_idx INTEGER NOT NULL REFERENCES notebook(id), pageid INTEGER);";
	if(getenv("ZLS_DEBUG") != NULL)
		fprintf(stderr, "SNoteBookProcess::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);

	sql = "CREATE TABLE edititem(id INTEGER PRIMARY key AUTOINCREMENT, notepage_idx INTEGER NOT NULL REFERENCES notepage(id), opr_idx INTEGER, edittype INTEGER);";
	if(getenv("ZLS_DEBUG") != NULL)
		fprintf(stderr, "SNoteBookProcess::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);

	sql = "CREATE TABLE track(id INTEGER PRIMARY key AUTOINCREMENT, edititem_idx INTEGER NOT NULL REFERENCES edititem(id),  penwidth INTEGER);";
	if(getenv("ZLS_DEBUG") != NULL)
		fprintf(stderr, "SNoteBookProcess::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);
	sql = "CREATE TABLE point(id INTEGER PRIMARY key AUTOINCREMENT, track_idx INTEGER NOT NULL REFERENCES  track(id), pointx INTEGER, pointy INTEGER);";
	if(getenv("ZLS_DEBUG") != NULL)
		fprintf(stderr, "SNoteBookProcess::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);

	db.close();
}
void SNoteBookProcess::addDNoteBookInfo(DNoteBookInfo* info){
	SQLiteWrapper db;		
	db.open(storageFilePath);
	
	string sql = "select id from notebook where notebookid=\"" + info->getBookId() + "\";";
	ResultList idlist = db.executeQuery(sql);
	if(idlist.size() != 0){
		sql = "update notebook set cover=\"";
		sql.append(info->getCover());
		sql += "\" where notebookid = \"" + info->getBookId() + "\"";
		db.executeUpdate(sql);
		db.close();
		return;
	}

	sql = "insert into notebook(notebookid, notebookname) values(\"" + info->getBookId() + "\",\"" + info->getBookName() + "\")";
	fprintf(stderr, "%s----\tsql=%s", __func__, sql.c_str());
	db.executeUpdate(sql);
	db.close();
}
DNoteBookInfo* SNoteBookProcess::getDNoteBookInfo(string id){
	DNoteBookInfo *dinfo = new DNoteBookInfo();
	dinfo->setBookId(id);
	return dinfo;
}
void SNoteBookProcess::addNotePage(string bookid, int pid){
	SQLiteWrapper db;
	db.open(storageFilePath);

	string sql = "select id from notebook where notebookid=\"" + bookid + "\";";
	fprintf(stderr, "%s ---%s\n", __func__,sql.c_str());
	ResultList bookidList = db.executeQuery(sql);
	string bookIdxStr;//notebook index
	if(bookidList.size() != 0){
		ResultList::iterator it = bookidList.begin();
		FieldsMap fm = *it;
		FieldsMap::iterator fit = fm.begin();
		if(fit->first == "id")
			bookIdxStr = fit->second;
	}

	char pidStr[BUF_SIZE];
	memset(pidStr, 0, BUF_SIZE);
	sprintf(pidStr, "%d", pid);
	sql = "select id from notepage where pageid=" + string(pidStr) + ";";
	ResultList pidList = db.executeQuery(sql);
	if(pidList.size() != 0){
		fprintf(stderr, "exists, no need add page");
		db.close();
		return;
	}
	
	sql = "insert into notepage(notebook_idx, pageid) values(\"" + bookIdxStr + "\"," + pidStr + ");";
	fprintf(stderr, "%s", sql.c_str());
	db.executeUpdate(sql);
	db.close();
}

list<NoteBookInfo*> SNoteBookProcess::getNoteBookInfoList(){
	list<NoteBookInfo*> bookInfoList;
	SQLiteWrapper db;
	db.open(storageFilePath);
	string sql = "select * from notebook";
	ResultList bookList = db.executeQuery(sql);
	if(bookList.size() == 0){
		db.close();
		return bookInfoList;
	}
	for(ResultList::iterator bookit = bookList.begin(); bookit != bookList.end(); bookit++){
		FieldsMap infofm = (*bookit);
		NoteBookInfo *info = new NoteBookInfo();
		for(FieldsMap::iterator infoit = infofm.begin(); infoit != infofm.end(); infoit++){
			if(infoit->first == "notebookid")
				info->setBookId(infoit->second);
			else if(infoit->first == "notebookname")
				info->setBookName(infoit->second);
		}
		bookInfoList.push_back(info);
	}
	fprintf(stderr, "%s------%d\n", __func__, bookInfoList.size());
	db.close();
	return bookInfoList;
}

list<NotePage*> SNoteBookProcess::getNotePageList(string bookid){
	list<NotePage*> notePageList;
	NotePage *page = new NotePage(0);
	NoteEditItem *item = new NoteEditItem();
	item->setEditType(WRITE);
	Track track;
	track.setPenWidth(4);
	SQLiteWrapper db;
	db.open(storageFilePath);
	string sql = "select * from point";	
	ResultList pointList = db.executeQuery(sql);

	for(ResultList::iterator pit = pointList.begin(); pit != pointList.end(); pit++){
		FieldsMap fm = *pit;
		Point p;
		for(FieldsMap::iterator fmit = fm.begin(); fmit != fm.end(); fmit++){
			if(fmit->first == "pointx"){
				p.x = static_cast<int>(strtol(fmit->second.c_str(), NULL, 10));
			}else if(fmit->first == "pointy"){
				p.y = static_cast<int>(strtol(fmit->second.c_str(), NULL, 10));
			}
		}
		track.addPoint(p);
	}
	item->addTrack(track);
	page->addItem(item);
	notePageList.push_back(page);
	return notePageList;
}

NotePage* SNoteBookProcess::getNotePage(string bookid, int pageid){
	NotePage* notePage = new NotePage(pageid);
	return notePage;
}
void SNoteBookProcess::saveNoteEditItem(string bookid, NoteEditItem *item){
	cout <<__FILE__<<"\t" <<__func__<<"\nbookid="<<bookid.c_str()<<"\npageid="<<item->getPageId()<<"\nitem->getTracks()="<<item->getTracks().size()<<"\nitem->oprId="<<item->getOprId()<<endl;

	list<Track> trackList = item->getTracks();
	if(trackList.size() <= 0)
		return;

	SQLiteWrapper db;		
	db.open(storageFilePath);
	char oprStr[BUF_SIZE];
	memset(oprStr, 0, BUF_SIZE);
	fprintf(stderr, "oprStr.size=%d\n", strlen(oprStr));
	sprintf(oprStr, "%d", item->getOprId());
	fprintf(stderr, "oprStr.size=%d\n", strlen(oprStr));
	char typeStr[BUF_SIZE];
	memset(typeStr, 0, BUF_SIZE);
	sprintf(typeStr, "%d", item->getEditType());

	string sql = "select id from notepage where notebook_idx in (select id from notebook where notebookid=\"" + bookid + "\")";
	string pageIdxStr;
	ResultList pageList = db.executeQuery(sql);
	if(pageList.size() == 0){
		db.close();
		return;
	}
	FieldsMap pagefm = *(pageList.begin());
	FieldsMap::iterator pagefmit = pagefm.begin();
	if(pagefmit->first == "id")
		pageIdxStr = pagefmit->second;

	sql = "insert into edititem(notepage_idx, opr_idx, edittype) values(" + pageIdxStr + "," +string(oprStr) + "," + string(typeStr) + ");";
	fprintf(stderr, "::%s sql=%s\n", __func__, sql.c_str());
	db.executeUpdate(sql);
	sql = "select id from edititem where opr_idx=" + string(oprStr) + ";";
	fprintf(stderr, "::%s sql=%s\n", __func__, sql.c_str());
	ResultList oprList = db.executeQuery(sql);
	FieldsMap oprfm = *(oprList.begin());
	FieldsMap::iterator oprfmit = oprfm.begin();

	string idStr;
	if(oprfmit->first == "id")
		idStr = oprfmit->second;
	for(list<Track>::iterator trackIt = trackList.begin(); trackIt != trackList.end(); trackIt++){
		char penStr[BUF_SIZE];
		memset(penStr, 0, BUF_SIZE);
		sprintf(penStr, "%d", (*trackIt).getPenWidth());
		sql = "insert into track(edititem_idx, penwidth) values(" + idStr + "," + string(penStr) +");";
		fprintf(stderr, "::%s sql=%s\n", __func__, sql.c_str());
		db.executeUpdate(sql);

		sql = "select id from track where edititem_idx=" + idStr +";";
		fprintf(stderr, "::%s sql=%s\n", __func__, sql.c_str());
		ResultList trIdList = db.executeQuery(sql);
		FieldsMap trfm = *(trIdList.begin());
		FieldsMap::iterator trfmit = trfm.begin();

		string trackIdx;
		if(trfmit->first == "id")
			trackIdx = trfmit->second;
		list<Point> pointList = (*trackIt).getPoints();
		for(list<Point>::iterator pit = pointList.begin(); pit != pointList.end(); pit++){

			char xStr[BUF_SIZE];
			memset(xStr, 0, BUF_SIZE);
			sprintf(xStr, "%d", (*pit).x);

			char yStr[BUF_SIZE];
			memset(yStr, 0, BUF_SIZE);
			sprintf(yStr, "%d", (*pit).y);

			sql = "insert into point(track_idx, pointx, pointy) values(" + trackIdx + "," + string(xStr) + "," + string(yStr) + ");";
			fprintf(stderr, "::%s sql=%s\n", __func__, sql.c_str());
			db.executeUpdate(sql);
		}
	}
	db.close();
}

bool SNoteBookProcess::syncNoteBook(string username, string useragent, string bookid, int width, int height){
	return true;
}

bool SNoteBookProcess::syncAllNoteBook(string username, string useragent, int width, int height){
	return true;
}
#if 0
list<Point> SNoteBookProcess::getPoint()
{
	list<Point> points;
	SQLiteWrapper db;
	db.open(storageFilePath);
	string sql = "select * from point";	
	ResultList pointList = db.executeQuery(sql);

	for(ResultList::iterator pit = pointList.begin(); pit != pointList.end(); pit++){
		FieldsMap fm = *pit;
		Point p;
		for(FieldsMap::iterator fmit = fm.begin(); fmit != fm.end(); fmit++){
			if(fmit->first == "pointx"){
				p.x = static_cast<int>(strtol(fmit->second.c_str(), NULL, 10));
			}else if(fmit->first == "pointy"){
				p.y = static_cast<int>(strtol(fmit->second.c_str(), NULL, 10));
			}
		}
		points.push_back(p);
	}
	fprintf(stderr, "func=%s----point size=%d\n", __func__, points.size());
	return points;
}
#endif
int SNoteBookProcess::getLocalMaxOprId(string id){
	SQLiteWrapper db;
	db.open(storageFilePath);
	string sql = "select max(opr_idx) AS maxId from edititem";
	ResultList oprList = db.executeQuery(sql);
	if(oprList.size() == 0){
		db.close();
		return 0;
	}
	FieldsMap fm = *(oprList.begin());
	string oprStr;
	for(FieldsMap::iterator it = fm.begin(); it != fm.end(); it++){
		if(it->first == "maxId")
			oprStr = it->second;
	}
	return static_cast<int>(strtol(oprStr.c_str(), NULL, 10));
}
