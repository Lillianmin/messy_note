#ifndef BOOKCOMMENTPROCESS_H
#define BOOKCOMMENTPROCESS_H

#include "ibookcommentprocess.h"
#include "../dataprocess/bookcommentdb.h"

class BookCommentProcess : public IBookCommentProcess {
public:
	BookCommentProcess();
	~BookCommentProcess();
	void setStorageFilePath(string path);
	void addDBookInfo(DBookInfo* info);
	DBookInfo* getDBookInfo(string bookid);
	list<BookInfo*> getBookInfoList();
	int getLocalMaxOprId(string bookid);
	void saveAnnotation(string bookid, Annotation* annotation);
	list<Annotation*> getPartAnnotationList(string bookid, int partid);
	list<Annotation*> getAnnotationList(string bookid);
	bool syncBookComment(string username, string useragent, string bookid, int width, int height);
	bool syncAllBookComment(string username, string useragent, int width, int height);
	void closeDB();
private:
	BookCommentDB* db;
};
#endif
