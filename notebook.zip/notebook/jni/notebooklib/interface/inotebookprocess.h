#ifndef INoteBookProcess_H
#define INoteBookProcess_H

#include "../notebookinfo.h"
#include "../dnotebookinfo.h"
#include "../notepage.h"

#include <list>

using namespace std;

class NoteEditItem;
class INoteBookProcess{
	public:
		virtual ~INoteBookProcess() {};
		virtual void setStorageFilePath(string path) = 0;
		virtual void addDNoteBookInfo(DNoteBookInfo *) = 0;
		virtual DNoteBookInfo* getDNoteBookInfo(string id) = 0;
		virtual void addNotePage(string, int) = 0;
		virtual list<NoteBookInfo*> getNoteBookInfoList() = 0;
		virtual int getLocalMaxOprId(string bookid) = 0;
		virtual list<NotePage*> getNotePageList(string bookid) = 0;
		virtual NotePage* getNotePage(string bookid, int pageid) = 0;
		virtual void saveNoteEditItem(string bookid, NoteEditItem *item) = 0;
		virtual bool syncNoteBook(string username, string useragent, string bookid, int width, int height) = 0;
		virtual bool syncAllNoteBook(string username, string useragent, int width, int height) = 0;
		virtual void closeDB(){};	
};

#endif
