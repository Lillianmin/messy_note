#ifndef NOTEBOOKPROCESS_H
#define NOTEBOOKPROCESS_H

#include "inotebookprocess.h"
#include "../dataprocess/notebookdb.h"
class NoteBookProcess : public INoteBookProcess {
public:
	NoteBookProcess();
	~NoteBookProcess();
	void setStorageFilePath(string path);
	void addDNoteBookInfo(DNoteBookInfo*);
	DNoteBookInfo* getDNoteBookInfo(string id);
	void addNotePage(string, int);
	list<NoteBookInfo*> getNoteBookInfoList();
	int getLocalMaxOprId(string bookid);
	list<NotePage*> getNotePageList(string bookid);
	NotePage* getNotePage(string bookid, int pageid);
	void saveNoteEditItem(string bookid, NoteEditItem *item);
	bool syncNoteBook(string username, string useragent, string bookid, int width, int height);
	bool syncAllNoteBook(string username, string useragent, int width, int height);
	void closeDB();
private:
	NoteBookDB* db;
};
#endif
