#ifndef SNOTEBOOKPROCESS_H
#define SNOTEBOOKPROCESS_H

#include "notebookprocess.h"

class SNoteBookProcess : public INoteBookProcess {
public:
	SNoteBookProcess();
	~SNoteBookProcess();
	void setStorageFilePath(string path);
	void addDNoteBookInfo(DNoteBookInfo* bookInfo);
	DNoteBookInfo* getDNoteBookInfo(string id);
	void addNotePage(string, int);
	list<NoteBookInfo*> getNoteBookInfoList();
	int getLocalMaxOprId(string bookid);
	list<NotePage*> getNotePageList(string bookid);
	NotePage* getNotePage(string bookid, int pageid);
	void saveNoteEditItem(string bookid, NoteEditItem *item);
	bool syncNoteBook(string username, string useragent, string bookid, int width, int heigth);
	bool syncAllNoteBook(string username, string useragent, int width, int height);
private:
	string storageFilePath;
};
#endif
