#include "bookcommentprocess.h"

BookCommentProcess::BookCommentProcess(){
}
BookCommentProcess::~BookCommentProcess(){
	delete db;
	db = NULL;

}
void BookCommentProcess::setStorageFilePath(string path){
	db = new BookCommentDB(path);
}

void BookCommentProcess::addDBookInfo(DBookInfo* info){
	db->addDBookInfo(info);
}
DBookInfo* BookCommentProcess::getDBookInfo(string bookid){
	return db->getDBookInfo(bookid);
}
list<BookInfo*> BookCommentProcess::getBookInfoList(){
	return db->getBookInfoList();
}
int BookCommentProcess::getLocalMaxOprId(string bookid){
	return db->getLocalMaxOprId(bookid);
}
void BookCommentProcess::saveAnnotation(string bookid, Annotation* annotation){
	db->saveAnnotation(bookid, annotation);
}
list<Annotation*> BookCommentProcess::getPartAnnotationList(string bookid, int partid){
	return db->getPartAnnotationList(bookid, partid);
}
list<Annotation*> BookCommentProcess::getAnnotationList(string bookid){
	return db->getAnnotationList(bookid);
}
bool BookCommentProcess::syncBookComment(string username, string useragent, string bookid, int width, int height){
	return false;
}
bool BookCommentProcess::syncAllBookComment(string username, string useragent, int width, int height){
	return false;
}

void BookCommentProcess::closeDB(){
	db->closeDB();
}
