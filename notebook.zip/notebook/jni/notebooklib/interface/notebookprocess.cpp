#include "notebookprocess.h"
#include "../noteedititem.h"
NoteBookProcess::NoteBookProcess(){

}

NoteBookProcess::~NoteBookProcess(){
	delete db;
	db = NULL;
}

void NoteBookProcess::setStorageFilePath(string path)
{
	db = new NoteBookDB(path);
}

void NoteBookProcess::addDNoteBookInfo(DNoteBookInfo* dInfo){
	db->addDNoteBookInfo(dInfo);
}

DNoteBookInfo* NoteBookProcess::getDNoteBookInfo(string id){
	return db->getDNoteBookInfo(id);
}

void NoteBookProcess::addNotePage(string bookid, int pageid){
	db->addNotePage(bookid, pageid);
}

list<NoteBookInfo*> NoteBookProcess::getNoteBookInfoList(){
	return db->getNoteBookInfoList();
}

int NoteBookProcess::getLocalMaxOprId(string bookid){
	return db->getLocalMaxOprId(bookid);
}

list<NotePage*> NoteBookProcess::getNotePageList(string bookid){
	return db->getNotePageList(bookid);
}
NotePage* NoteBookProcess::getNotePage(string bookid, int pageid){
	return db->getNotePage(bookid, pageid);
}

void NoteBookProcess::saveNoteEditItem(string bookid, NoteEditItem *item){
	db->saveNoteEditItem(bookid, item);
}

bool NoteBookProcess::syncNoteBook(string username, string useragent, string bookid, int width, int height){
	return true;
}

bool NoteBookProcess::syncAllNoteBook(string username, string useragent, int width, int height){
	return true;
}
void NoteBookProcess::closeDB(){
	db->closeDB();
}
