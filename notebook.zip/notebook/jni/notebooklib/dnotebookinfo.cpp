#include "dnotebookinfo.h"
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <stdio.h>
DNoteBookInfo::DNoteBookInfo(){
	cover = NULL;
	background = NULL;
	bgSize = 0;
	cvSize = 0;
}
DNoteBookInfo::DNoteBookInfo(const DNoteBookInfo& dInfo) {
	cover = NULL;
	background = NULL;
	bgSize = 0;
	cvSize = 0;
	setBookId(dInfo.getBookId());
	setBookName(dInfo.getBookName());
	setWidth(dInfo.getWidth());
	setHeight(dInfo.getHeight());
	setCover(dInfo.getCover(), dInfo.getCvSize());
	setBackground(dInfo.getBackground(), dInfo.getBgSize());
}

DNoteBookInfo::DNoteBookInfo(const DBookInfo& dInfo){
	cover = NULL;
	background = NULL;
	bgSize = 0;
	cvSize = 0;
	setBookId(dInfo.getBookId());
	setBookName(dInfo.getBookName());
	setWidth(dInfo.getWidth());
	setHeight(dInfo.getHeight());
}
DNoteBookInfo::~DNoteBookInfo(){
	cout << __FUNCTION__ << endl;
	if(cover!=NULL){
		delete [] cover;
		cover = NULL;
	}
	if(background!=NULL){
		delete [] background;
		background = NULL;
	}
}
void DNoteBookInfo::setCover(const char* cv, int size){
	fprintf(stderr, "func=%s cv=%s size=%d\n", __FUNCTION__, cv, size);
	if(cover!=NULL){
		delete [] cover;
		cover = NULL;
	}
	if(cv==NULL)
		return;
	cover = new char[size+1];
	memset(cover, 0, size+1);
	memcpy(cover, cv, size);
	cover[size]='\0';
	cvSize = size;
}
char* DNoteBookInfo::getCover() const{
	return cover;
}
int DNoteBookInfo::getCvSize() const {
	return cvSize;
}
void DNoteBookInfo::setBackground(const char* bg, int size){
	fprintf(stderr, "func=%s bg=%s size=%d\n", __FUNCTION__, bg, size);
	if(background != NULL){
		delete [] background;
		background = NULL;
	}
	if(bg==NULL)
		return;
	background = new char[size+1];
	memset(background, 0, size+1);
	memcpy(background, bg, size);
	background[size]='\0';
	bgSize = size;
}
char* DNoteBookInfo::getBackground() const{
	return background;
}
int DNoteBookInfo::getBgSize() const
{
	return bgSize;
}

string DNoteBookInfo::toString(){
	string str;
	str.append(__FILE__);
	str.append(DBookInfo::toString());
	
	str.append("\tcover:\t");
	str.append(cover==NULL?"NULL":cover);
	str.append("\tbackground:\t ");
	str.append(background==NULL?"NULL":background);
	str.append("\n");
	return str;
}
