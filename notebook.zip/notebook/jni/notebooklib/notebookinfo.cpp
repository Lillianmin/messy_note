#include "notebookinfo.h"
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
NoteBookInfo::NoteBookInfo(){
	thumb = NULL;
	thumbSize = 0;
}
NoteBookInfo::NoteBookInfo(const NoteBookInfo& bookInfo){
	thumb = NULL;
	thumbSize = 0;
	setBookId(bookInfo.getBookId());
	setBookName(bookInfo.getBookName());
	setThumb(bookInfo.getThumb(), bookInfo.getThumbSize());
}

NoteBookInfo::NoteBookInfo(const BookInfo& bookInfo){
	thumb = NULL;
	thumbSize = 0;
	setBookId(bookInfo.getBookId());
	setBookName(bookInfo.getBookName());
}
NoteBookInfo::~NoteBookInfo(){
	cout << __FUNCTION__ << endl;
	if(thumb != NULL){
		delete [] thumb;
		thumb = NULL;
	}
}
void NoteBookInfo::setThumb(const char* tb, int size){
	if(thumb!=NULL){
		delete [] thumb;
		thumb=NULL;
	}
	if(tb==NULL)
		return;
	thumb = new char[size+1];
	memset(thumb, 0, size+1);
	memcpy(thumb, tb, size);
	thumb[size]='\0';
	thumbSize = size;
}
char* NoteBookInfo::getThumb() const{
	return thumb;
}
int NoteBookInfo::getThumbSize() const {
	return thumbSize;
}
string NoteBookInfo::toString(){
	string str;
	str.append(__FILE__);
	str.append("\t");
	str.append(BookInfo::toString());
	str.append("\t");
	str.append("thumb: ");
	str.append(thumb==NULL?"NULL":thumb);
	str.append("\n");
	return str;
}
