#include "edititem.h"
#include <string.h>
EditItem::EditItem()
{
	editType = WRITE;
}

EditItem::EditItem(const EditItem& item)
{
	editType = WRITE;
	setEditType(item.getEditType());
	addTracks(item.getTracks());
}
EditItem::~EditItem()
{
}

void EditItem::setEditType(EditType type)
{
	editType = type;
}

void EditItem::addTrack(Track track)
{
	tracks.push_back(track);
}
void EditItem::addTracks(list<Track*> trackList){
	for(list<Track*>::iterator it = trackList.begin(); it!=trackList.end(); it++){
		tracks.push_back(*(*it));
	}
}
void EditItem::addTracks(list<Track> trackList){
	for(list<Track>::iterator it = trackList.begin(); it!=trackList.end(); it++){
		tracks.push_back(*it);
	}
}
list<Track> EditItem::getTracks() const
{
	return tracks;
}

EditType EditItem::getEditType() const
{
	return editType;
}

void EditItem::clear()
{
	tracks.clear();
}
string EditItem::toString(){
	string str;
	char s[1024]; 
	memset(s,0,1024);
        sprintf(s, "\t editType:%d\t", (int)editType);
	str.append(s);
	list<Track>::iterator trackIt;
        trackIt = tracks.begin();
        while(trackIt!=tracks.end()){
		str.append((*trackIt).toString());
		str.append("\t");
                trackIt++;
        }
	str.append("\n");
        return str;
}
