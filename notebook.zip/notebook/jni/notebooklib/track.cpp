#include "track.h"
Track::Track()
{
	penWidth = 0;
}

Track::Track(const Track& track)
{
	penWidth = 0;
	setPenWidth(track.getPenWidth());
	addPoints(track.getPoints());
}

Track::~Track()
{
}

void Track::setPenWidth(int w)
{
	penWidth = w;
}

int Track::getPenWidth() const
{
    return penWidth;
}

void Track::addPoint(Point p)
{
	points.push_back(p);
}
void Track::addPoints(list<Point*> pointList){
	for(list<Point*>::iterator it = pointList.begin(); it!=pointList.end(); it++){
		points.push_back(*(*it));
	}
}
void Track::addPoints(list<Point> pointList){
	for(list<Point>::iterator it = pointList.begin(); it!=pointList.end(); it++){
		points.push_back(*it);
	}
}
list<Point> Track::getPoints() const
{
	return points;
}
string Track::toString(){
	string str;
	char s[128]; 
	memset(s, 0, 128); 
	sprintf(s, "\tpendWidth: %d\t", penWidth);
	str.append(s);
	list<Point>::iterator pointIt;
        pointIt = points.begin();
        while(pointIt!=points.end()){
                str.append((*pointIt).toString());
                str.append("\t");
                pointIt++;
        }
        str.append("\n");
	return str;
}
void Track::clear()
{
	points.clear();
}
