#ifndef NOTEBOOKINFO_H
#define NOTEBOOKINFO_H
#include "bookinfo.h"
class NoteBookInfo : public BookInfo{
public:
	NoteBookInfo();
	NoteBookInfo(const NoteBookInfo&);
	NoteBookInfo(const BookInfo&);
	~NoteBookInfo();
	void setThumb(const char* tb, int size);
	char* getThumb() const ;
	int getThumbSize() const ;
	string toString();
private:
	char* thumb;
	int thumbSize;
};
#endif
