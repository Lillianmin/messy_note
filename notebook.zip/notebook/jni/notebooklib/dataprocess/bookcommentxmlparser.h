#ifndef BOOKCOMMENTXMLPARSER_H
#define BOOKCOMMENTXMLPARSER_H
#include "bookxmlparser.h"
#include <list>
#include "../annotation.h"
#include "../textannotation.h"
#include "../hwannotation.h"

using namespace std;

class BookCommentXMLParser : public BookXMLParser{
public:
	BookCommentXMLParser();
	~BookCommentXMLParser();
	void parse();
	list<Annotation*> getAnnotations();
private:
	TextAnnotation* parseTextComment(XMLElement* element);
	HWAnnotation* parseTrackComment(XMLElement* element);
	Annotation* parseBaseComment(XMLElement* element);
	list<Annotation*> annotations;
};
#endif
