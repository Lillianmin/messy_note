#ifndef NOTEBOOKINFOXMLCREATOR_H
#define NOTEBOOKINFOXMLCREATOR_H
#include "tinyxml2.h"
#include "../notebookinfo.h"
#include "bookinfoxmlcreator.h"
using namespace tinyxml2;

class NoteBookInfoXMLCreator : public BookInfoXMLCreator{
public:
	NoteBookInfoXMLCreator(const char* root = "notebook");
	~NoteBookInfoXMLCreator();
	XMLElement* addBookInfo(BookInfo* bookInfo);
};
#endif
