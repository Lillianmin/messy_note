#!/bin/sh
curl -H UserName:mll -A linux -F width=480 -F file=@/home/mll/data/notebook/notebooklib/test_notebookxmlcreator.xml http://192.168.4.246 -o post_return.out
