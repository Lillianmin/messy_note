#include "bookcommentxmlcreator.h"
#include <iostream>
BookCommentXMLCreator::BookCommentXMLCreator(string root): BookXMLCreator(root){
}
BookCommentXMLCreator::~BookCommentXMLCreator(){
}
XMLElement* BookCommentXMLCreator::addComments(list<Annotation*> annotations){
	XMLElement* commentsElement = addChild(getRoot(), "comments");
	list<Annotation*>::iterator annotationIt;
	annotationIt = annotations.begin();
	while(annotationIt!=annotations.end()){
		addComment(commentsElement, *annotationIt);
		annotationIt++;
	}
	return commentsElement;
}
XMLElement* BookCommentXMLCreator::addComment(XMLElement* parent, Annotation* annotation){
	XMLElement* element = NULL;
	switch(annotation->getAnnotationType()){
		case TEXT:
			element = addChild(parent, "text_comment");
			addTextAnnotation(element, dynamic_cast<TextAnnotation*>(annotation));
			break;	
		case HANDWRITE:
			element = addChild(parent, "track_comment");
			addHWAnnotation(element, dynamic_cast<HWAnnotation*>(annotation));
			break;
		default:
			break;
	}
	return element;
}

XMLElement* BookCommentXMLCreator::addAnnotation(XMLElement* parent, Annotation* annotation){
	addChildText(parent, "opr_idx", annotation->getOprId());
	addChildText(parent, "partid", annotation->getPartId());
	addChildText(parent, "startpos", annotation->getStartPos());
	addChildText(parent, "endpos", annotation->getEndPos());
	addChildText(parent, "quote", annotation->getQuote().c_str());
	return parent;
}
XMLElement* BookCommentXMLCreator::addTextAnnotation(XMLElement* parent, TextAnnotation* textAnnotation){
	addAnnotation(parent, textAnnotation);
	addChildText(parent, "comment", textAnnotation->getComment().c_str());
	return parent;
}
XMLElement* BookCommentXMLCreator::addHWAnnotation(XMLElement* parent, HWAnnotation* hwAnnotation){
	addAnnotation(parent, hwAnnotation);
	addEditItem(parent, hwAnnotation);
	return parent;
}
