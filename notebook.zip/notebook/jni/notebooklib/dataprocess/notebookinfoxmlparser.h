#ifndef NOTEBOOKINFOXMLPARSER_H
#define NOTEBOOKINFOXMLPARSER_H

#include "tinyxml2.h"

#include "bookinfoxmlparser.h"
#include "../notebookinfo.h"
using namespace tinyxml2;

class NoteBookInfoXMLParser : public BookInfoXMLParser{
public:
	NoteBookInfoXMLParser();
	~NoteBookInfoXMLParser();
	BookInfo* parseBookInfo(XMLElement* bookElement);
};
#endif
