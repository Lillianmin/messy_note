#ifndef NOTEBOOKXMLCREATOR_H
#define NOTEBOOKXMLCREATOR_H

#include "bookxmlcreator.h"

#include "../dnotebookinfo.h"
#include "../noteedititem.h"
class NoteBookXMLCreator : public BookXMLCreator{
public:
	NoteBookXMLCreator(string root = "notebook");
	~NoteBookXMLCreator();
	XMLElement* addDNoteBookInfo(DNoteBookInfo dNoteBookInfo);
	XMLElement* addEditItem(NoteEditItem editItem);
	void addEditItems(list<NoteEditItem*> editItems);
};
#endif
