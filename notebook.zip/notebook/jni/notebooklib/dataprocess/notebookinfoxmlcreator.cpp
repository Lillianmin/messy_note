#include "notebookinfoxmlcreator.h"
#include <iostream>
#include "base64.h"
NoteBookInfoXMLCreator::NoteBookInfoXMLCreator(const char* root):BookInfoXMLCreator(root){
}

NoteBookInfoXMLCreator::~NoteBookInfoXMLCreator(){

}

XMLElement* NoteBookInfoXMLCreator::addBookInfo(BookInfo* bookInfo){
	XMLElement* bookElement = BookInfoXMLCreator::addBookInfo(bookInfo);
	NoteBookInfo* noteBookInfo = dynamic_cast<NoteBookInfo*>(bookInfo);
	cout << __FUNCTION__ <<  " bookInfo getThumb " << noteBookInfo->getThumb() << endl;
	const char* thumb = noteBookInfo->getThumb();
	addChildText(bookElement, "thumb", thumb);
	return bookElement;
}

