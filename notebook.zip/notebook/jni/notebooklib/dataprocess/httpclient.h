#ifndef HTTPCLIENT_H
#define HTTPCLIENT_H

#include <string>

#include "curl/curl.h"

using namespace std;

typedef size_t(*WriteCallback)(char*,size_t, size_t, void*);

class HttpClient{
public:
	HttpClient();
	~HttpClient();
	void addHeader(string name, string value);
	void setUserAgent(string ua);
	void formAddContent(string name, string content);
	void formAddFile(string name, string path);
	void formAddFileStream(const char* fieldname, const char* filename, const char* data, long size);
	void formAddFileStream(const char* filename, const char* data, long size);
	bool doPost(string url, string caPath, WriteCallback wc, void* data);
//	virtual size_t writeCallback(char *buffer, size_t size, size_t nmemb, void *data);
//	virtual size_t headerCallback(char* buffer, size_t size, size_t nitems, void *data);
	static size_t writeCallback(char *buffer, size_t size, size_t nmemb, void *data);
	static size_t headerCallback(char* buffer, size_t size, size_t nitems, void *data);
	long getResponseCode();
	string getResponseHeader();
private:
	struct curl_slist *headers;
	struct curl_httppost* post;
	struct curl_httppost* last;
	string userAgent;
	long responseCode;
	string headerData;
};
#endif
