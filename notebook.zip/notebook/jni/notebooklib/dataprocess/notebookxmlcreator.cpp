#include "notebookxmlcreator.h"
NoteBookXMLCreator::NoteBookXMLCreator(string root): BookXMLCreator(root){
}
NoteBookXMLCreator::~NoteBookXMLCreator(){
}
XMLElement* NoteBookXMLCreator::addDNoteBookInfo(DNoteBookInfo dNoteBookInfo){
	XMLElement* bookElement = BookXMLCreator::addDBookInfo(getRoot(), dNoteBookInfo);
	const char* cover = dNoteBookInfo.getCover();
	const char* background = dNoteBookInfo.getBackground();
	addChildText(bookElement, "cover", cover);
	addChildText(bookElement, "background", background);
	return bookElement;
}
XMLElement* NoteBookXMLCreator::addEditItem(NoteEditItem editItem){
	XMLElement* editItemElement = BookXMLCreator::addEditItem(getRoot(), &editItem);
	addFirstChildText(editItemElement, "opr_idx", editItem.getOprId());
	addFirstChildText(editItemElement, "pageid", editItem.getPageId());
	return editItemElement;
}
void NoteBookXMLCreator::addEditItems(list<NoteEditItem*> editItems){
	list<NoteEditItem*>::iterator itemIt;
	itemIt  = editItems.begin();
	while(itemIt!=editItems.end()){
		addEditItem(**itemIt);
		itemIt++;
	}
}
