#include "basedb.h"
#include <stdio.h>
#include <iostream>
#include <string.h>

#include "sqlite3.h"

#define BUF_SIZE 128
BaseDB::BaseDB(string path){
	cout << __FILE__ << "\t" << __FUNCTION__ << endl;
	db.open(path);
	dbPath = path;
}

BaseDB::~BaseDB(){
}

void BaseDB::closeDB(){
        db.close();
}
void BaseDB::updateBLOB(const char* sql, const char* blob, int len){
        db.close();
	//sql="insert into book(cover) values (?);"
	int ret;
	sqlite3 *pdb;
	sqlite3_stmt* stmt = 0;
	const char* error= 0;
	ret = sqlite3_open_v2(dbPath.c_str(), &pdb, SQLITE_OPEN_READWRITE, NULL);
	if(ret != SQLITE_OK){
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
		sqlite3_close(pdb);
		return;
	}
	ret = sqlite3_prepare_v2(pdb, sql, -1, &stmt, &error);
	if(ret != SQLITE_OK){
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
		sqlite3_close(pdb);
		return;
	}
	cout << __FUNCTION__ << " len " <<  len << endl;
	ret = sqlite3_bind_blob(stmt, 1, blob, len,  SQLITE_TRANSIENT);
	//ret = sqlite3_bind_blob(stmt, 1, blob, len,  SQLITE_STATIC);
	ret = sqlite3_step(stmt);
//	printHex(blob, len);
	if(ret != SQLITE_DONE){
		cout << __FUNCTION__ << " step error " << ret << endl;
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
	}
	sqlite3_finalize(stmt);
	sqlite3_close(pdb);
	db.open(dbPath);
}

void BaseDB::getBLOB(const char* sql, char** blob, int* len){
	//sql = "select cover from book;"
	db.close();	
	int ret;
	sqlite3* pdb;
	sqlite3_stmt* stmt = 0;
	const char* error = 0;
	ret = sqlite3_open_v2(dbPath.c_str(), &pdb, SQLITE_OPEN_READWRITE, NULL);
	if(ret != SQLITE_OK){
		sqlite3_close(pdb);
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
		return;
		
	}

	ret = sqlite3_prepare_v2(pdb, sql, -1, &stmt, &error);
	if(ret != SQLITE_OK){
		sqlite3_close(pdb);
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
		return;
	}
	ret = sqlite3_step(stmt);
	if(ret==SQLITE_ROW){
		char* result = (char*)sqlite3_column_blob(stmt, 0);
		*len = sqlite3_column_bytes(stmt, 0);
		*blob = new char[(*len)+1];
		memset(*blob, 0, *len);
		memcpy(*blob, result, *len);
		(*blob)[*len]='\0';
		cout << __FUNCTION__ << " len " << *len << endl;
	}else{
		cout << __FUNCTION__ << " step error " << ret << endl;
		cout << "ERROR : " << sqlite3_errmsg(pdb) << endl;
	}
//	printHex(*blob, *len);
	sqlite3_finalize(stmt);
	sqlite3_close(pdb);
	db.open(dbPath);
}

void BaseDB::printHex(char* data, int len){
	cout << __FUNCTION__ << endl;
	for(int i = 0 ; i < len; i++){
		printf("%2hhx \t", data[i]);
	}
	printf("\n");
}
void BaseDB::saveTracks(int editIdx, list<Track> trackList){
	char editIdxStr[BUF_SIZE];
	memset(editIdxStr, 0, BUF_SIZE);
	sprintf(editIdxStr, "%d", editIdx);
	for(list<Track>::iterator trackIt = trackList.begin(); trackIt != trackList.end(); trackIt++){
		char penStr[BUF_SIZE];
		memset(penStr, 0, BUF_SIZE);
		sprintf(penStr, "%d", (*trackIt).getPenWidth());
		string sql = "insert into track(edititem_idx, penwidth) values(" + string(editIdxStr) + "," + string(penStr) +");";
			cout << __FUNCTION__ << " sql " << sql << endl;
		db.executeUpdate(sql);

		sql = "select max(id) as maxId  from track where edititem_idx=" + string(editIdxStr) +";";
		cout << __FUNCTION__ << " sql " << sql << endl;
		ResultList trIdList = db.executeQuery(sql);
		FieldsMap trfm = *(trIdList.begin());
		FieldsMap::iterator trfmit = trfm.begin();
		string trackIdx;
		if(trfmit->first == "maxId")
			trackIdx = trfmit->second;
//		cout <<__FUNCTION__<< " trackIdx  " << trackIdx << endl;

		list<Point> pointList = (*trackIt).getPoints();
		for(list<Point>::iterator pit = pointList.begin(); pit != pointList.end(); pit++){

			char xStr[BUF_SIZE];
			memset(xStr, 0, BUF_SIZE);
			sprintf(xStr, "%d", (*pit).x);

			char yStr[BUF_SIZE];
			memset(yStr, 0, BUF_SIZE);
			sprintf(yStr, "%d", (*pit).y);

			sql = "insert into point(track_idx, pointx, pointy) values(" + trackIdx + "," + string(xStr) + "," + string(yStr) + ");";
			cout << __FUNCTION__ << " sql " << sql << endl;
			db.executeUpdate(sql);
		}
	}
}


list<Track*> BaseDB::getTracks(int itemIdx){
        list<Track*> trackList;
        char itemIdxStr[BUF_SIZE];
        memset(itemIdxStr, 0, BUF_SIZE);
        sprintf(itemIdxStr, "%d", itemIdx);

        string sql = "select * from track where edititem_idx="+string(itemIdxStr)+";";
        ResultList resultList = db.executeQuery(sql);
        for(ResultList::iterator it = resultList.begin(); it!=resultList.end(); it++){
                Track* track = new Track();
                for(FieldsMap::iterator fit = it->begin(); fit != it->end(); fit++){
                        if(fit->first=="penwidth"){
                                string penWidthStr = fit->second;
                                int penWidth = static_cast<int>(strtol(penWidthStr.c_str(), NULL, 10));
                                track->setPenWidth(penWidth);
                        }
                        if(fit->first=="id"){
                                string trackIdStr = fit->second;
                                int trackId = static_cast<int>(strtol(trackIdStr.c_str(), NULL, 10));
				list<Point*> points = getPoints(trackId);
                                track->addPoints(points);
				for(list<Point*>::iterator it = points.begin(); it != points.end(); ){
					list<Point*>::iterator it2 = it;
					it++;
					delete *it2;
				}
				points.clear();
                        }

                }
                trackList.push_back(track);
        }
        return trackList;
}
list<Point*> BaseDB::getPoints(int trackIdx){
        list<Point*> pointList;
        char trackIdxStr[BUF_SIZE];
	memset(trackIdxStr, 0, BUF_SIZE);
	sprintf(trackIdxStr, "%d", trackIdx);
        string sql = "select * from point where track_idx="+string(trackIdxStr)+";";
        ResultList resultList = db.executeQuery(sql);
        for(ResultList::iterator it = resultList.begin(); it!=resultList.end();it++){
                Point* point = new Point();
                for(FieldsMap::iterator fit = it->begin(); fit != it->end(); fit++){
                        if(fit->first=="pointx"){
                                string pointXStr = fit->second;
                                int pointX = static_cast<int>(strtol(pointXStr.c_str(), NULL, 10));
                                point->x = pointX;
                        }
                        if(fit->first=="pointy"){
                                string pointYStr = fit->second;
                                int pointY = static_cast<int>(strtol(pointYStr.c_str(), NULL, 10));
                                point->y = pointY;
                        }
                }
                pointList.push_back(point);
        }
        return pointList;
}

int BaseDB::str2Int(string str){
	return static_cast<int>(strtol(str.c_str(), NULL, 10));
}
