#include "base64.h"
#include <stdlib.h>
#include <string.h>
#include <iostream>
extern "C"{
#include "b64/cencode.h"
#include "b64/cdecode.h"
}

Base64::Base64(){
}
Base64::~Base64(){
}
void Base64::encode(char* input, int isize, char* output, int* osize){
        int cnt = 0;
	int count = 0;
        base64_encodestate s;
        base64_init_encodestate(&s);
        cnt = base64_encode_block(input, isize, output, &s);
        count += cnt;
	output += cnt;
        cnt = base64_encode_blockend(output, &s);
	count += cnt;
        output += cnt;
	*osize  = count;
        *output = 0;
}
void Base64::decode(char* input, int isize, char* output, int* osize){
        int cnt = 0;
        base64_decodestate s;
        base64_init_decodestate(&s);
        cnt = base64_decode_block(input, isize, output, &s);
	*osize = cnt;
        output += cnt;
        *output = 0;
}
