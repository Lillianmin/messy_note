#ifndef BOOKCOMMENTXMLCREATOR_H
#define BOOKCOMMENTXMLCRATOR_H
#include <string>
#include "bookxmlcreator.h"

#include "../annotation.h"
#include "../textannotation.h"
#include "../hwannotation.h"

using namespace std;
class BookCommentXMLCreator : public BookXMLCreator{
public:
	BookCommentXMLCreator(string root = "bookcomment");
	~BookCommentXMLCreator();
	XMLElement* addComments(list<Annotation*> annotations);
private:
	XMLElement* addComment(XMLElement* parent, Annotation* annotation);
	XMLElement* addAnnotation(XMLElement* parent, Annotation* annotation);
	XMLElement* addTextAnnotation(XMLElement* parent, TextAnnotation* textAnnotation);
	XMLElement* addHWAnnotation(XMLElement* parent, HWAnnotation* hwAnnotation);
};
#endif
