#include "notebookxmlparser.h"
#include "../dbookinfo.h"
#include "../edititem.h"
#include <iostream>
NoteBookXMLParser::NoteBookXMLParser(){
}
NoteBookXMLParser::~NoteBookXMLParser(){

	delete dNoteBookInfo;
	dNoteBookInfo = NULL;

	for(list<NoteEditItem*>::iterator it = noteEditItems.begin(); it != noteEditItems.end();){
		list<NoteEditItem*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	noteEditItems.clear();
	
}
void NoteBookXMLParser::parse(){
	XMLElement* bookElement = getChildElement(getRootElement(), "book");
	parseDNoteBookInfo(bookElement);
	cout << __FUNCTION__ << "after parseDNoteBookInfo " << endl;
	XMLElement* editItemElement = getChildElement(getRootElement(), "edititem");
	while(editItemElement != NULL){
		NoteEditItem* item = parseNoteEditItem(editItemElement);
		noteEditItems.push_back(item);
		editItemElement=getNextElement(editItemElement, "edititem");
	}
}
DNoteBookInfo* NoteBookXMLParser::parseDNoteBookInfo(XMLElement* element){
	dNoteBookInfo = new DNoteBookInfo(*parseDBookInfo(element));
	const char* cover = getChildText(element, "cover");
	if(cover!=NULL){
		dNoteBookInfo->setCover(cover, strlen(cover));
	}
	const char* background = getChildText(element, "background");
	if(background != NULL){
		dNoteBookInfo->setBackground(background, strlen(background));
	}
	return dNoteBookInfo;
}
NoteEditItem* NoteBookXMLParser::parseNoteEditItem(XMLElement* element){
	EditItem* item = parseEditItem(element);
	NoteEditItem* noteEditItem = new NoteEditItem(*item);
	delete item;
	item = NULL;
	int oprId;
	getChildInt(element, "opr_idx", &oprId);
	noteEditItem->setOprId(oprId);
	int pageId;
	getChildInt(element, "pageid", &pageId);
	noteEditItem->setPageId(pageId);
	return noteEditItem;
}

DNoteBookInfo* NoteBookXMLParser::getDNoteBookInfo(){
	return dNoteBookInfo;
}
list<NoteEditItem*> NoteBookXMLParser::getNoteEditItems(){
	return noteEditItems;
}


