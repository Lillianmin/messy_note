#include "bookxmlcreator.h"

BookXMLCreator::BookXMLCreator(string root){
	rootElement = addRoot(root.c_str());
}
BookXMLCreator::~BookXMLCreator(){
}
XMLElement* BookXMLCreator::getRoot(){
	return rootElement;
}
XMLElement* BookXMLCreator::addDBookInfo(XMLElement* parent, DBookInfo dBookInfo){
	XMLElement* bookElement = addChild(parent, "book"); 
	addChildText(bookElement, "bookid", dBookInfo.getBookId().c_str());
	addChildText(bookElement, "bookname", dBookInfo.getBookName().c_str());
	addChildText(bookElement, "width", dBookInfo.getWidth());
	addChildText(bookElement, "height", dBookInfo.getHeight());
	return bookElement;
}
XMLElement* BookXMLCreator::addEditItem(XMLElement* parent, EditItem* editItem){
	XMLElement* editItemElement = addChild(parent, "edititem");
	addChildText(editItemElement, "opr_type", editItem->getEditType());
	list<Track> tracks = editItem->getTracks();
	list<Track>::iterator trackIt;
	trackIt = tracks.begin();
	while(trackIt!=tracks.end()){
		Track track = *trackIt;
		addTrack(editItemElement, track);
		trackIt++;
	}
	return editItemElement;
}
XMLElement* BookXMLCreator::addTrack(XMLElement* parent, Track track){
	XMLElement* trackElement = addChild(parent, "track");
	addChildText(trackElement, "penwidth", track.getPenWidth());
	XMLElement* pointsElement = addChild(trackElement, "points");
	list<Point> points = track.getPoints();
	list<Point>::iterator pointIt;
	pointIt = points.begin();
	while(pointIt!=points.end()){
		Point point = *pointIt;
		addPoint(pointsElement, point);
		pointIt++;
	}
	return trackElement;
}

XMLElement* BookXMLCreator::addPoint(XMLElement* parent, Point point){
	XMLElement* pointElement = addChild(parent, "point");
	addAttribute(pointElement, "x", point.x);
	addAttribute(pointElement, "y", point.y);
	return pointElement;
}
