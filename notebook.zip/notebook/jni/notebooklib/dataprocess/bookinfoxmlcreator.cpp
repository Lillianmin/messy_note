#include "bookinfoxmlcreator.h"

#include <iostream>
#include "../notebookinfo.h"
BookInfoXMLCreator::BookInfoXMLCreator(const char* root){
	cout << __FILE__ << " " << __FUNCTION__ << endl;
	rootElement = addRoot(root);
	booksElement = addChild(rootElement, "books");
}

BookInfoXMLCreator::~BookInfoXMLCreator(){
}

XMLElement* BookInfoXMLCreator::addBookInfo(BookInfo* bookInfo){
	XMLElement* bookElement = addChild(booksElement, "book");
	XMLElement* bookIdElement = addChild(bookElement, "bookid");
	bookIdElement->SetText(bookInfo->getBookId().c_str());
	XMLElement* bookNameElement = addChild(bookElement, "bookname");
	bookNameElement->SetText(bookInfo->getBookName().c_str());
	return bookElement;
}
void BookInfoXMLCreator::addBookInfos(list<BookInfo*> bookInfos){
	for(list<BookInfo*>::iterator bookInfoIt = bookInfos.begin(); bookInfoIt != bookInfos.end(); bookInfoIt++){
                cout << __FUNCTION__ << " bookInfo " << (*bookInfoIt)->toString() << endl;
		addBookInfo(*bookInfoIt);
        }
}
