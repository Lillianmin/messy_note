#include <iostream>

#include "xmlcreator.h"

XMLCreator::XMLCreator(){
	cout << __FILE__ << " " << __FUNCTION__ << endl;
	doc = new XMLDocument();
	doc->InsertEndChild( doc->NewDeclaration() );
}

XMLCreator::~XMLCreator(){
	delete doc;
	doc = NULL;
}

XMLDocument* XMLCreator::getDoc(){
	return doc;
}
bool XMLCreator::saveFile(const char* path){
	int result = doc->SaveFile(path);
	if(result==XML_NO_ERROR){
		return true;
	}else{
		doc->PrintError();
		return false;
	}
}
char* XMLCreator::getStream(){
	XMLPrinter streamer;
        doc->Print(&streamer);
	int size = strlen(streamer.CStr());
	char* stream = new char[size+1];
	memset(stream, 0 , size+1);
	memcpy(stream, streamer.CStr(), size);
	stream[size]='\0';
	return stream;
}
XMLElement* XMLCreator::addRoot(const char* root){
	XMLElement* rootElement = doc->NewElement(root);
	doc->InsertEndChild(rootElement);
	return rootElement;
}

XMLElement* XMLCreator::addChild(XMLElement* parent, const char* child){
	XMLElement* childElement = doc->NewElement(child);
	return parent->InsertEndChild(childElement)->ToElement();
}

XMLElement* XMLCreator::addFirstChild(XMLElement* parent, const char* child){
	XMLElement* childElement = doc->NewElement(child);
	return parent->InsertFirstChild(childElement)->ToElement();
}


XMLElement* XMLCreator::addChildText(XMLElement* parent, const char* child, const char* text){
	XMLElement* childElement = addChild(parent, child);
	childElement->SetText(text);
	return childElement;
}

XMLElement* XMLCreator::addFirstChildText(XMLElement* parent, const char* child, const char* text){
	XMLElement* childElement = addFirstChild(parent, child);
	childElement->SetText(text);
	return childElement;
}


XMLElement* XMLCreator::addChildText(XMLElement* parent, const char* child, int value){
	XMLElement* childElement = addChild(parent, child);
	childElement->SetText(value);
	return childElement;
}
XMLElement* XMLCreator::addFirstChildText(XMLElement* parent, const char* child, int value){
	XMLElement* childElement = addFirstChild(parent, child);
	childElement->SetText(value);
	return childElement;
}

XMLElement* XMLCreator::addAttribute(XMLElement* element, const char* name, const char* value){
	element->SetAttribute(name, value);
	return element;
}
XMLElement* XMLCreator::addAttribute(XMLElement* element, const char* name, int value){
	element->SetAttribute(name, value);
	return element;
}
