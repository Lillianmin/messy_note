#include "bookxmlparser.h"
#include <iostream>
BookXMLParser::BookXMLParser(){
}
BookXMLParser::~BookXMLParser(){
	delete dInfo;
	dInfo = NULL;
}
DBookInfo* BookXMLParser::parseDBookInfo(XMLElement* element){
	cout << __FUNCTION__ << endl;
	dInfo = new DBookInfo;
	dInfo->setBookId(getChildText(element, "bookid"));
	dInfo->setBookName(getChildText(element, "bookname"));
	int width;
	getChildInt(element, "width", &width);
	dInfo->setWidth(width);
	int height;
	getChildInt(element, "height", &height);
	dInfo->setHeight(height);
	return dInfo;
}
DBookInfo* BookXMLParser::getDBookInfo()
{
	return dInfo;
}
EditItem* BookXMLParser::parseEditItem(XMLElement* element){
	EditItem* editItem= new EditItem();
	int editType;
	getChildInt(element, "opr_type", &editType);
	EditType type = static_cast<EditType>(editType);
	type = (EditType)editType;
	editItem->setEditType(type);
	XMLElement* trackElement = getChildElement(element, "track");
	while(trackElement!=NULL){
		Track track = parseTrack(trackElement);
		editItem->addTrack(track);
		trackElement=getNextElement(trackElement, "track");
	}
	return editItem;
}

Track BookXMLParser::parseTrack(XMLElement* element){
	Track track;
	int penWidth;
	getChildInt(element, "penwidth", &penWidth);
	track.setPenWidth(penWidth);
	XMLElement* pointsElement = getChildElement(element, "points");
	XMLElement* pointElement = getChildElement(pointsElement,"point");
	while(pointElement!=NULL){
		Point point = parsePoint(pointElement);
		track.addPoint(point);
		pointElement=getNextElement(pointElement, "point");
	}
	return track;
}

Point BookXMLParser::parsePoint(XMLElement* element){
	Point p;
	p.x = getIntAttribute(element, "x");	
	p.y = getIntAttribute(element, "y");	
	return p;
}
