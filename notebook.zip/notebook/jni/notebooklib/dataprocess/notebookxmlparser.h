#ifndef NOTEBOOKXMLPARSER_H
#define NOTEBOOKXMLPARSER_H
#include "bookxmlparser.h"
#include <list>
#include "../dnotebookinfo.h"
#include "../noteedititem.h"
using namespace std;
class NoteBookXMLParser : public BookXMLParser{
public:
	NoteBookXMLParser();
	~NoteBookXMLParser();
	DNoteBookInfo* getDNoteBookInfo();
	list<NoteEditItem*> getNoteEditItems();
	void parse();
private:
	DNoteBookInfo* parseDNoteBookInfo(XMLElement* element);
	NoteEditItem* parseNoteEditItem(XMLElement* element);
	DNoteBookInfo* dNoteBookInfo;
	list<NoteEditItem*> noteEditItems;

};
#endif
