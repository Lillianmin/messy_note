#ifndef NOTEBOOKDB_H
#define NOTEBOOKDB_H
#include <string>
#include "sqlitewrapper.h"
#include "../dnotebookinfo.h"
#include "../notebookinfo.h"
#include <list>
#include "../notepage.h"
#include "../noteedititem.h"
#include "basedb.h"
using namespace std;
class NoteBookDB : public BaseDB{
public:
	NoteBookDB(string path);
	~NoteBookDB();
	void createDB();
	int getLocalMaxOprId(string id);

	void addDNoteBookInfo(DNoteBookInfo* dInfo);
	DNoteBookInfo* getDNoteBookInfo(string bookid);
	list<NoteBookInfo*> getNoteBookInfoList();
	void addNotePage(string bookid, int pageid);
	list<NotePage*> getNotePageList(string bookid);
	NotePage* getNotePage(string bookid, int pageid);
	list<NoteEditItem*> getPageNoteEditItemList(string bookid, int pageid);
	void saveNoteEditItem(string bookid, NoteEditItem *item);

	void saveNoteBookInfoList(list<NoteBookInfo*> infoList);
	void saveNoteEditItemList(string bookid, list<NoteEditItem*> itemList);
	list<NoteEditItem*> getNoteEditItemList(string bookid, int serverMaxId);
private:
	void saveNoteBookInfo(NoteBookInfo* info);
};
#endif
