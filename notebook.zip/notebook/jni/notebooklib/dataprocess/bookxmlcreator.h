#ifndef BOOKXMLCREATOR_H
#define BOOKXMLCREATOR_H

#include "xmlcreator.h"
#include "../edititem.h"
#include "../dbookinfo.h"
#include "../track.h"

class BookXMLCreator : public XMLCreator{
public:
	BookXMLCreator(string root);
	virtual ~BookXMLCreator();	
	XMLElement* getRoot();
	XMLElement* addDBookInfo(XMLElement* parent, DBookInfo dBookInfo);
	XMLElement* addEditItem(XMLElement* parent, EditItem* editItem);
	
private:
	XMLElement* addTrack(XMLElement* parent, Track track);
	XMLElement* addPoint(XMLElement* parent, Point point);
	XMLElement* rootElement;
};
#endif
