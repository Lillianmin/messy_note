#ifndef MAXIDXMLPARSER_H
#define MAXIDXMLPARSER_H

#include "xmlparser.h"

class MaxIdXMLParser : public XMLParser{
public:
	MaxIdXMLParser();
	~MaxIdXMLParser();
	int getMaxId();
};
#endif
