#include "notebookdb.h"
#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define BUF_SIZE 128

NoteBookDB::NoteBookDB(string path):BaseDB(path){
	cout << __FILE__ << "\t" << __FUNCTION__ << endl;
	createDB();
}

NoteBookDB::~NoteBookDB(){

}

void NoteBookDB::createDB(){
	cout << __FILE__ << "\t" <<  __FUNCTION__ << endl;
        string sql;
        sql = "CREATE TABLE IF NOT EXISTS notebook(id INTEGER PRIMARY key AUTOINCREMENT, notebookid TEXT UNIQUE, notebookname TEXT , background BLOB, cover BLOB, pagewidth INTEGER, pageheight INTEGER);";
        db.executeUpdate(sql);

	sql = "CREATE TABLE IF NOT EXISTS thumb(id INTEGER PRIMARY key AUTOINCREMENT, notebook_idx INTEGER NOT NULL REFERENCES notebook(id), thumb BLOB);";
	db.executeUpdate(sql);
        sql = "CREATE TABLE IF NOT EXISTS notepage(id INTEGER PRIMARY key AUTOINCREMENT, notebook_idx INTEGER NOT NULL REFERENCES notebook(id), pageid INTEGER);";
        db.executeUpdate(sql);

        sql = "CREATE TABLE IF NOT EXISTS edititem(id INTEGER PRIMARY key AUTOINCREMENT, notepage_idx INTEGER NOT NULL REFERENCES notepage(id), opr_idx INTEGER, edittype INTEGER);";
        db.executeUpdate(sql);

        sql = "CREATE TABLE IF NOT EXISTS track(id INTEGER PRIMARY key AUTOINCREMENT, edititem_idx INTEGER NOT NULL REFERENCES edititem(id),  penwidth INTEGER);";
        db.executeUpdate(sql);
        
	sql = "CREATE TABLE IF NOT EXISTS point(id INTEGER PRIMARY key AUTOINCREMENT, track_idx INTEGER NOT NULL REFERENCES  track(id), pointx INTEGER, pointy INTEGER);";
        db.executeUpdate(sql);
}

void NoteBookDB::addDNoteBookInfo(DNoteBookInfo* dInfo){
	char pageWidthStr[BUF_SIZE];
        memset(pageWidthStr, 0, BUF_SIZE);
        sprintf(pageWidthStr, "%d", dInfo->getWidth());
	char pageHeightStr[BUF_SIZE];
	memset(pageHeightStr, 0, BUF_SIZE);
	sprintf(pageHeightStr, "%d", dInfo->getHeight());

	string sql;
	sql = "select notebookid from notebook where notebookid=\'" + dInfo->getBookId() + "\';";
	ResultList pidList = db.executeQuery(sql);
        if(pidList.size() != 0){
		sql = "update notebook set notebookname=\'"+ dInfo->getBookName();
		sql += "\',pagewidth=";
		sql = sql.append(pageWidthStr);
		sql +=  ",pageheight=";
		sql = sql.append(pageHeightStr);
                sql += " where notebookid = \'" + dInfo->getBookId() + "\';";
//		cout << __FUNCTION__ << sql << endl;
                db.executeUpdate(sql);
        }else{
		//insert
		sql = "insert into notebook(notebookid, notebookname, pagewidth, pageheight) values(\'" + 
			dInfo->getBookId() + "\',\'" + dInfo->getBookName() + "\',";
		sql = sql.append(pageWidthStr);
		sql +=  ",";
		sql = sql.append(pageHeightStr);
		sql += ");";
//		cout << __FUNCTION__ << sql << endl;
        	db.executeUpdate(sql);
	}
	sql = "update notebook set cover = ? where notebookid=\'"+dInfo->getBookId()+"\';";
	updateBLOB(sql.c_str(), dInfo->getCover(), dInfo->getCvSize());
	sql = "update notebook set background = ? where notebookid=\'"+dInfo->getBookId()+"\';";
	updateBLOB(sql.c_str(), dInfo->getBackground(), dInfo->getBgSize());

}
DNoteBookInfo* NoteBookDB::getDNoteBookInfo(string bookid){
	DNoteBookInfo *dInfo = new DNoteBookInfo();
	dInfo->setBookId(bookid);
	string sql = "select * from notebook where notebookid=\'" + bookid + "\';";
	ResultList bookList = db.executeQuery(sql);
        if(bookList.size() != 0){
		ResultList::iterator it = bookList.begin();                         
		FieldsMap bookMap = *it;
		for(FieldsMap::iterator fit = bookMap.begin(); fit!= bookMap.end(); fit++){	

			string bookNameStr;
			if(fit->first == "notebookname"){
				bookNameStr = fit->second;
				dInfo->setBookName(bookNameStr);
			}
			string pageWidthStr;
			if(fit->first == "pagewidth"){
				pageWidthStr = fit->second;
				dInfo->setWidth(static_cast<int>(strtol(pageWidthStr.c_str(), NULL, 10)));
			}
			string pageHeightStr;
			if(fit->first == "pageheight"){
				pageHeightStr = fit->second;
				dInfo->setHeight(static_cast<int>(strtol(pageHeightStr.c_str(), NULL, 10)));
			}
		}
		char* cover;
		int coverSize = 0;
		sql = "select cover from notebook where notebookid=\'"+bookid+"\';";
		getBLOB(sql.c_str(), &cover, &coverSize);
		cout <<__FUNCTION__ << " " << __FILE__ << " cover " << cover << endl;
		char* background;
		int backgroundSize = 0;
		sql = "select background from notebook where notebookid=\'" + bookid + "\';";
		getBLOB(sql.c_str(), &background, &backgroundSize);
		dInfo->setCover(cover, coverSize);
		dInfo->setBackground(background, backgroundSize);

		delete [] cover;
		cover = NULL;
		delete [] background;
		background = NULL;

        }
	return dInfo;
}
list<NoteBookInfo*> NoteBookDB::getNoteBookInfoList(){
	list<NoteBookInfo*> bookInfoList;

        string sql = "select * from notebook;";
        ResultList bookList = db.executeQuery(sql);
        if(bookList.size() == 0){
                return bookInfoList;
        }
        for(ResultList::iterator bookit = bookList.begin(); bookit != bookList.end(); bookit++){
                FieldsMap infofm = (*bookit);
                NoteBookInfo *info = new NoteBookInfo();
                for(FieldsMap::iterator infoit = infofm.begin(); infoit != infofm.end(); infoit++){
                        if(infoit->first == "notebookid")
                                info->setBookId(infoit->second);
                        else if(infoit->first == "notebookname")
                                info->setBookName(infoit->second);
                }
		sql = "select thumb from thumb where notebook_idx in(select id from notebook where notebookid=\'"+ info->getBookId() +"\');";
		
		ResultList thumbList = db.executeQuery(sql);
		if(thumbList.size()!=0){
			char* thumb;
			int thumbSize = 0;
			getBLOB(sql.c_str(), &thumb, &thumbSize);
			info->setThumb(thumb, thumbSize);
			delete [] thumb;
			thumb = NULL;
		}
                bookInfoList.push_back(info);
        }
        return bookInfoList;

}
void NoteBookDB::addNotePage(string bookid, int pageid){
//	cout << __FUNCTION__ << " bookid " << bookid << endl;
        string sql = "select id from notebook where notebookid=\'" + bookid + "\';";
        ResultList bookIdList = db.executeQuery(sql);
        string bookIdxStr;
        if(bookIdList.size() != 0){
                ResultList::iterator it = bookIdList.begin();
                FieldsMap fm = *it;
                FieldsMap::iterator fit = fm.begin();
                if(fit->first == "id")
                        bookIdxStr = fit->second;
//		cout << __FUNCTION__ << " bookIdxStr " << bookIdxStr << endl;
        }else{
//		cout << "return " << __FUNCTION__ << endl;
		return;
	}

        char pageIdStr[BUF_SIZE];
        memset(pageIdStr, 0, BUF_SIZE);
	sprintf(pageIdStr, "%d", pageid);
        sql = "select id from notepage where pageid=" + string(pageIdStr) + " and notebook_idx="+ bookIdxStr + ";";
        ResultList pidList = db.executeQuery(sql);
        if(pidList.size() != 0){
        }else{
		sql = "insert into notepage(notebook_idx, pageid) values(" + bookIdxStr + "," + string(pageIdStr) + ");";
//		cout << __FUNCTION__ << " sql " << sql << endl;
		db.executeUpdate(sql);
	}
}

list<NotePage*> NoteBookDB::getNotePageList(string bookid){
	list<NotePage*> notePageList;
	list<int> pageList;
	string sql = "select pageid from notepage where notebook_idx in(select id from notebook where notebookid=\'"+ bookid + "\');";
	ResultList resultList = db.executeQuery(sql);
	for(ResultList::iterator it= resultList.begin(); it != resultList.end(); it++){
		for(FieldsMap::iterator fit = it->begin(); fit != it->end(); fit++){
			if(fit->first=="pageid"){
				string pageIdStr = fit->second;
//				cout << __FUNCTION__ << " pageIdStr " << pageIdStr << endl;
				int pageId = static_cast<int>(strtol(pageIdStr.c_str(), NULL, 10));
//				cout << __FUNCTION__ << " pageId " << pageId << endl;
				pageList.push_back(pageId);
			}
		}
	}
	for(list<int>::iterator pageIt = pageList.begin(); pageIt != pageList.end(); pageIt++){
//		cout << __FUNCTION__ << " pageIt " << *pageIt << endl;
		NotePage* page = new NotePage(*pageIt);
		list<NoteEditItem*> items = getPageNoteEditItemList(bookid, *pageIt);
		page->addItemList(items);
/*
		for(list<NoteEditItem*>::iterator it = items.begin(); it != items.end();){
			list<NoteEditItem*>::iterator it2 = it;
			it++;
			delete *it2;
		}
		items.clear();
*/
		notePageList.push_back(page);
	}
//	cout << __FUNCTION__ << " size "<< notePageList.size() << endl;
	return notePageList;
}
NotePage* NoteBookDB::getNotePage(string bookid, int pageid){
	NotePage* page = new NotePage(pageid);
	page->addItemList(getPageNoteEditItemList(bookid, pageid));
	return page;
}
list<NoteEditItem*> NoteBookDB::getPageNoteEditItemList(string bookid, int pageid){
	db.beginTransaction();
	list<NoteEditItem*> itemList;
	char pageIdStr[BUF_SIZE];
	memset(pageIdStr, 0, BUF_SIZE);
	sprintf(pageIdStr, "%d", pageid);
	string sql = "select id from notepage where notebook_idx in (select id from notebook where notebookid=\'" + bookid + "\') and pageid="+pageIdStr+";";
	string pageIdxStr;
	ResultList pageIdxList = db.executeQuery(sql);
	fprintf(stderr, "NoteBookDB::%s pageIdxList.size()=%d\n", __func__, pageIdxList.size());
	if(pageIdxList.size() == 0){
	}else{
		FieldsMap pageIdxFm = *(pageIdxList.begin());
		FieldsMap::iterator pageIdxFmIt = pageIdxFm.begin();
		if(pageIdxFmIt->first == "id"){
			pageIdxStr = pageIdxFmIt->second;
		}
		sql = "select * from edititem where notepage_idx="+pageIdxStr+";";
		fprintf(stderr, "NoteBookDB::%s sql=%s\n", __func__, sql.c_str());
		ResultList itemResultList = db.executeQuery(sql);	
		fprintf(stderr, "NoteBookDB::%s itemResultList.size()=%d\n", __func__, itemResultList.size());
		if(itemResultList.size()==0){
		}else{
			for(ResultList::iterator itemFm = itemResultList.begin(); itemFm!=itemResultList.end();itemFm++){
				NoteEditItem* noteEditItem = new NoteEditItem();
				noteEditItem->setPageId(pageid);
				for(FieldsMap::iterator it= itemFm->begin(); it!=itemFm->end();it++){
					string itemIdxStr;
					string itemOprIdStr;
					string itemEditTypeStr;
					if(it->first == "id"){
						itemIdxStr = it->second;
						int itemIdx = static_cast<int>(strtol(itemIdxStr.c_str(), NULL, 10));
						list<Track*> tracks = getTracks(itemIdx);
						fprintf(stderr, "NoteBookDB::%s tracks.size()=%d\n", __func__,tracks.size());
						noteEditItem->addTracks(tracks);
						for(list<Track*>::iterator it = tracks.begin(); it != tracks.end(); ){
							list<Track*>::iterator it2 = it;
							it++;
							delete *it2;
						}
						tracks.clear();

					}
					if(it->first == "opr_idx"){
						itemOprIdStr = it->second;
						int oprId = static_cast<int>(strtol(itemOprIdStr.c_str(), NULL, 10));
						noteEditItem->setOprId(oprId);
					}
					if(it->first == "edittype"){
						itemEditTypeStr = it->second;
						int editType = static_cast<int>(strtol(itemEditTypeStr.c_str(), NULL, 10));
						EditType type = static_cast<EditType>(editType);
						noteEditItem->setEditType(type);
					}
						
				}
				itemList.push_back(noteEditItem);
			}
		}
		
	}
//	cout << __FUNCTION__ << " note edit item list size " << itemList.size() << endl;
	db.endTransaction();
	return itemList;
}

void NoteBookDB::saveNoteEditItem(string bookid, NoteEditItem *item){
//	cout <<__FILE__ << " \t" << __FUNCTION__<<" bookid " << bookid << " item " << item->toString() << endl;
	db.beginTransaction();
	
	char oprStr[BUF_SIZE];
	memset(oprStr, 0, BUF_SIZE);
	sprintf(oprStr, "%d", item->getOprId());
	char typeStr[BUF_SIZE];
	memset(typeStr, 0, BUF_SIZE);
	sprintf(typeStr, "%d", item->getEditType());
	char pageIdStr[BUF_SIZE];
	memset(pageIdStr, 0, BUF_SIZE);
	sprintf(pageIdStr, "%d", item->getPageId());

	string sql = "select id from notepage where notebook_idx in (select id from notebook where notebookid=\'" + bookid + "\') and pageid="+string(pageIdStr)+";";
	string pageIdxStr;
	ResultList pageIdxList = db.executeQuery(sql);
	if(pageIdxList.size() == 0){
		addNotePage(bookid, item->getPageId());
		pageIdxList = db.executeQuery(sql);
	}
//	cout <<__FUNCTION__<< " sql " << sql << endl;
	if(pageIdxList.size() == 0){
		//in case no relative bookname in db, and addNotePage not success!
//		cout << __FUNCTION__ << " pageIdxList size 0" << endl;
		return;
	}
	FieldsMap pageFm = *(pageIdxList.begin());
	FieldsMap::iterator pageFmit = pageFm.begin();
	if(pageFmit->first == "id")
		pageIdxStr = pageFmit->second;

	sql = "insert into edititem(notepage_idx, opr_idx, edittype) values(" + pageIdxStr + "," +string(oprStr) + "," + string(typeStr) + ");";
	fprintf(stderr, "sql=%s\n", sql.c_str());
	db.executeUpdate(sql);
	list<Track> trackList = item->getTracks();
	if(trackList.size() == 0)
		return;

	sql = "select max(id) as maxId from edititem;";
	ResultList oprList = db.executeQuery(sql);
	FieldsMap oprfm = *(oprList.begin());
	FieldsMap::iterator oprfmit = oprfm.begin();
	if(oprfmit->first == "maxId"){
		string trackIdxStr = oprfmit->second;
		int itemIdx = static_cast<int>(strtol(trackIdxStr.c_str(), NULL, 10));
		saveTracks(itemIdx, trackList);
	}
	db.endTransaction();
}
int NoteBookDB::getLocalMaxOprId(string id){
        string sql = "select max(opr_idx) AS maxId from edititem;";
        ResultList oprList = db.executeQuery(sql);
        if(oprList.size() == 0){
                return 0;
        }
        FieldsMap fm = *(oprList.begin());
        string oprStr;
        for(FieldsMap::iterator it = fm.begin(); it != fm.end(); it++){
                if(it->first == "maxId")
                        oprStr = it->second;
        }
        return static_cast<int>(strtol(oprStr.c_str(), NULL, 10));
}
void NoteBookDB::saveNoteBookInfoList(list<NoteBookInfo*> infoList){
	for(list<NoteBookInfo*>::iterator infoIt = infoList.begin(); infoIt!=infoList.end(); infoIt++){
		saveNoteBookInfo(*infoIt);
	}
}
void NoteBookDB::saveNoteBookInfo(NoteBookInfo* info){
//TODO update	
	string sql = "select id from notebook where notebookid=\'" + info->getBookId() + "\';";
	cout << __FUNCTION__ << " sql " << sql << endl;
	ResultList bookList = db.executeQuery(sql);
	if(bookList.size()==0){
		sql = "insert into notebook(notebookname, notebookid) values(\'" + info->getBookName()+"\', \'"+ info->getBookId() + "\');";
	}else{
		sql = "update notebook set notebookname=\'"+info->getBookName()+"\' where notebookid=\'" + info->getBookId() + "\';";
	}
	cout << __FUNCTION__ << " sql " << sql << endl;
	db.executeUpdate(sql);
	sql = "select id from notebook where notebookid=\'" + info->getBookId() + "\';";
	cout << __FUNCTION__ << " sql " << sql << endl;
	bookList = db.executeQuery(sql);
	string bookIdx;
	FieldsMap fm = *(bookList.begin());
	for(FieldsMap::iterator it = fm.begin(); it != fm.end(); it++){
		if(it->first == "id"){
			bookIdx = it->second;
			//TODO select thumb if found update, else insert	
			sql = "select id from thumb where notebook_idx =" + bookIdx+";";
			ResultList thumbResultList = db.executeQuery(sql);

			if(thumbResultList.size()==0){
				sql = "insert into thumb(notebook_idx) values(" + bookIdx + ");";
			}
			cout << __FUNCTION__ << " sql " << sql << endl;
			db.executeUpdate(sql);
			sql = "update thumb set thumb = ? where notebook_idx="+bookIdx+";";
			updateBLOB(sql.c_str(), info->getThumb(), info->getThumbSize());
		}
	}
}
void NoteBookDB::saveNoteEditItemList(string bookid, list<NoteEditItem*> itemList){
	for(list<NoteEditItem*>::iterator itemIt=itemList.begin();itemIt!=itemList.end();itemIt++){
		saveNoteEditItem(bookid, *itemIt);
	}
}
list<NoteEditItem*> NoteBookDB::getNoteEditItemList(string bookid, int serverMaxId){
	list<NoteEditItem*> itemList;
	char serverMaxIdStr[BUF_SIZE];
	memset(serverMaxIdStr, 0, BUF_SIZE);
	sprintf(serverMaxIdStr, "%d", serverMaxId);
	string sql = "select * from edititem where opr_idx > " + string(serverMaxIdStr) + " and notepage_idx in(select id from notepage where notebook_idx in(select id from notebook where notebookid=\'"+bookid+"\'))"+";";
//	cout<< __FUNCTION__<<" sql " << sql << endl;
	ResultList itemResultList = db.executeQuery(sql);
	
	if(itemResultList.size()==0){
	}else{
		for(ResultList::iterator itemFm = itemResultList.begin(); itemFm!=itemResultList.end();itemFm++){
			NoteEditItem* noteEditItem = new NoteEditItem();
			for(FieldsMap::iterator it= itemFm->begin(); it!=itemFm->end();it++){
				string itemIdxStr;
				string itemOprIdStr;
				string itemEditTypeStr;
				string itemNotePageIdxStr;
				if(it->first == "id"){
					itemIdxStr = it->second;
					int itemIdx = static_cast<int>(strtol(itemIdxStr.c_str(), NULL, 10));
					list<Track*> tracks = getTracks(itemIdx);
					noteEditItem->addTracks(tracks);
					for(list<Track*>::iterator it = tracks.begin(); it != tracks.end(); ){
						list<Track*>::iterator it2 = it;
						it++;
						delete *it2;
					}
					tracks.clear();

				}
				if(it->first == "opr_idx"){
					itemOprIdStr = it->second;
					int oprId = static_cast<int>(strtol(itemOprIdStr.c_str(), NULL, 10));
					noteEditItem->setOprId(oprId);
				}
				if(it->first == "edittype"){
					itemEditTypeStr = it->second;
					int editType = static_cast<int>(strtol(itemEditTypeStr.c_str(), NULL, 10));
					EditType type = static_cast<EditType>(editType);
					noteEditItem->setEditType(type);
				}
				if(it->first == "notepage_idx"){
					itemNotePageIdxStr = it->second;
					sql = "select pageid from notepage where id="+itemNotePageIdxStr+";";
					ResultList pageIdList = db.executeQuery(sql);
					if(pageIdList.size()!=0){
						FieldsMap fm = *(pageIdList.begin());
						FieldsMap::iterator fit = fm.begin();
						if(fit->first=="pageid"){
							string pageIdStr = fit->second;
							int pageId = static_cast<int>(strtol(pageIdStr.c_str(), NULL, 10));
							noteEditItem->setPageId(pageId);
						}
					}
				}
					
			}
			itemList.push_back(noteEditItem);
		}
	}
	return itemList;
}
