#ifndef BASEDB_H
#define BASEDB_H
#include <string>
#include <list>
#include "sqlitewrapper.h"
#include "../track.h"
using namespace std;
class BaseDB{
public:
	BaseDB(string path);
	virtual ~BaseDB() = 0;
	void closeDB();
	int str2Int(string str);
	list<Track*> getTracks(int);
	void saveTracks(int editIdx, list<Track> trackList);

	virtual void createDB()=0;
	virtual int getLocalMaxOprId(string id)=0;

	void updateBLOB(const char* sql, const char* blob, int len);
	void getBLOB(const char* sql, char** blob, int* len);
	void printHex(char* data, int len);

	SQLiteWrapper db;	
private:
        list<Point*> getPoints(int);
	string dbPath;
};
#endif
