#include "maxidxmlparser.h"

MaxIdXMLParser::MaxIdXMLParser(){

}
MaxIdXMLParser::~MaxIdXMLParser(){

}

int MaxIdXMLParser::getMaxId(){
	int maxId;
	getChildInt(getRootElement(), "maxid", &maxId);
	return maxId;
}
