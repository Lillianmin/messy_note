#ifndef MAXIDXMLCREATOR_H
#define MAXIDXMLCREATOR_H

#include "tinyxml2.h"
#include "xmlcreator.h"

using namespace tinyxml2;

class MaxIdXMLCreator : public XMLCreator{
public:
	MaxIdXMLCreator(const char* root, int maxId);
	~MaxIdXMLCreator();

};
#endif
