#ifndef XMLCREATOR_H
#define XMLCREATOR_H

#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;

class XMLCreator{
public:
	XMLCreator();
	virtual ~XMLCreator();
	XMLDocument* getDoc();
	bool saveFile(const char* path);
	char* getStream();
	XMLElement* addRoot(const char* root);
	XMLElement* addChild(XMLElement* parent, const char* child);
	XMLElement* addFirstChild(XMLElement* parent, const char* child);
	XMLElement* addChildText(XMLElement* parent, const char* child, const char* text);
	XMLElement* addFirstChildText(XMLElement* parent, const char* child, const char* text);
	XMLElement* addChildText(XMLElement* parent, const char* child, int value);
	XMLElement* addFirstChildText(XMLElement* parent, const char* child, int value);
	XMLElement* addAttribute(XMLElement* element, const char* name, const char* value);
	XMLElement* addAttribute(XMLElement* element, const char* name, int value);
private:
	XMLDocument* doc;
};
#endif

