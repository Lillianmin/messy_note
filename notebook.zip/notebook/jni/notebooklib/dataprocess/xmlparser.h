#ifndef XMLPARSER_H
#define XMLPARSER_H

#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;
class XMLParser{
public:
	XMLParser();
	virtual ~XMLParser();
	bool loadFile(const char* path);
	bool loadStream(const char* xml);
	XMLDocument* getDoc();
	XMLElement* getRootElement();
	XMLElement* getChildElement(XMLElement* parent, const char* child);
	XMLElement* getNextElement(XMLElement* element, const char* tag);
	const char* getChildText(XMLElement* parent, const char* child);
	void getChildInt(XMLElement* parent, const char* child, int* value);
	const char* getAttribute(XMLElement* element, const char* name);
	int getIntAttribute(XMLElement* element, const char* name);
private:
	XMLDocument* doc;
};
#endif
