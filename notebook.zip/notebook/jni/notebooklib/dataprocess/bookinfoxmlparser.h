#ifndef BOOKINFOXMLPARSER_H
#define BOOKINFOXMLPARSER_H

#include <list>

#include "xmlparser.h"
#include "../bookinfo.h"
using namespace tinyxml2;

class BookInfoXMLParser : public XMLParser{
public:
	BookInfoXMLParser();
	virtual ~BookInfoXMLParser();
	void parse();
	virtual BookInfo* parseBookInfo(XMLElement* bookElement);
	list<BookInfo*> getBookInfos();
private:
	list<BookInfo*> bookInfos;
};
#endif
