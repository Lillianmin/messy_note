#include "xmlparser.h"
#include "iostream"
XMLParser::XMLParser(){
	doc = NULL;
}

XMLParser::~XMLParser(){
	if(doc != NULL){
	delete doc;
	doc = NULL;
	}
}
bool XMLParser::loadFile(const char* path){
	doc = new XMLDocument();
	doc->LoadFile(path);
	int error = doc->ErrorID();
	if(error==XML_NO_ERROR){
		return true;
	}else{
		doc->PrintError();
		return false;
	}

}
bool XMLParser::loadStream(const char* xml){
	cout << __FUNCTION__ << " xml " << xml << endl;
	doc = new XMLDocument();
	doc->Parse(xml);
	int error = doc->ErrorID();
	if(error==XML_NO_ERROR){
		return true;
	}else{
		doc->PrintError();
		return false;
	}
}
XMLDocument* XMLParser::getDoc(){
	return doc;
}

XMLElement* XMLParser::getRootElement(){
	return doc->RootElement();
}

XMLElement* XMLParser::getChildElement(XMLElement* parent, const char* child){
	return parent->FirstChildElement(child);
}
XMLElement* XMLParser::getNextElement(XMLElement* element, const char* tag){
	return element->NextSiblingElement(tag);
}
const char* XMLParser::getChildText(XMLElement* parent, const char* child){
	return parent->FirstChildElement(child)->GetText();
}
void XMLParser::getChildInt(XMLElement* parent, const char* child, int* value){
	parent->FirstChildElement(child)->QueryIntText(value);
}

const char* XMLParser::getAttribute(XMLElement* element, const char* name){
	return element->Attribute(name);
}

int XMLParser::getIntAttribute(XMLElement* element, const char* name){
	return element->IntAttribute(name);
}
