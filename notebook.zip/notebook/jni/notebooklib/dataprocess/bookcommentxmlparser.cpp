#include "bookcommentxmlparser.h"
#include <iostream>
BookCommentXMLParser::BookCommentXMLParser(){
}
BookCommentXMLParser::~BookCommentXMLParser(){
	for(list<Annotation*>::iterator it = annotations.begin(); it != annotations.end();){
		list<Annotation*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	annotations.clear();
}
void BookCommentXMLParser::parse(){
	XMLElement* bookElement = getChildElement(getRootElement(), "book");
	parseDBookInfo(bookElement);
	cout << __FUNCTION__ << " after parseDBookInfo " << endl;
	XMLElement* commentsElement = getChildElement(getRootElement(), "comments");
	XMLElement* textCommentElement = getChildElement(commentsElement, "text_comment");
	while(textCommentElement != NULL){
		TextAnnotation* ta = parseTextComment(textCommentElement);
		annotations.push_back(ta);
		textCommentElement=getNextElement(textCommentElement, "text_comment");
	}
	XMLElement* trackCommentElement = getChildElement(commentsElement, "track_comment");
	while(trackCommentElement != NULL){
		HWAnnotation* hwa = parseTrackComment(trackCommentElement);
		annotations.push_back(hwa);
		trackCommentElement=getNextElement(trackCommentElement, "track_comment");
	}
}

list<Annotation*> BookCommentXMLParser::getAnnotations(){
	return annotations;
}

TextAnnotation* BookCommentXMLParser::parseTextComment(XMLElement* element){
	Annotation* an = parseBaseComment(element);
	TextAnnotation* ta = new TextAnnotation(*an);
	ta->setComment(getChildText(element, "comment"));
	delete an;
	an = NULL;
	return ta;
}

HWAnnotation* BookCommentXMLParser::parseTrackComment(XMLElement* element){
	Annotation* an = parseBaseComment(element);
	HWAnnotation*  hwa = new HWAnnotation(*an);
	XMLElement* editItemElement = getChildElement(element, "edititem");
	EditItem* item = parseEditItem(editItemElement);
	hwa->setEditItem(*item);
	delete an;
	an = NULL;
	delete item;
	item = NULL;
	return hwa;
}

Annotation* BookCommentXMLParser::parseBaseComment(XMLElement* element){
	Annotation* annotation = new Annotation();
	int oprId;
	getChildInt(element, "opr_idx", &oprId);
	annotation->setOprId(oprId);
	int partId;
	getChildInt(element, "partid", &partId);
	annotation->setPartId(partId);
	int startPos;
	getChildInt(element, "startpos", &startPos);
	annotation->setStartPos(startPos);
	int endPos;
	getChildInt(element, "endpos", &endPos);
	annotation->setEndPos(endPos);
	annotation->setQuote(getChildText(element, "quote"));
	return annotation;
}
