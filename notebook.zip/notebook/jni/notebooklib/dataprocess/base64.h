#ifndef BASE64_H
#define BASE64_H
#include <string>
using namespace std;
class Base64{
public:
	Base64();
	~Base64();
	static void  encode(char*, int, char*, int*);
	static void  decode(char*, int, char*, int*);
};
#endif
