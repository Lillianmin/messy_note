#ifndef BOOKINFOXMLCREATOR_H
#define BOOKINFOXMLCREATOR_H

#include <list>
#include "tinyxml2.h"
#include "xmlcreator.h"
#include "../bookinfo.h"

using namespace tinyxml2;
using namespace std;

class BookInfoXMLCreator : public XMLCreator{
public:
	BookInfoXMLCreator(const char* root = "bookcomment");
	virtual ~BookInfoXMLCreator();
	virtual XMLElement* addBookInfo(BookInfo* bookInfo);
	void addBookInfos(list<BookInfo*> bookInfos);
private:
	XMLElement* rootElement;
	XMLElement* booksElement;
};
#endif
