#include "maxidxmlcreator.h"

MaxIdXMLCreator::MaxIdXMLCreator(const char* root, int maxId){
	XMLElement* rootElement = addRoot(root);
	XMLElement* maxIdElement = addChild(rootElement, "maxid");
	maxIdElement->SetText(maxId);
	
}

MaxIdXMLCreator::~MaxIdXMLCreator(){

}
