#ifndef BOOKCOMMENTDB_H
#define BOOKCOMMENTDB_H

#include <string>
#include <list>
#include "sqlitewrapper.h"
#include "../dbookinfo.h"
#include "../bookinfo.h"
#include "../annotation.h"
#include "../edititem.h"
#include "basedb.h"

using namespace std;

class BookCommentDB : public BaseDB{
public:
	BookCommentDB(string path);
	~BookCommentDB();
	void createDB();
	int getLocalMaxOprId(string bookid);
	
	void addDBookInfo(DBookInfo*);
	DBookInfo* getDBookInfo(string bookid);
	list<BookInfo*> getBookInfoList();
	list<Annotation*> getAnnotationList(string bookid);
	list<Annotation*> getPartAnnotationList(string bookid, int partid);
	void saveAnnotation(string bookid, Annotation* annotation);
	
	void saveBookInfoList(list<BookInfo*> infoList);
	void saveAnnotationList(string bookid, list<Annotation*> annotationList);
	list<Annotation*> getAnnotationList(string bookid, int serverMaxId);

	
private:
	void saveBookInfo(BookInfo* info);
	string getComment(int quoteIdx);
	EditItem* getEditItem(int quoteIdx);
	list<Annotation*> queryAnnotationList(string sql);
	void saveText(int quoteIdx, string comment);
	void saveHWAnnotation(int quoteIdx, EditItem* item);
};
#endif
