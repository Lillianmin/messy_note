#include "notebookinfoxmlparser.h"
#include "../notebookinfo.h"
#include "iostream"

NoteBookInfoXMLParser::NoteBookInfoXMLParser(){

}
NoteBookInfoXMLParser::~NoteBookInfoXMLParser(){

}

BookInfo* NoteBookInfoXMLParser::parseBookInfo(XMLElement* bookElement){
//	cout << __FUNCTION__ << " " << __FILE__ << endl;
	BookInfo* bookInfo = BookInfoXMLParser::parseBookInfo(bookElement);
	const char* thumb = getChildText(bookElement,"thumb");
	NoteBookInfo* noteBookInfo = new NoteBookInfo(*bookInfo);
	
	cout << __FUNCTION__ << " thumb " << thumb << endl;
	if(thumb!=NULL){
		int size = strlen(thumb);
		noteBookInfo->setThumb((char*)thumb, size);
	}
	delete bookInfo;
	bookInfo = NULL;
	return noteBookInfo;
}

