#ifndef BOOKXMLPARSER_H
#define BOOKXMLPARSER_H

#include "xmlparser.h"
#include "../dbookinfo.h"
#include "../edititem.h"
#include "../track.h"
class BookXMLParser : public XMLParser{
public:
	BookXMLParser();
	virtual ~BookXMLParser();
	DBookInfo* parseDBookInfo(XMLElement* element);
	EditItem* parseEditItem(XMLElement* element);
	DBookInfo* getDBookInfo();
private:
	Track parseTrack(XMLElement* element);
	Point parsePoint(XMLElement* element);
	DBookInfo* dInfo;
};
#endif
