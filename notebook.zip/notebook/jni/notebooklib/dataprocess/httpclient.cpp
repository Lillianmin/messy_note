#include "httpclient.h"
#include <iostream>
HttpClient::HttpClient(){
	headers = NULL;
	post = NULL;
	last = NULL;
}
HttpClient::~HttpClient(){
}
void HttpClient::addHeader(string name, string value){
	string header = name.append(":").append(value);
	headers = curl_slist_append(headers, header.c_str());
}
void HttpClient::setUserAgent(string ua){
	userAgent = ua;
}
void HttpClient::formAddContent(string name, string content){
	curl_formadd(&post, &last, CURLFORM_COPYNAME, name.c_str(), CURLFORM_COPYCONTENTS, content.c_str(), CURLFORM_END);
}
void HttpClient::formAddFile(string name, string path){
	curl_formadd(&post, &last, CURLFORM_COPYNAME, name.c_str(), CURLFORM_FILE, path.c_str(), CURLFORM_END);
}
//TODO valgrind Conditional jump or move depends on uninitialised value(s)(2+15 errors)
//TODO valgrind Use of uninitialised value of size(15 errors)
void HttpClient::formAddFileStream(const char* filename, const char* data, long size){
	// curl_formadd(&post, &last, CURLFORM_COPYNAME, filename, CURLFORM_PTRCONTENTS, data, CURLFORM_CONTENTSLENGTH, size, CURLFORM_END);
	 curl_formadd(&post, &last, CURLFORM_COPYNAME, filename, CURLFORM_COPYCONTENTS, data, CURLFORM_CONTENTSLENGTH, size, CURLFORM_END);
}
//TODO valgrind Conditional jump or move depends on uninitialised value(s)(2+15 errors)
//TODO valgrind Use of uninitialised value of size(15 errors)
void HttpClient::formAddFileStream(const char* fieldname, const char* filename, const char* data, long size){
	 curl_formadd(&post, &last, CURLFORM_COPYNAME, fieldname, CURLFORM_BUFFER, filename, CURLFORM_BUFFERPTR, data, CURLFORM_BUFFERLENGTH, size, CURLFORM_END);
}
bool HttpClient::doPost(string url, string caPath, WriteCallback wc, void* data){
	bool result = false;
	curl_global_init(CURL_GLOBAL_ALL);
	CURL* curl;
	CURLcode res;
	curl = curl_easy_init();
	if(curl){
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
		if(!caPath.empty()){
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
			curl_easy_setopt(curl, CURLOPT_CAINFO, caPath.c_str());
		}else{
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		}
		if(!userAgent.empty()){
			curl_easy_setopt(curl, CURLOPT_USERAGENT, userAgent.c_str());
		}
		if(headers){
			curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		}
		if(post&&last){
			curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
		}
		
		if(data){ 
			curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, wc); 
			curl_easy_setopt(curl, CURLOPT_WRITEDATA, data);
		}
				
		curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, headerCallback); 

		curl_easy_setopt(curl, CURLOPT_HEADERDATA, (void*)&headerData);

		res = curl_easy_perform(curl);

		curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &responseCode);
		if(res!=CURLE_OK){
			fprintf(stderr, "curl_easy_perform() failed: %s\n",
				curl_easy_strerror(res));
			result = false;
		}else{	
			result =  true;
		}
		if(post){
			curl_formfree(post);
		}
		if(headers){
			curl_slist_free_all(headers);
		}
		curl_easy_cleanup(curl);
	}
	curl_global_cleanup();
	return result;
}

size_t HttpClient::writeCallback(char* buffer, size_t size, size_t nmemb, void *data){
	std::string* str = reinterpret_cast<std::string*>(data);  
	if (NULL == str || NULL == buffer)  
	{  
		return -1;  
	}  

	char* pData =  reinterpret_cast<char*>(buffer);  
	str->append(pData, size * nmemb);  
	return nmemb * size;
}

size_t HttpClient::headerCallback(char *buffer, size_t size, size_t nitems, void *headerdata){
	cout << __FUNCTION__ << endl;
	size_t dataSize = writeCallback(buffer, size, nitems, headerdata);
	return dataSize;
}

long HttpClient::getResponseCode(){
	return responseCode;
}

string HttpClient::getResponseHeader(){
	return headerData;
}
