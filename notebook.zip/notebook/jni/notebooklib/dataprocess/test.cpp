#include <stdio.h>
#include <iostream>
#include <fstream>
#include <assert.h>
#include "../edititem.h"
#include "bookinfoxmlcreator.h"
#include "notebookinfoxmlcreator.h"
#include "../bookinfo.h"
#include "bookinfoxmlparser.h"
#include "notebookinfoxmlparser.h"
#include "httpclient.h"
#include "maxidxmlcreator.h"
#include "maxidxmlparser.h"
#include "notebookxmlcreator.h"
#include "bookcommentxmlcreator.h"
#include "../annotation.h"
#include "../textannotation.h"
#include "../hwannotation.h"
#include "../track.h"
#include "../dbookinfo.h"
#include "notebookxmlparser.h"
#include "bookcommentxmlparser.h"
#include "notebookdb.h"
#include "bookcommentdb.h"
#include "../interface/notebookprocess.h"
#include "../interface/bookcommentprocess.h"
#include "base64.h"
#include "../bookprocessfactory.h"
class Test{
public:
	Test();
	~Test();
	void testCreator();
	void testParser();
	void testBookInfoXMLCreator();
	void testNoteBookInfoXMLCreator();
	void testBookInfoXMLParser();
	void testNoteBookInfoXMLParser();
	void testHttpClient();
	void testMaxIdXMLCreator();
	void testMaxIdXMLParser();
	void testNoteBookXMLCreator();
	void testBookCommentXMlCreator();
	void testNoteBookXMLParser();
	void testBookCommentXMLParser();
	void testNoteBookDB();
	void testNoteBookProcess();
	void testBookCommentDB();
	void testBookCommentProcess();
	void testBookProcessFactory();
	char* readFile(string path, int* size);
	void writeFile(const char* stream, int size, string path);
	void overString();
	void testBase64();
	void testBLOB();	
	static size_t writeData(char* ptr, size_t size, size_t nmemb, void *stream);
};

Test::Test(){
}
Test::~Test(){
}
void Test::testCreator(){
	XMLCreator creator;
	XMLElement* rootElement = creator.addRoot("bookcomment");
	XMLElement* bookElement = creator.addChild(rootElement, "book");
	XMLElement* bookIdElement = creator.addChild(bookElement, "bookid");
	bookIdElement->SetText("ABCDEFGHIJK");
	creator.addChildText(bookElement, "bookname", "测试样书");
	creator.saveFile("test_xmlcreator.xml");
	char* xml = creator.getStream();
	cout << __FUNCTION__ << " xml " << xml << endl;
//	creator.getDoc()->Print();
	delete [] xml;
	xml = NULL;
}

void Test::testParser(){
	XMLParser parser;
//	bool success = parser.loadFile("test_xmlcreator.xml");
	int size = 0;
	char* source = readFile("test_xmlcreator.xml", &size); 
	bool success = parser.loadStream(source);
	cout << __FUNCTION__ << " success " << success << endl;
	if(success){
		XMLElement* rootElement = parser.getRootElement();
		XMLElement* bookElement = parser.getChildElement(rootElement, "book");
		const char* bookId = parser.getChildText(bookElement, "bookid");
		const char* bookName = parser.getChildText(bookElement, "bookname");
		cout << "bookId " << bookId << " bookName " << bookName << endl;
	}
	delete [] source;
	source = NULL;
}

void Test::testBookInfoXMLCreator(){
	BookInfo* bookInfo = new BookInfo();
	BookInfoXMLCreator creator;
	bookInfo->setBookId("THISISBOOKID 0");
	bookInfo->setBookName("THISISBOOKNAME 0");
	creator.addBookInfo(bookInfo);
	BookInfo* bookInfo1 = new BookInfo();
	bookInfo1->setBookId("THISISBOOKID 1");
	bookInfo1->setBookName("THISISBOOKNAME 1");
	creator.addBookInfo(bookInfo1);
	BookInfo* bookInfo2 = new BookInfo();
	bookInfo2->setBookId("THISISBOOKID 2");
	bookInfo2->setBookName("THISISBOOKNAME 2");
	creator.addBookInfo(bookInfo2);
	BookInfo* bookInfo3 = new BookInfo();
	bookInfo3->setBookId("THISISBOOKID 3");
	bookInfo3->setBookName("THISISBOOKNAME 3");
	list<BookInfo*> bookInfos;
	bookInfos.push_back(bookInfo);
	bookInfos.push_back(bookInfo1);
	bookInfos.push_back(bookInfo2);
	bookInfos.push_back(bookInfo3);
	creator.addBookInfos(bookInfos);
	creator.saveFile("test_bookinfoxmlcreator.xml");
//	creator.getDoc()->Print();
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it!= bookInfos.end();){
		list<BookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	bookInfos.clear();
}
void Test::testNoteBookInfoXMLCreator(){
	NoteBookInfoXMLCreator creator;
	NoteBookInfo* bookInfo = new NoteBookInfo();
	bookInfo->setBookId("THISISNOTEBOOKID 0");
	bookInfo->setBookName("THISISNOTEBOOKNAME 0");
	const char* thumb0 = "TESTTHUMB 0";
	bookInfo->setThumb(thumb0, strlen(thumb0));
	creator.addBookInfo(bookInfo);
	NoteBookInfo* bookInfo1 = new NoteBookInfo();
	bookInfo1->setBookId("THISISNOTEBOOKID 1");
	bookInfo1->setBookName("THISISNOTEBOOKNAME 1");
	const char* thumb1 = "TESTTHUMB 1";
	bookInfo1->setThumb(thumb1, strlen(thumb1));
	creator.addBookInfo(bookInfo1);
	NoteBookInfo* bookInfo2 = new NoteBookInfo();
	bookInfo2->setBookId("THISISNOTEBOOKID 2");
	bookInfo2->setBookName("THISISNOTEBOOKNAME 2");
	const char* thumb2 = "TESTTHUMB 2";
	bookInfo2->setThumb(thumb2, strlen(thumb2));
	creator.addBookInfo(bookInfo2);
	NoteBookInfo* bookInfo3 = new NoteBookInfo();
	bookInfo3->setBookId("THISISNOTEBOOKID 3");
	bookInfo3->setBookName("THISISNOTEBOOKNAME 3");
	const char* thumb3 = "TESTTHUMB 3";
	bookInfo3->setThumb(thumb3, strlen(thumb3));
	list<BookInfo*> infos;
	infos.push_back(bookInfo);
	infos.push_back(bookInfo1);
	infos.push_back(bookInfo2);
	infos.push_back(bookInfo3);
	creator.addBookInfos(infos);
	creator.saveFile("test_notebookinfoxmlcreator.xml");
//	creator.getDoc()->Print();
	for(list<BookInfo*>::iterator it = infos.begin(); it!= infos.end();){
		list<BookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	infos.clear();
}
void Test::testBookInfoXMLParser(){
	cout << __FUNCTION__ << endl;
	BookInfoXMLParser parser;
	bool success = parser.loadFile("test_bookinfoxmlcreator.xml");
	if(!success)
		return;
	parser.parse();
	list<BookInfo*> bookInfos = parser.getBookInfos();
	cout << __FUNCTION__ << "bookInfos size " << bookInfos.size() << endl;
	list<BookInfo*>::iterator bookInfoIt;
	bookInfoIt = bookInfos.begin();
	while(bookInfoIt!=bookInfos.end()){
		cout << __FUNCTION__ << " bookInfo " << (*bookInfoIt)->toString() << endl;
		bookInfoIt++;
	}
	BookInfoXMLCreator creator;
	creator.addBookInfos(bookInfos);
	creator.saveFile("check_bookinfoxmlparser.xml");
	
}
void Test::testNoteBookInfoXMLParser(){
	cout << __FUNCTION__ << endl;
	NoteBookInfoXMLParser parser;
	bool success = parser.loadFile("test_notebookinfoxmlcreator.xml");
	if(!success)
		return;
	parser.parse();
	list<BookInfo*> bookInfos = parser.getBookInfos();
	cout << __FUNCTION__ << "bookInfos size " << bookInfos.size() << endl;
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it != bookInfos.end(); it++){
		cout << __FUNCTION__ << " it " << (*it)->toString() << endl;
	}
	
	NoteBookInfoXMLCreator creator;
	creator.addBookInfos(bookInfos);
	creator.saveFile("check_notebookinfoxmlparser.xml");
	
}
size_t Test::writeData(char *ptr, size_t size, size_t nmemb, void *stream)
{
  size_t written = fwrite(ptr, size, nmemb, (FILE *)stream);
  return written;
}

void Test::testHttpClient(){
	HttpClient httpClient;

	httpClient.setUserAgent("linux");
	httpClient.addHeader("UserName", "mll");
	httpClient.formAddContent("width", "480");
	httpClient.formAddFile("file", "test_notebookxmlcreator.xml");

	string filename = "test_notebookinfoxmlcreator.xml";
	int size = 0; 
	char* data = readFile(filename, &size);
	//httpClient.formAddFileStream("file_two", filename.c_str(), data, size);
	httpClient.formAddFileStream(filename.c_str(), data, size);
	delete [] data;
	data = NULL;

//	bool result = httpClient.doPost("http://192.168.4.252", "", NULL, NULL);
	
	FILE* file = fopen("testpost.out", "w");
	bool result = httpClient.doPost("http://192.168.4.252", "", NULL, file);
	//bool result = httpClient.doPost("http://192.168.4.252", "", Test::writeData, file);//same with above row 
	if(file){
		fclose(file);
	}
/*
	string outdata;
	bool result = httpClient.doPost("http://192.168.4.99", "", HttpClient::writeCallback, (void*)&outdata);
	cout << __FUNCTION__ << " outdata " << outdata << endl;
*/	
	long responseCode = httpClient.getResponseCode();
	string responseHeader = httpClient.getResponseHeader();
	cout << __FUNCTION__ << " doPost result " << result << " responseCode " << responseCode << " responseHeader " << responseHeader << endl;

}
void Test::testMaxIdXMLCreator(){
	MaxIdXMLCreator creator("notebook", 80);
	creator.saveFile("test_notebookmaxidxmlcreator.xml");
//        creator.getDoc()->Print();
	MaxIdXMLCreator creator2("bookcomment", 100);
	creator2.saveFile("test_bookcommentmaxidxmlcreator.xml");
//        creator2.getDoc()->Print();

}
void Test::testMaxIdXMLParser(){
	MaxIdXMLParser parser;
	bool success = parser.loadFile("test_notebookmaxidxmlcreator.xml");
	if(!success)
		return;
	int maxid = parser.getMaxId();
	MaxIdXMLParser parser2;
	success = parser2.loadFile("test_bookcommentmaxidxmlcreator.xml");
	if(!success)
		return;
	int maxid2 = parser2.getMaxId();
	cout << " maxid " << maxid << " maxid2 " << maxid2 << endl;
}

void Test::testNoteBookXMLCreator(){
	NoteBookXMLCreator creator;
	DNoteBookInfo dInfo;
	dInfo.setBookId("BOOKID");
	dInfo.setBookName("BOOKNAME");
	dInfo.setWidth(1000);
	dInfo.setHeight(1000);
	const char* cover = "TEST COVER";
	dInfo.setCover(cover, strlen(cover));
	const char* background = "TEST BACKGROUND";
	dInfo.setBackground(background, strlen(background));
	creator.addDNoteBookInfo(dInfo);
	NoteEditItem editItem;
	editItem.setOprId(1);
	editItem.setPageId(0);
	editItem.setEditType(WRITE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 9 + j + j;
			point.y = 9 * i * j;
			track.addPoint(point);
		}
		editItem.addTrack(track);
	}
	creator.addEditItem(editItem);
	editItem.setOprId(2);
	editItem.setPageId(1);
	editItem.setEditType(ERASE);
	creator.addEditItem(editItem);
	creator.saveFile("test_notebookxmlcreator.xml");
//        creator.getDoc()->Print();
}
void Test::testBookCommentXMlCreator(){

	DBookInfo dInfo;
	dInfo.setBookId("BOOKID");
	dInfo.setBookName("BOOKNAME");
	dInfo.setWidth(1000);
	dInfo.setHeight(1000);
	BookCommentXMLCreator* creator = new BookCommentXMLCreator("bookcomment");;
	creator->addDBookInfo(creator->getRoot(),dInfo);
	
	list<Annotation*> annotations;
	TextAnnotation* textAnnotation = new TextAnnotation();
	textAnnotation->setOprId(1);
	textAnnotation->setPartId(10);
	textAnnotation->setStartPos(111);
	textAnnotation->setEndPos(1111);
	textAnnotation->setQuote("hello quote");
	textAnnotation->setComment("hello comment");
	annotations.push_back(textAnnotation);
	TextAnnotation* textAnnotation2 = new TextAnnotation();
	textAnnotation2->setOprId(32);
	textAnnotation2->setPartId(110);
	textAnnotation2->setStartPos(1110);
	textAnnotation2->setEndPos(11110);
	textAnnotation2->setQuote("hello quote2");
	textAnnotation2->setComment("hello comment2");
	annotations.push_back(textAnnotation2);
	
	HWAnnotation* hwAnnotation = new HWAnnotation();
	hwAnnotation->setOprId(4);
	hwAnnotation->setPartId(11);	
	hwAnnotation->setStartPos(100);
	hwAnnotation->setEndPos(1000);
	hwAnnotation->setQuote("hello hw  Quota");
	
	hwAnnotation->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 9 +i +j;
			point.y = 10 * j * j;
			track.addPoint(point);
		}
		hwAnnotation->addTrack(track);
	}

	annotations.push_back(hwAnnotation);
	HWAnnotation* hwAnnotation2 = new HWAnnotation();
	hwAnnotation2->setOprId(42);
	hwAnnotation2->setPartId(112);	
	hwAnnotation2->setStartPos(1002);
	hwAnnotation2->setEndPos(10002);
	hwAnnotation2->setQuote("hello hw2  Quota");
	
	hwAnnotation2->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 9 +i +j;
			point.y = 10 * j * j;
			track.addPoint(point);
		}
		hwAnnotation2->addTrack(track);
	}

	annotations.push_back(hwAnnotation2);
	creator->addComments(annotations);
	creator->saveFile("test_bookcommentxmlcreator.xml");
 //       creator.getDoc()->Print();
	for(list<Annotation*>::iterator it = annotations.begin(); it != annotations.end();){
		list<Annotation*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	annotations.clear();
	delete creator;
	creator = NULL;
	
}
void Test::testNoteBookXMLParser(){
	NoteBookXMLParser parser;
	bool success = parser.loadFile("test_notebookxmlcreator.xml");
	if(!success)
		return;
	parser.parse();
	DNoteBookInfo* dInfo = parser.getDNoteBookInfo();
	cout << __FUNCTION__ << " dInfo " << dInfo->toString() << endl;
	list<NoteEditItem*> items = parser.getNoteEditItems();
	cout << __FUNCTION__ << " items.size " << items.size() << endl;
	list<NoteEditItem*>::iterator itemIt;
	itemIt = items.begin();
	while(itemIt!=items.end()){
		cout << __FUNCTION__ << " item " << (*itemIt)->toString().c_str() << endl;
		itemIt++;
	}
/*
	NoteBookXMLCreator creator;
	creator.addDNoteBookInfo(dInfo);
	creator.addEditItems(items);
	creator.saveFile("check_notebookxmlparser.xml");
*/
}
void Test::testBookCommentXMLParser(){
	BookCommentXMLParser parser;
	bool success = parser.loadFile("test_bookcommentxmlcreator.xml");
	if(!success)
		return;
	parser.parse();
	DBookInfo* dInfo = parser.getDBookInfo();
	cout << __FUNCTION__ << " dInfo " << dInfo->toString() << endl;
	list<Annotation*> annotations = parser.getAnnotations();
	cout << __FUNCTION__ << " annotations.size " << annotations.size() << endl;
	list<Annotation*>::iterator annotationIt;
	annotationIt = annotations.begin();
	while(annotationIt!=annotations.end()){
		cout << __FUNCTION__ << " annotation " << (*annotationIt)->toString().c_str() << endl;
		annotationIt++;
	}
/*
	BookCommentXMLCreator creator;
	creator.addDBookInfo(creator.getRoot(),dInfo);
	creator.addComments(annotations);
	creator.saveFile("check_bookcommentxmlparser.xml");
*/
}

void Test::testNoteBookDB(){
	NoteBookDB db("notebook.db");
	DNoteBookInfo* dInfo = new DNoteBookInfo();
	dInfo->setBookId("notebookid");
	dInfo->setBookName("my notebook");
	dInfo->setWidth(1000);
	dInfo->setHeight(1000);
	const char* cover = "COVER";
	int size = 0;
	char* background = readFile("dataprocess/bg0.png", &size);
	cout << __FUNCTION__ << " background size " << strlen(background) << endl;
	dInfo->setCover(cover, strlen(cover));
	dInfo->setBackground(background, size);
	db.addDNoteBookInfo(dInfo);
	delete [] background;
	background = NULL;
	delete dInfo;
	dInfo = NULL;
	DNoteBookInfo *getInfo = db.getDNoteBookInfo("notebookid");
	writeFile(getInfo->getBackground(), getInfo->getBgSize(), "testpng.png");
	cout << __FUNCTION__ << " getInfo " << getInfo->toString() << endl;
	delete getInfo;
	getInfo = NULL;
	list<NoteBookInfo*> infoList = db.getNoteBookInfoList();
	for(list<NoteBookInfo*>::iterator it=infoList.begin();it!=infoList.end();it++){
		cout << __FUNCTION__ << " it " << (*it)->toString() << endl;
	}
	for(list<NoteBookInfo*>::iterator it=infoList.begin();it!=infoList.end();){
		list<NoteBookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	infoList.clear();
	db.addNotePage("notebookid", 0);
	db.addNotePage("notebookid", 1);
	NoteEditItem * item = new NoteEditItem();
	item->setOprId(1);
	item->setPageId(0);
	item->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 9 + j + j;
			point.y = 9 * i * j;
			track.addPoint(point);
		}
		item->addTrack(track);
	}
	db.saveNoteEditItem("notebookid", item);
	delete item;
	item = NULL;
	NoteEditItem* item2 = new NoteEditItem();
	item2->setOprId(2);
	item2->setPageId(1);
	item2->setEditType(ERASE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 92 + j + j;
			point.y = 92 * i * j;
			track.addPoint(point);
		}
		item2->addTrack(track);
	}
	cout <<__FUNCTION__<< " item2 " << item2->toString() << endl;; 
        db.saveNoteEditItem("notebookid", item2);
	delete item2;
	item2 = NULL;
	int localMaxId = db.getLocalMaxOprId("notebookid");
	cout << __FUNCTION__ << " maxId " << localMaxId << endl;
	list<NoteEditItem*> itemList = db.getPageNoteEditItemList("notebookid", 0);
	for(list<NoteEditItem*>::iterator it = itemList.begin(); it != itemList.end(); it++){
		cout << __FUNCTION__ << " item " << (*it)->toString() << endl;
	}
	for(list<NoteEditItem*>::iterator it = itemList.begin(); it != itemList.end();){
		list<NoteEditItem*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	itemList.clear();
	list<NotePage*> pageList = db.getNotePageList("notebookid");
	for(list<NotePage*>::iterator it = pageList.begin(); it != pageList.end(); it++){
		cout << __FUNCTION__ << " page " <<  (*it)->toString() << endl;
		list<Item*> item2List = (*it)->getItems();
		for(list<Item*>::iterator it2 = item2List.begin(); it2 != item2List.end(); it2++){
			cout << __FUNCTION__ << " item 2 " <<(*it2)->toString() << endl;
			NoteEditItem* test = dynamic_cast<NoteEditItem*>(*it2);
			cout << __FUNCTION__ << " test " << test->toString() << endl;
		}
	}
	for(list<NotePage*>::iterator it = pageList.begin(); it!= pageList.end();){
		list<NotePage*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	pageList.clear();

	NoteBookInfoXMLParser parser;
	bool success = parser.loadFile("test_notebookinfoxmlcreator.xml");
	if(!success)
		return;
	parser.parse();
	list<BookInfo*> bookInfos = parser.getBookInfos();
	list<NoteBookInfo*> noteBookInfos;
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it != bookInfos.end(); it++){
		NoteBookInfo* ni = dynamic_cast<NoteBookInfo*>(*it);
		noteBookInfos.push_back(ni);
	}
	db.saveNoteBookInfoList(noteBookInfos);
	cout << __FUNCTION__ << "  db.saveNoteBookInfoList size " << noteBookInfos.size() << endl;
	db.saveNoteBookInfoList(noteBookInfos);
	cout << __FUNCTION__ << "  db.saveNoteBookInfoList size " << noteBookInfos.size() << endl;

	NoteBookXMLParser bookParser;
	success = bookParser.loadFile("test_notebookxmlcreator.xml");
	if(!success)
		return;
	bookParser.parse();
	DNoteBookInfo* dNoteInfo = bookParser.getDNoteBookInfo();
	db.addDNoteBookInfo(dNoteInfo);
	list<NoteEditItem*> items = bookParser.getNoteEditItems();
	db.saveNoteEditItemList(dNoteInfo->getBookId(), items);
	list<NoteEditItem*> noteItemList = db.getNoteEditItemList(dNoteInfo->getBookId(), 0);
	for(list<NoteEditItem*>::iterator it = noteItemList.begin(); it!=noteItemList.end(); it++){
		cout << __FUNCTION__ << " noteitem " << (*it)->toString() << endl;
	}	
	for(list<NoteEditItem*>::iterator it = noteItemList.begin(); it!=noteItemList.end();){
		list<NoteEditItem*>::iterator it2 = it;
		it++;
		delete *it2;
	}	
	noteItemList.clear();
	db.closeDB();
}
void Test::testNoteBookProcess(){
	NoteBookProcess process;
	process.setStorageFilePath("process.db");
	DNoteBookInfo* dInfo = new DNoteBookInfo();
	dInfo->setBookName("processbookname");
	dInfo->setBookId("processbookid");
	dInfo->setWidth(1000);
	dInfo->setHeight(1000);
	string cover = "processcover";
	dInfo->setCover(cover.c_str(), cover.size());
	string background = "processbackground";
	dInfo->setBackground(background.c_str(), background.size());
        process.addDNoteBookInfo(dInfo);
	delete dInfo;
	dInfo = NULL;
        DNoteBookInfo *dNoteBookInfo = process.getDNoteBookInfo("processbookid");
	cout << __FUNCTION__ << " dNoteBookInfo "<< dNoteBookInfo->toString() << endl;
	delete dNoteBookInfo;
	dNoteBookInfo = NULL;
        process.addNotePage("processbookid", 0);
	NoteEditItem* item = new NoteEditItem();
	item->setOprId(1);
	item->setPageId(0);
	item->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 9 + j + j;
			point.y = 9 * i * j;
			track.addPoint(point);
		}
		item->addTrack(track);
	}
        process.saveNoteEditItem("processbookid", item);
	cout <<__FUNCTION__<< " item " << item->toString() << endl;; 
	delete item;
	item = NULL;
        process.addNotePage("processbookid", 1);
       	NoteEditItem* item2 = new NoteEditItem();
	item2->setOprId(2);
	item2->setPageId(1);
	item2->setEditType(ERASE);
	for(int j = 2; j < 10; j++){
		Track track;
		track.setPenWidth(j);
		for(int i = 0; i < 10; i++){
			Point point;
			point.x = 92 + j + j;
			point.y = 92 * i * j;
			track.addPoint(point);
		}
		item2->addTrack(track);
	}
	cout <<__FUNCTION__<< " item2 " << item2->toString() << endl;; 
        process.saveNoteEditItem("processbookid", item2);
	delete item2;
	item2 = NULL;
	list<NoteBookInfo*> noteBookInfoList = process.getNoteBookInfoList();
	for(list<NoteBookInfo*>::iterator it = noteBookInfoList.begin(); it != noteBookInfoList.end(); it++){
		cout << __FUNCTION__ << " process.getNoteBookInfoList it " << (*it)->toString() << endl;
	}
	for(list<NoteBookInfo*>::iterator it = noteBookInfoList.begin(); it != noteBookInfoList.end();){
		list<NoteBookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	noteBookInfoList.clear();
        int localMaxOprId = process.getLocalMaxOprId("processbookid");
	cout << __FUNCTION__ << " localMaxOprId " << localMaxOprId << endl;
        list<NotePage*> pageList = process.getNotePageList("processbookid");
	for(list<NotePage*>::iterator it = pageList.begin(); it != pageList.end(); it++){
		cout << __FUNCTION__ << " process.getNotePageList it " << (*it)->toString() << endl;
		list<Item*> item2List = (*it)->getItems();
		for(list<Item*>::iterator it2 = item2List.begin(); it2 != item2List.end(); it2++){
			cout << __FUNCTION__ << " item 2 " <<(*it2)->toString() << endl;
			NoteEditItem* test = dynamic_cast<NoteEditItem*>(*it2);
			cout << __FUNCTION__ << " test " << test->toString() << endl;
		}
	}
	for(list<NotePage*>::iterator it = pageList.begin(); it != pageList.end();){
		list<NotePage*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	pageList.clear();
	process.closeDB();
}
void Test::testBookCommentDB(){
	BookCommentDB db("bookcomment.db");
	DBookInfo* dInfo = new DBookInfo();
	dInfo->setBookName("bookcommentbookname");
	dInfo->setBookId("bookcommentbookid");
	dInfo->setWidth(1200);
	dInfo->setHeight(1200);
        db.addDBookInfo(dInfo);
	delete dInfo;
	dInfo = NULL;
        DBookInfo* dInfo2 = db.getDBookInfo("bookcommentbookid");
	cout << __FUNCTION__ << " dInfo2 " << dInfo2->toString() << endl;
	delete dInfo2;
	dInfo2 = NULL;
	TextAnnotation* ta = new TextAnnotation();
	ta->setOprId(1);
	ta->setPartId(1);
	ta->setStartPos(1);
	ta->setEndPos(1);
	ta->setQuote("text quote");
	ta->setComment("text comment");
	HWAnnotation* hwa = new HWAnnotation();
	hwa->setOprId(2);
	hwa->setPartId(2);
	hwa->setStartPos(2);
	hwa->setEndPos(2);
	hwa->setQuote("hw quote");
        db.saveAnnotation("bookcommentbookid", ta);
	delete ta;
	ta = NULL;
	EditItem* item = new EditItem();
	item->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
                Track track;
                track.setPenWidth(j);
                for(int i = 0; i < 10; i++){
                        Point point;
                        point.x = 9 + j + j;
                        point.y = 9 * i * j;
                        track.addPoint(point);
                }
                item->addTrack(track);
        }
	hwa->setEditItem(*item);
	delete item;
	item = NULL;
	db.saveAnnotation("bookcommentbookid", hwa);
	delete hwa;
	hwa = NULL;
	int maxOprId = db.getLocalMaxOprId("bookcommentbookid");
	cout << __FUNCTION__ << " maxOprId " << maxOprId <<  endl;
        list<Annotation*> as = db.getAnnotationList("bookcommentbookid");
	for(list<Annotation*>::iterator it = as.begin(); it != as.end(); it++){
		cout << __FUNCTION__ << " annotation " << (*it)->toString() <<  endl;
	}
	for(list<Annotation*>::iterator it = as.begin(); it != as.end(); ){
		cout << __FUNCTION__ << " annotation " << (*it)->toString() <<  endl;
		list<Annotation*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	as.clear();
        list<Annotation*> aps = db.getPartAnnotationList("bookcommentbookid", 2);
	for(list<Annotation*>::iterator it = aps.begin(); it != aps.end(); it++){
		cout << __FUNCTION__ << " annotation part " << (*it)->toString() <<  endl;
	}
	for(list<Annotation*>::iterator it = aps.begin(); it != aps.end();){
		list<Annotation*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	aps.clear();
        list<Annotation*> ams = db.getAnnotationList("bookcommentbookid", 0);
	for(list<Annotation*>::iterator it = ams.begin(); it != ams.end(); it++){
		cout << __FUNCTION__ << " annotation to server " << (*it)->toString() <<  endl;
	}
	for(list<Annotation*>::iterator it = ams.begin(); it != ams.end();){
		list<Annotation*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	ams.clear();

	BookInfoXMLParser parser;
	parser.loadFile("test_bookinfoxmlcreator.xml");
	parser.parse();
	list<BookInfo*> infos = parser.getBookInfos();
	cout <<__FUNCTION__<< " infos size " <<  infos.size() << endl;
        db.saveBookInfoList(infos);

	BookCommentXMLParser parser2;
	parser2.loadFile("test_bookcommentxmlcreator.xml");
	parser2.parse();
	DBookInfo* info = parser2.getDBookInfo();
        cout << __FUNCTION__ << " info " << info->toString() << endl;
	db.addDBookInfo(info);
	list<Annotation*> annotations = parser2.getAnnotations();
        db.saveAnnotationList(info->getBookId(), annotations);
        
	
	list<BookInfo*> bookInfos = db.getBookInfoList();
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it != bookInfos.end(); it++){
		cout << __FUNCTION__ << " bookInfo " << (*it)->toString() <<  endl;
	}
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it != bookInfos.end(); ){
		list<BookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	bookInfos.clear();

	db.closeDB();	
}
void Test::testBookCommentProcess(){
	BookCommentProcess process;
	
	process.setStorageFilePath("bookcommentprocess.db");
	DBookInfo* info = new DBookInfo();
	info->setBookName("bookcommentname");
	info->setBookId("bookcommentid");
	info->setWidth(1000);
	info->setHeight(1000);
	process.addDBookInfo(info);
	delete info;
	info = NULL;
	DBookInfo* dInfo = process.getDBookInfo("bookcommentid");
	cout << __FUNCTION__ <<  " dInfo " << dInfo->toString() << endl;
	delete dInfo;
	dInfo = NULL;	
	list<BookInfo*> infos = process.getBookInfoList();
	for(list<BookInfo*>::iterator it = infos.begin(); it != infos.end(); it++){
		cout << __FUNCTION__ <<  " getBookInfoList it  " << (*it)->toString() << endl;
	}
	for(list<BookInfo*>::iterator it = infos.begin(); it != infos.end(); ){
		list<BookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	infos.clear();

	TextAnnotation* ta = new TextAnnotation();
	ta->setOprId(1);
	ta->setPartId(1);
	ta->setStartPos(1);
	ta->setEndPos(1);
	ta->setQuote("text quote");
	ta->setComment("text comment");
	HWAnnotation* hwa = new HWAnnotation();
	hwa->setOprId(2);
	hwa->setPartId(2);
	hwa->setStartPos(2);
	hwa->setEndPos(2);
	hwa->setQuote("hw quote");
        process.saveAnnotation("bookcommentid", ta);
	delete ta;
	ta = NULL;
	EditItem* item = new EditItem();
	item->setEditType(WRITE);
	for(int j = 2; j < 10; j++){
                Track track;
                track.setPenWidth(j);
                for(int i = 0; i < 10; i++){
                        Point point;
                        point.x = 9 + j + j;
                        point.y = 9 * i * j;
                        track.addPoint(point);
                }
                item->addTrack(track);
        }
	hwa->setEditItem(*item);
	process.saveAnnotation("bookcommentid", hwa);
	delete item;
	item = NULL;
	delete hwa;
	hwa = NULL;
	int maxId = process.getLocalMaxOprId("bookcommentid");
	cout << __FUNCTION__ << " maxId " << maxId << endl;

	list<Annotation*> pas = process.getPartAnnotationList("bookcommentid", 2);
	for(list<Annotation*>::iterator pasit = pas.begin(); pasit != pas.end(); pasit++){
		cout << __FUNCTION__ << " pas it " << (*pasit)->toString() << endl;
	}
	for(list<Annotation*>::iterator pasit = pas.begin(); pasit != pas.end();){
		list<Annotation*>::iterator it2 = pasit;
		pasit++;
		delete *it2;
	}
	pas.clear();
	list<Annotation*> as = process.getAnnotationList("bookcommentid");
	for(list<Annotation*>::iterator asit = as.begin(); asit != as.end(); asit++){
		cout << __FUNCTION__ << " as it " << (*asit)->toString() << endl;
	}
	for(list<Annotation*>::iterator asit = as.begin(); asit != as.end(); ){
		list<Annotation*>::iterator it2 = asit;
		asit++;
		delete *it2;
	}
	as.clear();
	process.closeDB();
}
void Test::testBookProcessFactory(){
	IBookCommentProcess* bookCommentProcess = BookProcessFactory::createBookCommentProcess();
	bookCommentProcess->setStorageFilePath("ibookcommentprocess.db");
	INoteBookProcess* noteBookProcess = BookProcessFactory::createNoteBookProcess(false);	
	noteBookProcess->setStorageFilePath("inotebookprocess.db");
	bookCommentProcess->closeDB();
	noteBookProcess->closeDB();	
	delete bookCommentProcess;
	bookCommentProcess = NULL;
	delete noteBookProcess;
	noteBookProcess = NULL;
}
char* Test::readFile(string path, int* size){
	ifstream ifle(path.c_str());
	string s;
	while (!ifle.eof()){
		char c = ifle.get();
		if(ifle.fail()) {
                	break;
          	}
		 s.push_back(c);
	}
	// Must add an \0 at the end otherwise tinyxml2 will return error when parse xml stream
	size_t len = s.size();
	char* charBuffer = new char[len+1];
	memcpy(charBuffer, s.c_str(), len);
	charBuffer[len] = '\0';
	*size = len;
	return charBuffer;
}

void Test::writeFile(const char* stream, int size, string path){
	ofstream of(path.c_str());
	of.write(stream, size);
	of.close();
}
void Test::overString(){
	string str = "hellotest";
	str.append("\0");
	str.append(1,'\0');
	str.append("helloagain");
	cout << __FUNCTION__ << " str " << str << " str len " << str.length()<< endl;
	cout << __FUNCTION__ << " str c_str " << str.c_str() << endl;
	cout << __FUNCTION__ << " str data " << str.data() << endl;

}

void Test::testBase64(){
	char* input = (char*)"hellotest\0helloagain";
	
	for(int i = 0 ; i < 20; i++){
		cout << __FUNCTION__ << " input i " << input[i] << endl;
	}
	int size = 0;
	char* encode = new char[40];
	memset(encode, 0, 40);
	Base64::encode(input, 20, encode, &size);
	cout << __FUNCTION__  << " encode size " << size <<  endl;	
	for(int i = 0 ; i < size; i++){
		cout << __FUNCTION__ << " encode i " << encode[i] << endl;
	}
	int dsize = 0;
	char* decode = new char[size];
	memset(decode, 0, size);
	Base64::decode(encode, size, decode, &dsize);
	cout << __FUNCTION__ << " decode size " << dsize <<  endl;	
	for(int i = 0 ; i < dsize; i++){
		cout << __FUNCTION__ << " decode i " << decode[i] << endl;
	}
	delete [] encode;
	delete [] decode;
	encode = NULL;
	decode = NULL;
	size = 0;
	char* source = readFile("dataprocess/bg0.png", &size);
	int len = 0;
	encode = new char[size*2];
	memset(encode, 0, size*2);
	Base64::encode(source, size, encode, &len);
	int dlen = 0;
	decode = new char[len];
	memset(decode, 0, len);
	Base64::decode(encode, len, decode, &dlen);
	writeFile(decode, dlen, "b64.png");
	delete [] encode;
	delete [] decode;
	encode = NULL;
	decode = NULL;
	delete [] source;
	source = NULL;
}
void Test::testBLOB(){
	NoteBookDB db("notebook.db");
	int size = 0;

	char* cover = readFile("dataprocess/bg0.png", &size);
	db.updateBLOB("insert into notebook(notebookid, cover) values(\'notebookblobid\', ?);", cover, size);
	delete [] cover;
	cover = NULL;
	/*char* cover = new char[100];
	cover = "asklkdfsjfklsfjlsdfs;\0ksldjfslkfslfkdslfskdjl";
	size = 100;
	db.updateBLOB("update notebook set cover = ? where notebookid=\'notebookblobid\';", cover, size);*/
	cout << __FUNCTION__ << " size " << size << endl;
	int len = 0;
	char* blob;
	db.getBLOB("select cover from notebook where notebookid=\'notebookblobid\';", &blob, &len);
	cout << __FUNCTION__ << " len " << len << endl;
	writeFile(blob, len, "db.png");
	delete [] blob;
	blob = NULL;
/*
	char* test = new char[100];
	strncpy(test, blob, 100);
	db.printHex(test, 100);
*/
	db.closeDB();
}
int main(){
	Test test;
	test.testCreator();
	test.testParser();
	test.testBookInfoXMLCreator();
	test.testNoteBookInfoXMLCreator();
	test.testBookInfoXMLParser();
	test.testNoteBookInfoXMLParser();
	test.testHttpClient();
	test.testMaxIdXMLCreator();
	test.testMaxIdXMLParser();
	test.testNoteBookXMLCreator();
	test.testBookCommentXMlCreator();
	test.testNoteBookXMLParser();
	test.testBookCommentXMLParser();
	test.testNoteBookDB();
	test.testNoteBookProcess();
	test.testBookCommentDB();
	test.testBookCommentProcess();
	test.testBookProcessFactory();
	test.overString();
	test.testBase64();
	test.testBLOB();
	return 1;
}
