#include "bookcommentdb.h"
#include <stdio.h>
#include <iostream>
#include "../textannotation.h"
#include "../hwannotation.h"
#define BUF_SIZE 128
BookCommentDB::BookCommentDB(string path):BaseDB(path){
	createDB();
}
BookCommentDB::~BookCommentDB(){
}
void BookCommentDB::createDB(){
	string sql;
	sql = "CREATE TABLE IF NOT EXISTS book(id INTEGER PRIMARY key AUTOINCREMENT, bookid TEXT UNIQUE, bookname TEXT, pagewidth INTEGER, pageheight INTEGER);";
	db.executeUpdate(sql);
	sql = "CREATE TABLE IF NOT EXISTS quote(id INTEGER PRIMARY key AUTOINCREMENT, book_idx INTEGER NOT NULL REFERENCES book(id), opr_idx INTEGER, partid INTEGER, startpos INTEGER, endpos INTEGER, quote TEXT, type TEXT);";
	db.executeUpdate(sql);
	sql = "CREATE TABLE IF NOT EXISTS comment(id INTEGER PRIMARY key AUTOINCREMENT, quote_idx INTEGER NOT NULL REFERENCES quote(id), comment TEXT);";
	db.executeUpdate(sql);
	sql = "CREATE TABLE IF NOT EXISTS edititem(id INTEGER PRIMARY key AUTOINCREMENT, quote_idx INTEGER NOT NULL REFERENCES quote(id), edittype INTEGER);";
	db.executeUpdate(sql);
	sql = "CREATE TABLE IF NOT EXISTS track(id INTEGER PRIMARY key AUTOINCREMENT, edititem_idx INTEGER NOT NULL REFERENCES edititem(id), penwidth INTEGER);";
	db.executeUpdate(sql);
	sql = "CREATE TABLE IF NOT EXISTS point(id INTEGER PRIMARY key AUTOINCREMENT, track_idx INTEGER NOT NULL REFERENCES track(id), pointx INTEGER, pointy INTEGER);";
	db.executeUpdate(sql);
}

void BookCommentDB::addDBookInfo(DBookInfo* bookInfo){
	char pageWidthStr[BUF_SIZE];
	memset(pageWidthStr, 0, BUF_SIZE);
	sprintf(pageWidthStr, "%d", bookInfo->getWidth());
	char pageHeightStr[BUF_SIZE];
	memset(pageHeightStr, 0, BUF_SIZE);
	sprintf(pageHeightStr, "%d", bookInfo->getHeight());
	cout << __FUNCTION__ << " bookid " << bookInfo->getBookId();
	string sql;
	sql = "select id from book where bookid=\'" + bookInfo->getBookId() + "\';";
	cout << __FUNCTION__ << " sql  " << sql << endl;
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size()==0){
		sql = "insert into book(bookid, bookname, pagewidth, pageheight) values(\'" + bookInfo->getBookId() + "\',\'" + bookInfo->getBookName() + "\'," + string(pageWidthStr) + "," + string(pageHeightStr) + ");";
	}else{
		sql = "update book set bookname=\'" + bookInfo->getBookName() + "\', pagewidth=" + string(pageWidthStr) + ", pageheight=" + string(pageHeightStr) + " where bookid=\'" + bookInfo->getBookId() + "\' ;";
	}
	cout << __FUNCTION__ << " sql  " << sql << endl;
	db.executeUpdate(sql);
}

DBookInfo* BookCommentDB::getDBookInfo(string bookid){
	DBookInfo* info = new DBookInfo();
	info->setBookId(bookid);
	string sql = "select * from book where bookid=\'" + bookid + "\';";
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size()!=0){
		ResultList::iterator it = resultList.begin();
		FieldsMap fm = *it;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="bookname"){
				info->setBookName(fit->second);
			}
			if(fit->first=="pagewidth"){
				string pageWidthStr = fit->second;
				int pageWidth = static_cast<int>(strtol(pageWidthStr.c_str(), NULL, 10));
				info->setWidth(pageWidth);
			}
			if(fit->first=="pageheight"){
				string pageHeightStr = fit->second;
				int pageHeight = static_cast<int>(strtol(pageHeightStr.c_str(), NULL, 10));
				info->setHeight(pageHeight);
			}
		}
	}
		
	return info;
}

list<BookInfo*> BookCommentDB::getBookInfoList(){
	list<BookInfo*> infoList;
	string sql = "select * from book;";
	ResultList resultList = db.executeQuery(sql);
	for(ResultList::iterator it = resultList.begin(); it != resultList.end(); it++){
		BookInfo* info = new BookInfo();
		FieldsMap fm = *it;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="bookid"){
				info->setBookId(fit->second);
			}
			if(fit->first=="bookname"){
				info->setBookName(fit->second);
			}
		}
		infoList.push_back(info);	
	}
	return infoList;
}

list<Annotation*> BookCommentDB::getAnnotationList(string bookid){
	list<Annotation*> annotationList;
	string sql = "select partid from quote where book_idx in(select id from book where bookid=\'" + bookid +"\');";
	ResultList resultList = db.executeQuery(sql);
	list<int> partIdList;
	for(ResultList::iterator it = resultList.begin(); it != resultList.end(); it++){
		FieldsMap fm = *it;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="partid"){
				string partIdStr = fit->second;
				int partId = static_cast<int>(strtol(partIdStr.c_str(), NULL, 10));
				partIdList.push_back(partId);
			}
		}
	}
	for(list<int>::iterator it = partIdList.begin(); it != partIdList.end(); it++){
		list<Annotation*> partList = getPartAnnotationList(bookid, *it);
		for(list<Annotation*>::iterator ait = partList.begin(); ait != partList.end(); ait++){
			annotationList.push_back(*ait);
		}
	}
	return annotationList;
}

list<Annotation*> BookCommentDB::getPartAnnotationList(string bookid, int partid){
	char partIdStr[BUF_SIZE];
	memset(partIdStr, 0, BUF_SIZE);
	sprintf(partIdStr, "%d", partid);
	string sql = "select * from quote where book_idx in(select id from book where bookid=\'"+bookid+"\') and partid="+ string(partIdStr) +";";
	return queryAnnotationList(sql);
}

void BookCommentDB::saveAnnotation(string bookid, Annotation* annotation){
	string sql = "select id from book where bookid=\'" + bookid + "\';";
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size()!=0){
		ResultList::iterator it = resultList.begin();
		FieldsMap fm = *it;
		int bookIdx = 0;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="id"){
				string bookIdStr = fit->second;
				bookIdx = static_cast<int>(strtol(bookIdStr.c_str(), NULL, 10));
			}
		}
		char bookIdxStr[BUF_SIZE];
		memset(bookIdxStr, 0, BUF_SIZE);
		sprintf(bookIdxStr, "%d", bookIdx);
		char oprIdxStr[BUF_SIZE];
		memset(oprIdxStr, 0, BUF_SIZE);
		sprintf(oprIdxStr, "%d", annotation->getOprId());
		char partIdStr[BUF_SIZE];
		memset(partIdStr, 0, BUF_SIZE);
		sprintf(partIdStr, "%d", annotation->getPartId());
		char startPosStr[BUF_SIZE];
		memset(startPosStr, 0, BUF_SIZE);
		sprintf(startPosStr, "%d", annotation->getStartPos());
		char endPosStr[BUF_SIZE];
		memset(endPosStr, 0, BUF_SIZE);
		sprintf(endPosStr, "%d", annotation->getEndPos());
		string quote = annotation->getQuote();
		char typeStr[BUF_SIZE];
		memset(typeStr, 0, BUF_SIZE);
		sprintf(typeStr, "%d", annotation->getAnnotationType());
		sql = "insert into quote(book_idx, opr_idx, partid, startpos, endpos, quote, type) values("+string(bookIdxStr)+ ", " + string(oprIdxStr) +", " 
			+ string(partIdStr) + ", " + string(startPosStr) + ", " + string(endPosStr) + ", \'" + quote + "\', " +string(typeStr) +");";
		cout << __FUNCTION__ << " sql  " << sql << endl;
		db.executeUpdate(sql);
		sql = "select max(id) as maxId from quote;";
		resultList = db.executeQuery(sql);
		if(resultList.size() != 0){
			ResultList::iterator rit = resultList.begin();
			FieldsMap idfm = *rit;
			for(FieldsMap::iterator fit = idfm.begin(); fit != idfm.end(); fit++){
				if(fit->first=="maxId"){
					string quoteIdxStr = fit->second;
					int quoteIdx = str2Int(quoteIdxStr);
					switch(annotation->getAnnotationType()){
						case TEXT:{
							TextAnnotation* ta = dynamic_cast<TextAnnotation*>(annotation);
							if(ta!=NULL){
								saveText(quoteIdx, ta->getComment());
							}	
						  	}
							break;
						case HANDWRITE:{
							EditItem* item = dynamic_cast<EditItem*>(annotation);
							saveHWAnnotation(quoteIdx, item);
						       	}
						       	break;
						default:
						       break;
					}

				}
			}
		}
	}
}
void BookCommentDB::saveText(int quoteIdx, string comment){
	char quoteIdxStr[BUF_SIZE];
	memset(quoteIdxStr, 0, BUF_SIZE);
	sprintf(quoteIdxStr, "%d", quoteIdx);
	string sql = "insert into comment(quote_idx, comment) values(" + string(quoteIdxStr) + ", \'" + comment + "\');";
	db.executeUpdate(sql);
}
void BookCommentDB::saveHWAnnotation(int quoteIdx, EditItem* item){
	db.beginTransaction();
	char quoteIdxStr[BUF_SIZE];
	memset(quoteIdxStr, 0, BUF_SIZE);
	sprintf(quoteIdxStr, "%d", quoteIdx);
	char typeStr[BUF_SIZE];
	memset(typeStr, 0, BUF_SIZE);
	sprintf(typeStr, "%d", item->getEditType());
	string sql = "insert into edititem(quote_idx, edittype) values(" + string(quoteIdxStr) + ", " + string(typeStr) + ");";
	db.executeUpdate(sql);
	list<Track> tracks = item->getTracks();
	if(tracks.size() == 0)
		return;
	sql = "select max(id) as maxId from edititem;";
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size() != 0){
		ResultList::iterator rit = resultList.begin();
		FieldsMap idfm = *rit;
		for(FieldsMap::iterator fit = idfm.begin(); fit != idfm.end(); fit++){
			if(fit->first=="maxId"){
				string itemIdxStr = fit->second;
				int itemIdx = str2Int(itemIdxStr);
				saveTracks(itemIdx, tracks);
			}
		}
	}
	db.endTransaction();

}
int BookCommentDB::getLocalMaxOprId(string bookid){
	string sql = "select max(opr_idx) as maxId from quote where book_idx in(select id from book where bookid=\'"+bookid+"\');";
        ResultList oprList = db.executeQuery(sql);
        if(oprList.size() == 0){
                return 0;
        }
        FieldsMap fm = *(oprList.begin());
        string oprStr;
        for(FieldsMap::iterator it = fm.begin(); it != fm.end(); it++){
                if(it->first == "maxId")
                        oprStr = it->second;
        }
        return static_cast<int>(strtol(oprStr.c_str(), NULL, 10));
}

void BookCommentDB::saveBookInfoList(list<BookInfo*> infoList){
	for(list<BookInfo*>::iterator it = infoList.begin(); it != infoList.end(); it++){
		saveBookInfo(*it);
	}	
}
void BookCommentDB::saveBookInfo(BookInfo* info){
	string sql;
	sql = "select id from book where bookid=\'" + info->getBookId() + "\';";
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size()==0){
		sql = "insert into book(bookid, bookname) values(\'" + info->getBookId() + "\',\'" + info->getBookName() + "\');";
	}else{
		sql = "update book set bookname=\'" + info->getBookName() + "\' where  bookid=\'" + info->getBookId() + "\';";
	}
	cout << __FUNCTION__ << " sql  " << sql << endl;
	db.executeUpdate(sql);

}

void BookCommentDB::saveAnnotationList(string bookid, list<Annotation*> annotationList){
	for(list<Annotation*>::iterator it = annotationList.begin(); it != annotationList.end(); it++){
		saveAnnotation(bookid, *it);
	}
}

list<Annotation*> BookCommentDB::getAnnotationList(string bookid, int serverMaxId){
	char serverMaxIdStr[BUF_SIZE];
	memset(serverMaxIdStr, 0 , BUF_SIZE);
	sprintf(serverMaxIdStr, "%d", serverMaxId);
	string sql = "select * from quote where  opr_idx > " + string(serverMaxIdStr) + " and book_idx in(select id from book where bookid=\'" + bookid +"\');";
	return queryAnnotationList(sql);
}

list<Annotation*> BookCommentDB::queryAnnotationList(string sql){
	list<Annotation*> annotationList;
	ResultList resultList = db.executeQuery(sql);
	for(ResultList::iterator it = resultList.begin(); it != resultList.end(); it++){
		FieldsMap fm = *it;
		int quoteIdx = 0;
		int partId = 0;
		int startPos = 0;
		int endPos = 0;
		int oprIdx = 0;
		string quote="";
		AnnotationType annotationType = TEXT;

		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
						if(fit->first=="id"){
				string quoteIdxStr = fit->second;
				quoteIdx = static_cast<int>(strtol(quoteIdxStr.c_str(), NULL, 10));
			}
			if(fit->first=="partid"){
				string partIdStr = fit->second;
				partId = static_cast<int>(strtol(partIdStr.c_str(), NULL, 10));
			}
			if(fit->first=="startpos"){
				string startPosStr = fit->second;
				startPos = static_cast<int>(strtol(startPosStr.c_str(), NULL, 10));
			}
			if(fit->first=="endpos"){
				string endPosStr = fit->second;
				endPos = static_cast<int>(strtol(endPosStr.c_str(), NULL, 10));
			}
			if(fit->first=="ort_idx"){
				string oprIdxStr = fit->second;
				oprIdx = static_cast<int>(strtol(oprIdxStr.c_str(), NULL, 10));
			}
			if(fit->first=="quote"){
				quote = fit->second;
			}
			if(fit->first=="type"){
				string typeStr = fit->second;
				int type = static_cast<int>(strtol(typeStr.c_str(), NULL, 10));
				annotationType = static_cast<AnnotationType>(type);
			}
		}
		switch(annotationType){
			case TEXT:{
				TextAnnotation* ta = new TextAnnotation();
				ta->setPartId(partId);
				ta->setStartPos(startPos);
				ta->setEndPos(endPos);
				ta->setOprId(oprIdx);
				ta->setQuote(quote);
				ta->setComment(getComment(quoteIdx));
				annotationList.push_back(ta);
			}
				break;
			case HANDWRITE:{
				HWAnnotation* hwa = new HWAnnotation();
				hwa->setPartId(partId);
				hwa->setStartPos(startPos);
				hwa->setEndPos(endPos);
				hwa->setOprId(oprIdx);
				hwa->setQuote(quote);
				EditItem* item = getEditItem(quoteIdx);
				hwa->setEditItem(*item);
				delete item;
				item = NULL;
				annotationList.push_back(hwa);
			}
				break;
			default:
				break;
		}
	}
	return annotationList;
}

string BookCommentDB::getComment(int quoteidx){
	string comment="";
	char quoteIdxStr[BUF_SIZE];
	memset(quoteIdxStr, 0, BUF_SIZE);
	sprintf(quoteIdxStr, "%d", quoteidx);
	string sql = "select comment from comment where quote_idx=" + string(quoteIdxStr) + ";";
	ResultList resultList = db.executeQuery(sql);
	if(resultList.size()!=0){
		ResultList::iterator it = resultList.begin();
		FieldsMap fm = *it;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="comment"){
				comment = fit->second;
			}
		}
	}
	return comment;
}

EditItem* BookCommentDB::getEditItem(int quoteidx){
	db.beginTransaction();
	EditItem* editItem = new EditItem();
	char quoteIdxStr[BUF_SIZE];
	memset(quoteIdxStr, 0, BUF_SIZE);
	sprintf(quoteIdxStr, "%d", quoteidx);
	string sql = "select * from edititem where quote_idx=" + string(quoteIdxStr) + ";";
	ResultList resultList = db.executeQuery(sql);	
	if(resultList.size()!=0){
		ResultList::iterator it = resultList.begin();
		FieldsMap fm = *it;
		for(FieldsMap::iterator fit = fm.begin(); fit != fm.end(); fit++){
			if(fit->first=="id"){
				string editIdxStr = fit->second;
				int editIdx = static_cast<int>(strtol(editIdxStr.c_str(), NULL, 10));
				list<Track*> tracks = getTracks(editIdx);
				editItem->addTracks(tracks);
				for(list<Track*>::iterator it = tracks.begin(); it != tracks.end(); ){
					list<Track*>::iterator it2 = it;
					it++;
					delete *it2;
				}
				tracks.clear();
			}
			if(fit->first=="edittype"){
				string editTypeStr = fit->second;
				int type = static_cast<int>(strtol(editTypeStr.c_str(), NULL, 10));
				EditType editType = static_cast<EditType>(type);
				editItem->setEditType(editType);
			}
		}
	}
	db.endTransaction();
	return editItem;
}
