#include "bookinfoxmlparser.h"
#include <iostream>
#include <string>

BookInfoXMLParser::BookInfoXMLParser(){
}
BookInfoXMLParser::~BookInfoXMLParser(){
	for(list<BookInfo*>::iterator it = bookInfos.begin(); it != bookInfos.end();){
		list<BookInfo*>::iterator it2= it;
		it++;
		delete *it2;
	}
	bookInfos.clear();
}
void BookInfoXMLParser::parse(){
	XMLElement* rootElement = getRootElement();
	XMLElement* booksElement = getChildElement(rootElement, "books"); 
	XMLElement* bookElement = getChildElement(booksElement,"book");
	while( bookElement != NULL){
		BookInfo* bookInfo = parseBookInfo(bookElement);
		bookInfos.push_back(bookInfo);
		bookElement = getNextElement(bookElement, "book");
	}
}
BookInfo* BookInfoXMLParser::parseBookInfo(XMLElement* bookElement){
//	cout << __FUNCTION__ << " " << __FILE__ << endl;
	BookInfo* bookInfo = new BookInfo();
	string bookId = getChildText(bookElement, "bookid");
	string bookName = getChildText(bookElement, "bookname");
	bookInfo->setBookId(bookId);
	bookInfo->setBookName(bookName);
	return bookInfo;
	
}
list<BookInfo*> BookInfoXMLParser::getBookInfos(){
	return bookInfos;
}
