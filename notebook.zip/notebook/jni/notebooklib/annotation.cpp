#include "annotation.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
Annotation::Annotation()
{
    partId = 0;
    startPos = 0;
    endPos = 0;
    quote = "";
    annotationType = TEXT;

}

Annotation::~Annotation()
{
}

void Annotation::setPartId(int id)
{
	partId = id;
}
int Annotation::getPartId() const
{
	return partId;
}

void Annotation::setStartPos(int pos)
{
	startPos = pos;
}
int Annotation::getStartPos() const
{
	return startPos;
}

void Annotation::setEndPos(int pos)
{
	endPos= pos;
}
int Annotation::getEndPos() const
{
	return endPos;
}

void Annotation::setQuote(string quo)
{
	quote = quo;
}
string Annotation::getQuote() const
{
	return quote;
}

void Annotation::setAnnotationType(AnnotationType type)
{
	annotationType = type;
}
AnnotationType Annotation::getAnnotationType() const
{
	return annotationType;
}
string Annotation::toString(){
	char s[1024]; 
	memset(s, 0, 1024); 
	sprintf(s, "%s\t %s partId:%d startPos:%d endPos:%d quote:%s noteType:%d \t", __FILE__, Item::toString().c_str(), partId, startPos, endPos, quote.c_str(), annotationType); 
	return string(s);
}
