#include "dbookinfo.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string.h>
DBookInfo::DBookInfo(){
	width = 0;
	height = 0;
}

DBookInfo::DBookInfo(const DBookInfo& info){
	width = 0;
	height = 0;
	setBookId(info.getBookId());
	setBookName(info.getBookName());
	setWidth(info.getWidth());
	setHeight(info.getHeight());
}

DBookInfo::~DBookInfo(){
}
void DBookInfo::setWidth(int w){
	width = w;
}
int DBookInfo::getWidth() const{
	return width;
}
void DBookInfo::setHeight(int h){
	height = h;
}
int DBookInfo::getHeight() const{
	return height;
}
string DBookInfo::toString(){
	char s[1024];
	memset(s, 0, 1024); 
	sprintf(s, "\t width: %d\t height: %d\t", width, height);
	string str;
	str.append(__FILE__);
	str.append("\t");
	str.append(BookInfo::toString());
	str.append("\t");
	str.append(s);
	str.append("\n");
	return str;	
}
