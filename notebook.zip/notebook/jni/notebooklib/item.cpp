#include "item.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
Item::Item(){
	oprId = 0;
}
Item::Item(const Item& item){
	oprId = 0;
	setOprId(item.getOprId());
}
Item::~Item(){
}
void Item::setOprId(int oid){
	oprId = oid;
}
int Item::getOprId() const{
	return oprId;
}
string Item::toString(){
	char s[128];
	memset(s, 0, 128); 
        sprintf(s, "\toprId:%d\t", oprId);
        return string(s);
}
