#include "notebook.h"

NoteBook::NoteBook()
{
	bookInfo = NULL;
}

NoteBook::NoteBook(const NoteBook& book)
{
	bookInfo = NULL;
	setDNoteBookInfo(book.getDNoteBookInfo());
	list<NotePage*> plist = book.getNotePages();
	for(list<NotePage*>::iterator it = plist.begin(); it != plist.end(); it++){
		addNotePage(*it);
	}
}
NoteBook::~NoteBook()
{
	for(list<NotePage*>::iterator it = pages.begin(); it != pages.end();){
		list<NotePage*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	pages.clear();
}

void NoteBook::setDNoteBookInfo(DNoteBookInfo *dinfo){
	bookInfo = dinfo;
}

DNoteBookInfo* NoteBook::getDNoteBookInfo() const{
	return bookInfo;
}

list<NotePage*> NoteBook::getNotePages() const
{
	return pages;
}

void NoteBook::addNotePage(NotePage* page)
{
	if(page)
		pages.push_back(page);
}
