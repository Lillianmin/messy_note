#ifndef TextAnnotation_h
#define TextAnnotation_h

#include "annotation.h"
#include <string>


class TextAnnotation : public Annotation {
public:
	TextAnnotation();
	TextAnnotation(const TextAnnotation&);
	TextAnnotation(const Annotation&);
	~TextAnnotation();

    void setComment(string);
    string getComment() const;
    string toString();
private:
    string comment;
};

#endif
