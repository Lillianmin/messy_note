#include "hwannotation.h"
#include <stdlib.h>
#include <iostream>
HWAnnotation::HWAnnotation()
{
	setAnnotationType(HANDWRITE);
}
HWAnnotation::HWAnnotation(const HWAnnotation& annotation)
{
	setAnnotationType(HANDWRITE);
	setOprId(annotation.getOprId());	
	setPartId(annotation.getPartId());
	setStartPos(annotation.getStartPos());
	setEndPos(annotation.getEndPos());
	setQuote(annotation.getQuote());
	setEditType(annotation.getEditType());
	list<Track> tracks = annotation.getTracks();
	list<Track>::iterator trackIt;
	trackIt = tracks.begin();
	while(trackIt!=tracks.end()){
		addTrack(*trackIt);
		trackIt++;
	}
}
HWAnnotation::HWAnnotation(const Annotation& annotation)
{
	setAnnotationType(HANDWRITE);
	setOprId(annotation.getOprId());	
	setPartId(annotation.getPartId());
	setStartPos(annotation.getStartPos());
	setEndPos(annotation.getEndPos());
	setQuote(annotation.getQuote());
}
void HWAnnotation::setEditItem(const EditItem& item){
	setEditType(item.getEditType());
	list<Track> tracks = item.getTracks();
	list<Track>::iterator trackIt;
	trackIt = tracks.begin();
	while(trackIt!=tracks.end()){
		addTrack(*trackIt);
		trackIt++;
	}
}
HWAnnotation::~HWAnnotation()
{
}

string HWAnnotation::toString(){
	string str;
	str.append(__FILE__);
	str.append(Annotation::toString());
	str.append("\t");
	str.append(EditItem::toString());
	return str;
}
