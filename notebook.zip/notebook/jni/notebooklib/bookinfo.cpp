#include "bookinfo.h"

BookInfo::BookInfo(){
	bookId = "";
	bookName = "";
}
BookInfo::BookInfo(const BookInfo& info){
	bookId = "";
	bookName = "";
	setBookId(info.getBookId());
	setBookName(info.getBookName());
}
BookInfo::~BookInfo(){
}
void BookInfo::setBookId(string bookid)
{
	bookId = bookid;
}
string BookInfo::getBookId() const
{
	return bookId;
}
void BookInfo::setBookName(string bookname){
	bookName = bookname;
}
string BookInfo::getBookName() const
{
	return bookName;
}
string BookInfo::toString(){
	return "bookId:" + bookId + "\tbookName:" + bookName + "\t";
}

