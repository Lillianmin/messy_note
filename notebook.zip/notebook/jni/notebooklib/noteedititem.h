#ifndef NOTEEDITITEM_H
#define NOTEEDITITEM_H

#include "edititem.h"
#include "item.h"

class NoteEditItem : public EditItem, public Item{
public:
	NoteEditItem();
	NoteEditItem(const NoteEditItem&);
	NoteEditItem(const EditItem&);
	~NoteEditItem();
	void setPageId(int pid);
	int getPageId() const;
	string toString();
private:
	int pageId;
};
#endif
