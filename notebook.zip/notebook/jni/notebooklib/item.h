#ifndef ITEM_H
#define ITEM_H

#include <string>

using namespace std;

class Item {
public:
	Item();
	Item(const Item&);
	virtual ~Item();
	void setOprId(int);
	int getOprId() const;
	virtual string toString();
private:
	int oprId;
};

#endif
