#ifndef EDITITEM_H
#define EDITITEM_H

#include <list>
#include "item.h"
#include "track.h"

using namespace std;

enum EditType{
	WRITE,
	ERASE,
	CLEAR
};

class EditItem{
public:
	EditItem();
	EditItem(const EditItem&);
	virtual ~EditItem();

    void setEditType(EditType type);
	EditType getEditType() const;

    void addTrack(Track track);
	void addTracks(list<Track*>);
	void addTracks(list<Track>);
    list<Track> getTracks() const;

	void clear();
	string toString();

public:
    list<Track> tracks;
    EditType editType;
};

#endif
