#ifndef NOTEBOOK_H
#define NOTEBOOK_H

#include "notepage.h"
#include "dnotebookinfo.h"
#include <string>
#include <list>

using namespace std;
class NoteBook {
public:
	NoteBook();
	NoteBook(const NoteBook&);
	~NoteBook();

	void setDNoteBookInfo(DNoteBookInfo *dinfo);
	DNoteBookInfo* getDNoteBookInfo() const;	

    list<NotePage*> getNotePages() const;
    void addNotePage(NotePage* p);

private:
	DNoteBookInfo *bookInfo;
    list<NotePage*> pages;
};
#endif
