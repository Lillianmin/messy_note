#ifndef DNOTEBOOKINFO_H
#define DNOTEBOOKINFO_H

#include "dbookinfo.h"

class DNoteBookInfo : public DBookInfo{
public:
	DNoteBookInfo();
	DNoteBookInfo(const DBookInfo&);
	DNoteBookInfo(const DNoteBookInfo&);
	~DNoteBookInfo();
	void setCover(const char* cv, int size);
	char* getCover() const;
	int getCvSize() const;
	void setBackground(const char* bg, int size);
	char* getBackground() const;
	int getBgSize() const;
	string toString();
private:
	char* cover;
	char* background;
	int bgSize;
	int cvSize;
};
#endif
