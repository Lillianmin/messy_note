#ifndef COMMON_H
#define COMMON_H

#include <jni.h>
#include "edititem.h"
#include "track.h"

extern "C" char* jstringToString(JNIEnv *env, jstring jstr);
extern "C" jstring stringToJString(JNIEnv *env, const char* str);
extern "C" jbyteArray stringToJByteArray(JNIEnv* env, const char* str, int size);
extern "C" jobject editTypeToJEditType(JNIEnv* env, EditType editType);
extern "C" jobject pointToJPoint(JNIEnv* env, Point point);
extern "C" jobject trackToJTrack(JNIEnv* env, Track track);
extern "C" jobject editItemToJEditItem(JNIEnv* env, EditItem item);
#endif
