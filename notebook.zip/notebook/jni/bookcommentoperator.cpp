#include <jni.h>
#include <android/log.h>
#include <list>
#include <string>
#include "common.h"
#include "bookprocessfactory.h"
#include "dbookinfo.h"
#include "bookinfo.h"
#include "textannotation.h"
#include "hwannotation.h"

using namespace std;
static IBookCommentProcess* process =
		BookProcessFactory::createBookCommentProcess();//TODO db close is in process destroy function. make it another function to call.
extern "C" void Java_com_zeleisoft_wifishare_operator_BookCommentOperator_setStorageFilePath(
		JNIEnv* env, jobject thiz, jstring path) {
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "setStorageFilePath");
	char* dbPath = jstringToString(env, path);
	process->setStorageFilePath(string(dbPath));
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "setStorageFilePath %s\n",
			dbPath);
	free(dbPath);
}
extern "C" jobject dBookInfoToJDBookInfo(JNIEnv* env, DBookInfo info) {
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/DBookInfo");
	jmethodID methodId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, methodId);
	jmethodID setBookIdMethodId = env->GetMethodID(cls, "setBookId",
			"(Ljava/lang/String;)V");
	jstring bookid = stringToJString(env, info.getBookId().c_str());
	env->CallVoidMethod(object, setBookIdMethodId,
			bookid);
	env->DeleteLocalRef(bookid);
	jmethodID setBookNameMethodId = env->GetMethodID(cls, "setBookName",
			"(Ljava/lang/String;)V");
	jstring bookname = stringToJString(env, info.getBookName().c_str());
	env->CallVoidMethod(object, setBookNameMethodId,
			bookname);
	env->DeleteLocalRef(bookname);
	jmethodID setWidthMethodId = env->GetMethodID(cls, "setWidth", "(I)V");
	env->CallVoidMethod(object, setWidthMethodId, info.getWidth());
	jmethodID setHeightMethodId = env->GetMethodID(cls, "setHeight", "(I)V");
	env->CallVoidMethod(object, setHeightMethodId, info.getHeight());
	env->DeleteLocalRef(cls);
	return object;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_BookCommentOperator_getDBookInfo(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "id %s\n", id);
	DBookInfo* info = process->getDBookInfo(string(id));

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "info %s\n",
			info->toString().c_str());
	jobject jinfo = dBookInfoToJDBookInfo(env, *info);
	delete info;
	info = NULL;
	free(id);
	return jinfo;
}
extern "C" jobject bookInfoToJBookInfo(JNIEnv* env, BookInfo info) {

	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/BookInfo");
	jmethodID methodId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, methodId);
	jmethodID setBookIdMethodId = env->GetMethodID(cls, "setBookId",
			"(Ljava/lang/String;)V");
	jstring bookid = stringToJString(env, info.getBookId().c_str());
	env->CallVoidMethod(object, setBookIdMethodId,
			bookid);
	env->DeleteLocalRef(bookid);
	jmethodID setBookNameMethodId = env->GetMethodID(cls, "setBookName",
			"(Ljava/lang/String;)V");
	jstring bookname = stringToJString(env, info.getBookName().c_str());
	env->CallVoidMethod(object, setBookNameMethodId,
			bookname);
	env->DeleteLocalRef(bookname);
	env->DeleteLocalRef(cls);
	return object;
}

extern "C" jobject Java_com_zeleisoft_wifishare_operator_BookCommentOperator_getBookInfoList(
		JNIEnv* env, jobject thiz) {
	list<BookInfo*> infoList = process->getBookInfoList();

	jclass cls = env->FindClass("java/util/ArrayList");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject jlist = env->NewObject(cls, metholdId);
	jmethodID addMethodId = env->GetMethodID(cls, "add",
			"(Ljava/lang/Object;)Z");
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "bookinfo list size %d\n",
			infoList.size());
	for (list<BookInfo*>::iterator it = infoList.begin(); it != infoList.end();
			it++) {
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "bookinfo %s\n",
				(*it)->toString().c_str());
		jobject bookInfo = bookInfoToJBookInfo(env, *(*it));
		env->CallBooleanMethod(jlist, addMethodId,
				bookInfo);
		env->DeleteLocalRef(bookInfo);
	}

	env->DeleteLocalRef(cls);
	for (list<BookInfo*>::iterator it = infoList.begin(); it != infoList.end();
			) {
		list<BookInfo*>::iterator it2 = it;
		it++;
		delete *it2;
	}
	infoList.clear();
	return jlist;

}
extern "C" jint Java_com_zeleisoft_wifishare_operator_BookCommentOperator_getLocalMaxOprId(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	int maxId = process->getLocalMaxOprId(string(id));
	free(id);
	return maxId;
}
extern "C" jobject textAnnotationToJTextAnnotation(JNIEnv* env, TextAnnotation annotation){
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/TextAnnotation");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);
	jmethodID setOprIdMethodId = env->GetMethodID(cls, "setOprId", "(I)V");
	env->CallVoidMethod(object, setOprIdMethodId, annotation.getOprId());
	jmethodID setPartIdMethodId = env->GetMethodID(cls, "setPartId", "(I)V");
	env->CallVoidMethod(object, setPartIdMethodId, annotation.getPartId());
	jmethodID setStartPosMethodId = env->GetMethodID(cls, "setStartPos", "(I)V");
	env->CallVoidMethod(object, setStartPosMethodId, annotation.getStartPos());
	jmethodID setEndPosMethodId = env->GetMethodID(cls, "setEndPos", "(I)V");
	env->CallVoidMethod(object, setEndPosMethodId, annotation.getEndPos());
	jmethodID setQuoteMethodID = env->GetMethodID(cls, "setQuote", "(Ljava/lang/String;)V");
	jstring quote = stringToJString(env, annotation.getQuote().c_str());
	env->CallVoidMethod(object, setQuoteMethodID, quote);
	env->DeleteLocalRef(quote);
	jmethodID setCommentMethodId = env->GetMethodID(cls, "setComment", "(Ljava/lang/String;)V");
	jstring comment = stringToJString(env, annotation.getComment().c_str());
	env->CallVoidMethod(object, setCommentMethodId, comment);
	env->DeleteLocalRef(comment);
	env->DeleteLocalRef(cls);
	return object;
}
extern "C" jobject hwAnnotationToJHWAnnotation(JNIEnv* env, HWAnnotation annotation){
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/HWAnnotation");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);
	jmethodID setOprIdMethodId = env->GetMethodID(cls, "setOprId", "(I)V");
	env->CallVoidMethod(object, setOprIdMethodId, annotation.getOprId());
	jmethodID setPartIdMethodId = env->GetMethodID(cls, "setPartId", "(I)V");
	env->CallVoidMethod(object, setPartIdMethodId, annotation.getPartId());
	jmethodID setStartPosMethodId = env->GetMethodID(cls, "setStartPos", "(I)V");
	env->CallVoidMethod(object, setStartPosMethodId, annotation.getStartPos());
	jmethodID setEndPosMethodId = env->GetMethodID(cls, "setEndPos", "(I)V");
	env->CallVoidMethod(object, setEndPosMethodId, annotation.getEndPos());
	jmethodID setQuoteMethodID = env->GetMethodID(cls, "setQuote", "(Ljava/lang/String;)V");
	jstring quote = stringToJString(env, annotation.getQuote().c_str());
	env->CallVoidMethod(object, setQuoteMethodID, quote);
	env->DeleteLocalRef(quote);
	jmethodID setEditItemMethodId = env->GetMethodID(cls, "setEditItem", "(Lcom/zeleisoft/wifishare/operator/EditItem;)V");
	jobject editItem = editItemToJEditItem(env, annotation);
	env->CallVoidMethod(object, setEditItemMethodId, editItem);
	env->DeleteLocalRef(cls);
	env->DeleteLocalRef(editItem);
	return object;
}
extern "C" jobject annotationToJAnnotation(JNIEnv* env, Annotation* annotation){
	jobject object;
	if(annotation->getAnnotationType()==TEXT){
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before  dynamic_cast<TextAnnotation&>\n");
		TextAnnotation* ta = dynamic_cast<TextAnnotation*>(annotation);
		object = textAnnotationToJTextAnnotation(env, *ta);
	}else if(annotation->getAnnotationType()==HANDWRITE){
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before  dynamic_cast<HWAnnotation&>\n");
		HWAnnotation* hwa = dynamic_cast<HWAnnotation*>(annotation);
		object = hwAnnotationToJHWAnnotation(env, *hwa);
	}
	return object;
}
extern "C" jobject annotationListToJAnnotationList(JNIEnv* env,
		list<Annotation*> annotationList) {
	jclass cls = env->FindClass("java/util/ArrayList");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject jlist = env->NewObject(cls, metholdId);
	jmethodID addMethodId = env->GetMethodID(cls, "add",
			"(Ljava/lang/Object;)Z");
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "annotation list size %d\n",
			annotationList.size());
	for (list<Annotation*>::iterator it = annotationList.begin(); it != annotationList.end();
			it++) {
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "annotation %s\n",
				(*it)->toString().c_str());
		jobject annotation = annotationToJAnnotation(env, *it);
		env->CallBooleanMethod(jlist, addMethodId,
				annotation);
		env->DeleteLocalRef(annotation);
	}

	env->DeleteLocalRef(cls);
	return jlist;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_BookCommentOperator_getPartAnnotationList(
		JNIEnv* env, jobject thiz, jstring bookid, int partid) {
	char* id = jstringToString(env, bookid);
	list<Annotation*> annotationList = process->getPartAnnotationList(string(id),
			partid);
	jobject object = annotationListToJAnnotationList(env, annotationList);

	free(id);
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before delete getPartAnnotationList \n");
	for(list<Annotation*>::iterator it = annotationList.begin(); it != annotationList.end(); it++){
			list<Annotation*>::iterator it2 = it;
			it++;
			delete *it2;
		}
	annotationList.clear();
	return object;
}
extern "C" jobject Java_com_zeleisoft_wifishare_operator_BookCommentOperator_getAnnotationList(
		JNIEnv* env, jobject thiz, jstring bookid) {
	char* id = jstringToString(env, bookid);
	list<Annotation*> annotationList = process->getAnnotationList(string(id));
	jobject object = annotationListToJAnnotationList(env, annotationList);
	free(id);
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before delete getAnnotationList \n");

	for(list<Annotation*>::iterator it = annotationList.begin(); it != annotationList.end(); it++){
				list<Annotation*>::iterator it2 = it;
				it++;
				delete *it2;
	}
	annotationList.clear();

	return object;
}

extern "C" jboolean Java_com_zeleisoft_wifishare_operator_BookCommentOperator_syncBookComment(
		JNIEnv* env, jobject thiz, jstring username, jstring useragent,
		jstring bookid, int width, int height) {
	char* name = jstringToString(env, username);
	char* agent = jstringToString(env, useragent);
	char* id = jstringToString(env, bookid);
	bool result = process->syncBookComment(string(name), string(agent),
			string(id), width, height);
	free(name);
	free(agent);
	free(id);
	return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" jboolean Java_com_zeleisoft_wifishare_operator_BookCommentOperator_syncAllBookComment(
		JNIEnv* env, jobject thiz, jstring username, jstring useragent,
		int width, int height) {
	char* name = jstringToString(env, username);
	char* agent = jstringToString(env, useragent);
	bool result = process->syncAllBookComment(string(name), string(agent),
			width, height);
	free(name);
	free(agent);
	return result ? JNI_TRUE : JNI_FALSE;
}

extern "C" void Java_com_zeleisoft_wifishare_operator_BookCommentOperator_closeDB(JNIEnv* env, jobject thiz){
	process->closeDB();
}
