#include <jni.h>
#include <android/log.h>
#include "edititem.h"
#include "track.h"

//jstring to char*
using namespace std;
extern "C" char* jstringToString(JNIEnv *env, jstring jstr) {
	char* rtn = NULL;
	jclass cls = env->FindClass("java/lang/String");
	jstring strEncode = env->NewStringUTF("utf-8");
	jmethodID methodID = env->GetMethodID(cls, "getBytes",
			"(Ljava/lang/String;)[B");
	jbyteArray byteArray = (jbyteArray) env->CallObjectMethod(jstr, methodID,
			strEncode);
	jsize len = env->GetArrayLength(byteArray);
	jbyte* btry = env->GetByteArrayElements(byteArray, JNI_FALSE);
	if (len > 0) {
		rtn = (char*) malloc(len + 1);
		memcpy(rtn, btry, len);
		rtn[len] = 0;
	}

	//env->DeleteLocalRef(jstr);
	env->ReleaseByteArrayElements(byteArray, btry, 0);
	env->DeleteLocalRef(cls);
	env->DeleteLocalRef(strEncode);
	return rtn;
}

//char* to jstring
extern "C" jstring stringToJString(JNIEnv *env, const char* str) {
	jclass cls = env->FindClass("java/lang/String");
	jmethodID methodID = env->GetMethodID(cls, "<init>",
			"([BLjava/lang/String;)V");
	jbyteArray bytes = env->NewByteArray(strlen(str));
	env->SetByteArrayRegion(bytes, 0, strlen(str), (jbyte*) str);
	jstring encoding = env->NewStringUTF("utf-8");
	jstring strRtn = (jstring) env->NewObject(cls, methodID, bytes, encoding);

	env->DeleteLocalRef(cls);
	env->DeleteLocalRef(bytes);
	env->DeleteLocalRef(encoding);
	return strRtn;
}
//char*, size to jbyteArray
extern "C" jbyteArray stringToJByteArray(JNIEnv* env, const char* str,
		int size) {
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "stringToJByteArray %d\n",
			size);
	jbyteArray byteArray = env->NewByteArray(size);
	env->SetByteArrayRegion(byteArray, 0, size, (jbyte*) str);
	return byteArray;
}
extern "C" jobject editTypeToJEditType(JNIEnv* env, EditType editType){

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "editTypeToJEditType \n");
		jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/EditItem$EditType");

		jfieldID type;
		if(editType == WRITE) {
			type = env->GetStaticFieldID(
				    cls,"WRITE","Lcom/zeleisoft/wifishare/operator/EditItem$EditType;");
		}else if (editType == ERASE) {
			type = env->GetStaticFieldID(
				    cls,"ERASE","Lcom/zeleisoft/wifishare/operator/EditItem$EditType;");
		}else if (editType == CLEAR){
			type = env->GetStaticFieldID(
				    cls,"CLEAR","Lcom/zeleisoft/wifishare/operator/EditItem$EditType;");
		}

		jobject object = env->GetStaticObjectField(cls, type);

		env->DeleteLocalRef(cls);
		return object;
}
extern "C" jobject pointToJPoint(JNIEnv* env, Point point){
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "pointToJPoint \n");
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/Point");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);

	jmethodID setXMethodId = env->GetMethodID(cls, "setX", "(I)V");
	env->CallVoidMethod(object, setXMethodId, point.x);

	jmethodID setYMethodId = env->GetMethodID(cls, "setY", "(I)V");
	env->CallVoidMethod(object, setYMethodId, point.y);

	env->DeleteLocalRef(cls);
	return object;
}

extern "C" jobject trackToJTrack(JNIEnv* env, Track track){
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "trackToJTrack \n");
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/Track");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);

	jmethodID setPenWidthMethodId = env->GetMethodID(cls, "setPenWdith", "(I)V");
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "trackToJTrack setPenWidthMethodId\n");
	env->CallVoidMethod(object, setPenWidthMethodId, track.getPenWidth());

	list<Point> points = track.getPoints();
	jmethodID addPointMethodId = env->GetMethodID(cls, "addPoint", "(Lcom/zeleisoft/wifishare/operator/Point;)V");

	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "trackToJTrack addPointMethodId\n");
	for(list<Point>::iterator it = points.begin(); it != points.end(); it++){
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "before pointToJPoint\n");
		__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "trackToJTrack %s\n", (*it).toString().c_str());
		jobject point = pointToJPoint(env, *it);
		env->CallVoidMethod(object, addPointMethodId, point);
		env->DeleteLocalRef(point);
	}

	env->DeleteLocalRef(cls);
	return object;

}
extern "C" jobject editItemToJEditItem(JNIEnv* env, EditItem item){
	__android_log_print(ANDROID_LOG_INFO, "JNI_DBG", "editItemToJEditItem \n");
	jclass cls = env->FindClass("com/zeleisoft/wifishare/operator/EditItem");
	jmethodID metholdId = env->GetMethodID(cls, "<init>", "()V");
	jobject object = env->NewObject(cls, metholdId);
	jmethodID setEditTypeMethodId = env->GetMethodID(cls, "setEditType", "(Lcom/zeleisoft/wifishare/operator/EditItem$EditType;)V");
	jobject editType = editTypeToJEditType(env, item.getEditType());
	env->CallVoidMethod(object, setEditTypeMethodId, editType);
	env->DeleteLocalRef(editType);
	jmethodID addTrackMethodID = env->GetMethodID(cls, "addTrack", "(Lcom/zeleisoft/wifishare/operator/Track;)V");

	list<Track> tracks = item.getTracks();
	for(list<Track>::iterator it = tracks.begin(); it != tracks.end(); it++){
		jobject track = trackToJTrack(env, *it);
		env->CallVoidMethod(object, addTrackMethodID, track);
		env->DeleteLocalRef(track);
	}
	env->DeleteLocalRef(cls);
	return object;
}
