#!/bin/sh
make_armeabi(){
#build arm
	make distclean
	export SYSROOT=$NDK_TOOLCHAIN_HOME/arm-linux-androideabi-4.6/sysroot
	export CPPFLAGS="-I$SYSROOT/usr/include"
	export LDFLAGS="-L$SYSROOT/usr/lib"
	./configure --host=arm-linux-androideabi --prefix=$PWD/libs/armeabi
	make
	make install
}
make_armeabi_v7a(){
#build armv7-a
	make distclean
	export SYSROOT=$NDK_TOOLCHAIN_HOME/arm-linux-androideabi-4.6/sysroot
	export CPPFLAGS="-I$SYSROOT/usr/include"
	export CFLAGS="-march=armv7-a"
	export LDFLAGS="-L$SYSROOT/usr/lib"
	./configure --host=arm-linux-androideabi --prefix=$PWD/libs/armeabi-v7a
	make
	make install
}
make_mips(){
#build mips
	make distclean
	export SYSROOT=$NDK_TOOLCHAIN_HOME/mipsel-linux-android-4.6/sysroot
	export CPPFLAGS="-I$SYSROOT/usr/include"
	export LDFLAGS="-L$SYSROOT/usr/lib"
	./configure --host=mipsel-linux-android --prefix=$PWD/libs/mips
	make
	make install 
}
make_x86(){
#build x86
	make distclean
	export SYSROOT=$NDK_TOOLCHAIN_HOME/i686-linux-android-4.6/sysroot
	export CPPFLAGS="-I$SYSROOT/usr/include"
	export LDFLAGS="-L$SYSROOT/usr/lib"
	./configure --host=i686-linux-android --prefix=$PWD/libs/x86
	make
	make install 
}

if [ $# -eq 1 ]; then
	echo $1
	if [ "armeabi" = $1 ]; then
		make_armeabi;
	elif [ "armeabi_v7a" = $1 ]; then
		make_armeabi_v7a;
	elif [ "mips" = $1 ]; then
		make_mips;
	elif [ "x86" = $1 ]; then
		make_x86;
	else
		echo "Usage: $0 armeabi or armeabi_v7a or mips or x86"
	fi
else
	echo "Usage: $0 armeabi or armeabi_v7a or mips or x86"
fi
