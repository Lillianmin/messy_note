#!/bin/sh
make distclean
./configure "CFLAGS=-m32" "CXXFLAGS=-m32" "LDFLAGS=-m32" --without-libssh2 --prefix=$PWD/install
#./configure "CFLAGS=-m32" "CXXFLAGS=-m32" "LDFLAGS=-m32" --prefix=$PWD/install
make
make install
