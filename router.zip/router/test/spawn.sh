#spawn-fcgi -a 127.0.0.1 -p 7000 -u mll -f /home/mll/data/RouterDev/test/test.cgi
spawn-fcgi -a 127.0.0.1 -p 7000 -u mll -f /home/mll/data/RouterDev/test/check_login_get.cgi
