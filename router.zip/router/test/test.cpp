#include <fcgi_stdio.h>
int main( int argc, char *argv[] )
{
  while( FCGI_Accept() >= 0 )
  {
      FCGI_printf( "Status: 200 OK\r\n" );
      FCGI_printf( "Content-Type: text/html\r\n\r\n" );
      FCGI_printf( "Hello world in C\n" );
  }
  return 0;
}
