g++ -o test.cgi test.cpp -L /usr/local/lib/ -lfcgi
