#!/bin/sh

PRE_PATH=/tmp/run/mountd/sda1/nginx/portal
SH_PATH=/etc/config/sh
export PATH=${PATH}:${SH_PATH}
wlan_name=wlan0
wifi_mac=`ifconfig | getmac.sh ${wlan_name}`
ftp_serv=192.168.200.10

if [ ! -d ${PRE_PATH}/admin/$wifi_mac ]; then
    mkdir -p ${PRE_PATH}/admin/$wifi_mac
fi

while [ 1 ];
do
cp -f ${PRE_PATH}/config/visit_record.txt ${PRE_PATH}/admin/$wifi_mac/${wifi_mac}
md5sum ${PRE_PATH}/admin/$wifi_mac/$wifi_mac | cut -f 1 -d ' ' > ${PRE_PATH}/admin/${wifi_mac}/md5_${wifi_mac}

cd ${PRE_PATH}/admin/
tar cvf visit_record.tar ${wifi_mac}

echo ncftpput -u zcc -p 123456 -m -R $ftp_serv /home/zcc/ $wifi_mac
ncftpput -u zcc -p 123456  -R $ftp_serv /home/zcc/ ${PRE_PATH}/admin/$wifi_mac

sleep 900
rm -f ${PRE_PATH}/admin/visit_record.tar
done

