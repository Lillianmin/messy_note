#!/bin/sh

#spawn fcgi program

LOGIN_CGI_DIR=/tmp/run/mountd/sda1/nginx/portal/login
ADMIN_CGI_DIR=/tmp/run/mountd/sda1/nginx/portal/admin

spawn-fcgi -a 127.0.0.1 -p 7000 -f ${LOGIN_CGI_DIR}/login
spawn-fcgi -a 127.0.0.1 -p 7001 -f ${ADMIN_CGI_DIR}/admin
spawn-fcgi -a 127.0.0.1 -p 7002 -f ${ADMIN_CGI_DIR}/auth
spawn-fcgi -a 127.0.0.1 -p 7003 -f ${ADMIN_CGI_DIR}/visit
spawn-fcgi -a 127.0.0.1 -p 7004 -f ${ADMIN_CGI_DIR}/act_check.cgi
spawn-fcgi -a 127.0.0.1 -p 7005 -f ${ADMIN_CGI_DIR}/activator.cgi
spawn-fcgi -a 127.0.0.1 -p 7006 -f ${ADMIN_CGI_DIR}/passwd.cgi

#Port 8001 is a web in fact,use for customer authentication.
iptables -t nat -I PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8001
iptables -t nat -I PREROUTING -p udp --dport 53 -j REDIRECT --to-port 53
iptables -t nat -I PREROUTING -p tcp --dport 53 -j REDIRECT --to-port 53 

ln -s /tmp/dhcp.leases -T /tmp/run/mountd/sda1/nginx/portal/config/dhcp.leases
