#include<fcgi_stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "commom.h"
#define AUTH_OK CGI_HTML_DIR"auth_ok.html"
#define AUTH_ERR CGI_HTML_DIR"auth_err.html"
#define AUTH_ALREADY CGI_HTML_DIR"auth_already.html"
#define ACTIVATION_EXPIRED CGI_HTML_DIR"activation_expired.html"

static char m[4][10] = {"3XY6ef2RS4", "abc85dghij", "klmn79opst", "Z10MNPqrTU"};
int checkcodetoid(char *sn)
{
    int i, j, id = 0;
    for(i = 3; i >= 0 ; i--)
    {
	for(j = 0; j < 10; j++)
	{
	    if(m[i][j] == sn[3-i])
	    {
		id *= 10;
		id += j;
		break;
	    }
	}
    }
    return id;
}

int main()
{
    while(FCGI_Accept() >= 0)
	{
		int fdCustomer, fdActive, id, cus_is_found = 0;
		struct customer cus;
		long time = 0, act_time = 0;
		long valid_time =31*24*60*60;

		fdCustomer = open(CUSTOMER_FILE, O_RDWR|O_CREAT, 0666); 
		fdActive = open(ACTIVATOR_FILE, O_RDONLY, 0666);
		
		if(fdCustomer < 0)
		{
		    file_print("ERROR_FILE");
		    continue;
		}

		if(fdActive < 0)
		{
		    printf("Content-type: text/html\r\n\r\n");
		    file_print(ACTIVATION_EXPIRED);
		    continue;
		}else
		{
		    if(read(fdActive, &act_time, sizeof(act_time)) != sizeof(act_time))
		    {
			file_print(ERROR_FILE);
			continue;
		    }
		}

		char *str_len = getenv("CONTENT_LENGTH");

		if(strlen == NULL)
		{
		    file_print("ERROR_FILE");
		    continue;
		}

		int len = atoi(str_len);
		char *str = (char *)malloc(len + 1);
		char *cnum = (char *)malloc(len + 1);

		if(str == NULL || cnum == NULL)
		{
		    free(str);
		    free(cnum);
		    file_print(ERROR_FILE);
		    continue;
		}

		fgets(str, len + 1, stdin);
		int count = sscanf(str,"check=%[^&]&now=%ld",cnum, &time);


		if(count != 2)
		{
		    free(str);
		    free(cnum);
		    file_print(ERROR_FILE);
		    continue;
		}

		if((time - act_time) > valid_time)
		{
		    printf("Content-type: text/html;charset=utf-8\r\n\r\n");
		    file_print(ACTIVATION_EXPIRED);
		    continue;
		}

		id = checkcodetoid(cnum);

		memset(&cus, 0, sizeof(cus));
        while(read(fdCustomer, &cus, sizeof(cus)) == sizeof(cus))
		{	
            if(cus.auth_status == 1 && cus.id == id)
			{
				printf("Content-type: text/html;charset=utf-8\r\n\r\n");
				file_print(AUTH_ALREADY);		
				cus_is_found = 1;
				break;
			}

			if(cus.auth_status == 0 && cus.id == id)
			{	
                cus.auth_status = 1;
				lseek(fdCustomer, -sizeof(cus), SEEK_CUR);		
				write(fdCustomer, &cus, sizeof(cus));
				printf("Content-type: text/html;charset=utf-8\r\n\r\n");
				file_print(AUTH_OK);
				cus_is_found = 1;
				break;
			}			
			memset(&cus, 0, sizeof(cus));	
		}

		if(cus_is_found == 0)
		{

			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			file_print(AUTH_ERR);
		}
		free(cnum);
        free(str);
		close(fdCustomer);
        close(fdActive);
	}
	
}
