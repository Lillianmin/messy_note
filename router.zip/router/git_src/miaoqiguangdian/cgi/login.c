#include <fcgi_stdio.h>
#include <stdlib.h>
#include <stdio.h> 
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <arpa/inet.h>
#include <time.h>
#include "commom.h"
#define JUMP_TO_BOOKBOX CGI_HTML_DIR"jump_to_bookbox.html"
#define WELCOME CGI_HTML_DIR"welcome.html"
#define MAX_TIMES 10
#define YES 1
#define NO 0

static char m[4][10] = {"3XY6ef2RS4", "abc85dghij", "klmn79opst", "Z10MNPqrTU"};
void idtocheckcode(int num, char *sn)
{
    int i;
    for(i = 0; i < 4; i++)
    {
	sn[3-i] = m[i][num % 10];
	num /= 10;
    }
}

void getmac(unsigned char *ip, unsigned char *mac)
{
    FILE *lease_stream = fopen(UDHCP_FILE, "r");
    char buf[512];
    while(!feof(lease_stream))
    {
        memset(buf, 0, sizeof(buf));
        fgets(buf, 512, lease_stream);
        int i, j, ip_match = YES;
        for(i = 29, j = 0; i <= 43; i++, j++)
        {
            if(ip[j] != buf[i])
            {
                ip_match = NO;
                break;
            }
        }
        if(ip_match == YES)
        {
            for(i = 11, j = 0; i <= 27; i++, j++)
            {
                mac[j] = buf[i];
            }
            mac[j] = '\0';
            break;
        }
    }
    fclose(lease_stream);
}

int main()
{
	while(FCGI_Accept() >= 0)
	{
		int fdCustomer, fdVist, cus_match = NO;	
		unsigned char *ip, *mac;
		char *date;
		struct in_addr addr;
		struct customer cus;
        struct access_statistics r;

		fdCustomer = open(CUSTOMER_FILE, O_RDWR|O_CREAT, 0666);
		fdVist = open(VISIT_RECORD, O_RDWR|O_CREAT, 0666);

		//define iptables command and init prefix
		char cmd[150] = "/usr/sbin/iptables -t nat -I PREROUTING -p tcp --dport 80 -s ";

		//get ip and mac 
        char *str_len = getenv("REMOTE_ADDR");
        ip = (char *)malloc(atoi(str_len) + 1);
		strcpy(ip, getenv("REMOTE_ADDR"));
        mac = (char *)malloc(18);
        getmac(ip, mac);
        
		date = getenv("QUERY_STRING");
		
		if(fdCustomer < 0 || fdVist < 0 || ip == NULL || date == NULL)
		{
		    file_print(ERROR_FILE);
		    close(fdCustomer);
		    close(fdVist);	
		    continue;
		}

		while(read(fdCustomer, &cus, sizeof(cus)) == sizeof(cus))
		{
			if(ustrncmp(cus.mac, mac, 17) == 0)
			{
				cus_match = YES;
				if(cus.auth_status == YES)
				{
					//do iptables cmd 
					strcat(cmd, ip);				
					strcat(cmd," -j ACCEPT");
                    int i = 0;
                    while (i < MAX_TIMES) {
                        if(system(cmd) != -1)
                            break;
                        i++;
                    }

					printf("Content-type: text/html\r\n\r\n");
					file_print(JUMP_TO_BOOKBOX);

					if(cus.is_counted == 0)
					{
						int date_match = NO;
						while(read(fdVist, &r, sizeof(r)) == sizeof(r))
						{
							if(strcmp(r.date, date) == 0)
							{
							    r.count++;
							    lseek(fdVist, -sizeof(r), SEEK_CUR);
							    write(fdVist, &r, sizeof(r));
							    date_match = YES;
							    break;
							}
						}
						
						if(date_match == 0)
						{
							memset(&r, 0, sizeof(r));
							lseek(fdVist, 0, SEEK_END);
							strcpy(r.date, date);
							r.count = 1;
							write(fdVist, &r, sizeof(r));
						}
						
						cus.is_counted = 1;
						lseek(fdCustomer, -sizeof(cus), SEEK_CUR);
						write(fdCustomer, &cus, sizeof(cus));
					}
					break;
				}
				break;
			}
		}

		if(cus_match == NO)
		{
			lseek(fdCustomer, 0, SEEK_SET);   //The customer file is empty?
			if(read(fdCustomer, &cus,sizeof(cus)) != 0)
			{
				lseek(fdCustomer, -sizeof(cus), SEEK_END);
				read(fdCustomer, &cus,sizeof(cus));
				cus.id++;
			}else
			{
				cus.id = 1;
			}
			
			ustrncpy(cus.mac, mac, 17);
			cus.auth_status = 0;
			cus.is_counted = 0;			
			write(fdCustomer, &cus, sizeof(cus));
			
		}

        if(cus_match == 0 || cus.auth_status == 0)
		{
            char sn[5];
			memset(sn, 0, sizeof(sn));
			idtocheckcode(cus.id, sn);

			printf("Content-type: text/html\r\n\r\n");
			file_print_arg(WELCOME,"#id#",sn);
		}
		free(ip);
        free(mac);
		close(fdCustomer);
		close(fdVist);	

	}
	return 0;
}
