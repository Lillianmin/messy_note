#include<fcgi_stdio.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include "commom.h"
#define MODIFY_PASSWD_OK CGI_HTML_DIR"modify_passwd_ok.html"
#define OLD_PASSWD_ERR CGI_HTML_DIR"old_passwd_err.html"

int main()
{
	while(FCGI_Accept() >= 0)
	{

		int fd;
		struct account_pwd p1,p2;
		fd = open(PASSWD, O_RDWR, 0666);

		if(fd < 0)
		{
		    file_print(ERROR_FILE);
		    continue;
		}
		 
		char *strlen = getenv("CONTENT_LENGTH");

		if(strlen == NULL)
		{
		    file_print(ERROR_FILE);
		    continue;
		}
		
		int len = atoi(strlen);
		char *str = (char *)malloc(len + 1);
		char *pwd_old = (char *)malloc(len);
		char *pwd_new = (char *)malloc(len);
		char *pwd_new1 = (char *)malloc(len);

		if(str == NULL || pwd_old == NULL || pwd_new == NULL || pwd_new1 == NULL)
		{
		    free(str);
		    free(pwd_old);
		    free(pwd_new);
		    free(pwd_new1);
		    file_print(ERROR_FILE);
		    continue;
		}
		
		fgets(str, len + 1, stdin);
		int count = sscanf(str,"xx=%[^&]&yy=%[^&]&zz=%s", pwd_old, pwd_new, pwd_new1);

		if(count != 3)
		{
		    file_print(ERROR_FILE);
		    continue;
		}
		    
		memset(&p1, 0, sizeof(p1));
		if(read(fd, &p1, sizeof(p1)) != sizeof(p1))
		{
		    file_print(ERROR_FILE);
		    continue;
		}

		if(strcmp(p1.pwd, pwd_old) == 0)
		{
		    strcpy(p1.pwd, pwd_new);
		    lseek(fd, 0, SEEK_SET);
		    memset(&p2, 0, sizeof(p2));
		    write(fd, &p2, sizeof(p2));
		    lseek(fd, 0, SEEK_SET);
		    write(fd, &p1, sizeof(p1));

		    printf("Content-type: text/html;charset=utf-8\r\n\r\n");
		    file_print(MODIFY_PASSWD_OK);
		}else
		{
		    printf("Content-type: text/html;charset=utf-8\r\n\r\n");
		    file_print(OLD_PASSWD_ERR);
		}
		
		free(str);
		free(pwd_old);
		free(pwd_new);
		free(pwd_new1);
		close(fd);
	}
}
