#define CUSTOMER_FILE "/media/mmcblk0p1/customer"

struct customer
{
        int id;
        unsigned char mac[6];
        int auth_status;
	int is_record;
};

int main()
{
    struct customer cus;
    int fd = open(CUSTOMER_FILE, O_RDONLY);
    while(read(fd, &cus, sizeof(cus)) == sizeof(cus))
    {
	printf("id is %d, mac is %s\n auth_status is %d, is record is %d\n", cus.id, cus.mac, cus.auth_status, cus.is_record);
    }
}
