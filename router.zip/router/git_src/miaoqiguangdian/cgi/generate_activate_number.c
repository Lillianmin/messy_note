#include "generate_activate_number.h"

int main(int argc, char **argv) 
{
        if(argc != 2){
                printf("Usage:%s key\n", argv[0]);
                return -1;
        }
        char *key = argv[1];
        char *hex  = act_code(key);
        printf("key:%s activate code:%s  ok\n", key, hex);
        free(hex);
        return 0;
}
