#include <fcgi_stdio.h>
#include <stdlib.h>
#include <stdio.h> 
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include "commom.h"

int main()
{
	while(FCGI_Accept() >= 0)
	{
        struct access_statistics r;
		int fd = open(VISIT_RECORD, O_RDONLY, 0666);

		if(fd < 0)
		{
		    file_print(ERROR_FILE);
		    continue;
		}
		lseek(fd, 0, SEEK_SET);
		
		printf("Content-type: text/html\r\n\r\n");
		printf("<html>"
			"<head>"
			"<meta charset=\"utf-8\"/>"
			"<title>访问记录</title>"
			"</head>"
			"<body align=\"center\">"
			"<table align=\"center\" width=\"770\" border=\"3\">"
			"<caption><font size=\"5\">月度访问汇总</font></caption>"
			"<tr>"
			"<th>年&nbsp;月</th>"
			"<th>访问数</th>"
			"</tr>"
		);

		while(read(fd, &r, sizeof(r)) == sizeof(r))
		{
			printf("<tr>"
			"<th>&nbsp;%s</th>"
			"<th>&nbsp;%d</td>"
			"</tr>", r.date, r.count);
		}
		
		printf("</table>"
		"<a href=\"http://www.admin.com:8002/visit_record.tar\">下载访问记录</a>"
		"</body>"
		"</html>");
		close(fd);
	}
	
	return 0;
}
