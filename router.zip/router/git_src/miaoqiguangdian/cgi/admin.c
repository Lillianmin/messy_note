#include<fcgi_stdio.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<string.h>
#include"global.h"
#include"md5.h"
#include "commom.h"
#define ADMIN_AUTH CGI_HTML_DIR"admin_auth.html"
#define ADMIN_PASSWD_ERR CGI_HTML_DIR"admin_passwd_err.html"

void md5fun(const char *src, char *dest)
{
   	char *d = dest;
	unsigned char digest[16] = {0};
	unsigned int len = strlen(src);
	MD5_CTX context;
	MD5Init(&context);
	MD5Update(&context, (unsigned char *)src, len);
	MD5Final(digest, &context);
	int i = 0;
	for(i = 0; i < 16; i++)
	{	sprintf(d,"%02x", digest[i]);
		d += 2;
	}
}
int main()
{
	int fd, count = 0;
	char *s1, *s2,passwd[33]={0};
    struct account_pwd p1;

	while(FCGI_Accept() >= 0)
	{					
		fd = open(PASSWD, O_RDONLY, 0666);

		memset(p1.account, 0, sizeof(p1.account));
		memset(p1.pwd, 0, sizeof(p1.pwd));

	    	//get account and passwd from client
		char *strlen = getenv("CONTENT_LENGTH");

		if(fd < 0 || strlen == NULL)
		{
		    file_print(ERROR_FILE);
		    continue;
		}

		int len = atoi(strlen);
		if(len == 0)
		{
		    file_print(ERROR_FILE);
		    continue;

		}
		//notice that the QUERY_STRING's length is not sure
		char *str = (char *)malloc(len + 1);
		s1 = (char *)malloc(len);
		s2 = (char *)malloc(len);

		if( str == NULL || s1 == NULL || s2 == NULL)
		{
		    free(str);
		    free(s1);
		    free(s2);
		    file_print(ERROR_FILE);
		    continue;
		}

		fgets(str, len + 1, stdin);
	  	int scount = sscanf(str, "xm=%[^&]&mm=%s", s1, s2);			
		if(scount != 2)
		{
		    free(str);
		    free(s1);
		    free(s2);
		    file_print(ERROR_FILE);
		    continue;
		}

		lseek(fd, 0, SEEK_SET);
		if(read(fd, &p1, sizeof(p1)) != sizeof(p1))
		{
		    file_print(ERROR_FILE);
		    continue;
		}

		md5fun(p1.pwd, passwd);

		if(strcmp(p1.account, s1) == 0 && strcmp(passwd, s2) == 0)
		{
			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			file_print(ADMIN_AUTH);	
		}else
		{
			  printf("Content-type:text/html\r\n\r\n");
			  file_print(ADMIN_PASSWD_ERR);		
		}
		free(str);		
		free(s1);
		free(s2);	
		close(fd);

	}
}
