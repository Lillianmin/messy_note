#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PRE_DIR "/tmp/run/mountd/sda1/nginx/portal/"

#define CGI_HTML_DIR PRE_DIR"cgi_html_dir/"
#define ERROR_FILE CGI_HTML_DIR"error.html"

#define CONFIG_DIR PRE_DIR"config/"
#define CUSTOMER_FILE CONFIG_DIR"customer"
#define UDHCP_FILE CONFIG_DIR"dhcp.leases"
#define VISIT_RECORD CONFIG_DIR"visit_record.txt"
#define ACTIVATOR_FILE CONFIG_DIR"activator"
#define PASSWD CONFIG_DIR"passwd"

extern char **environ;

#define BUF_SIZE 32 * 1024

static void PrintEnv(char *label, char **envp)
{
    printf("%s:<br>\n<pre>\n", label);
    for ( ; *envp != NULL; envp++) {
        printf("%s\n", *envp);
    }
    printf("</pre><p>\n");
}



struct account_pwd
{
	char account[10];
	char pwd[10];
};

struct access_statistics
{
	char date[8]; 
	int count;
};

struct customer
{
    int id;
    unsigned char mac[18];
    int auth_status;
    int is_counted;
};

int ustrncmp(unsigned char *str1, unsigned char *str2, int n)
{
        int i;
        for(i = 0; i < n; i++)
        {
                if(str1[i] != str2[i])
                        return 1;
        }

        return 0;
}

void ustrncpy(unsigned char *p1, unsigned char  *p2, int n)
{
        memset(p1, 0, sizeof(p1));
        int i;
        for(i = 0; i < n; i++)
        {
                p1[i] = p2[i];
        }
}
/*
int replace_str(char *src_str, char *match_str, char *replace_str)
{
        int  string_len;
	char new_string[MAX_MSG_LENGTH];

        char *find_pos = strstr(src_str, match_str);
        if( (!find_pos) || (!match_str) )
                return -1;

        while( find_pos )
        {
                memset(new_string, 0, sizeof(new_string));
                string_len = find_pos - src_str;
                strncpy(new_string, src_str, string_len);
                strcat(new_string, replace_str);
                strcat(new_string, find_pos + strlen(match_str));
		
//		realloc(strlen(new_string));
                strcpy(src_str, new_string);

                find_pos = strstr(src_str, match_str);
        }

        return 0;
}
*/
/*
char* file_read(const char* file_path){
        char *pchBuf = NULL;
        int  nLen = 0;
        FILE *pF  = fopen(file_path, "r"); 
	while (!feof(*pF)) {
        	nLen = fread(pchBuf, sizeof(char), nLen, pF);
	}

        fclose(pF);  
	return pchBuf;

}
*/

int file_print(const char* file_path)
{
	char buf[BUF_SIZE];
        int  nLen = 0;
        FILE *pF  = fopen(file_path, "r"); 
	if (pF == NULL) {
		printf("%s not found\n", file_path);
		return -1;
	}
	while (!feof(pF)) {
		memset(buf, 0, BUF_SIZE);
        	nLen = fread(buf, BUF_SIZE, 1, pF);
		if (nLen >= 0) {
			printf("%s", buf);
		} else {
			//TODO  notify;		
		}
	}

        fclose(pF);  
	return 0;
}

void print_replace_tag(const char *src, const char *tag, const char *value)
{
	char buf[BUF_SIZE];
	char *idx = strstr(src, tag);
	if (idx == NULL)
		return;
	int pos = (idx - src);
	int len = strlen(tag);
	memset(buf, 0, BUF_SIZE);
	memcpy(buf, src, pos);
	printf("%s", buf);
	printf("%s", value);
	printf("%s", (idx + len));
}

int file_print_arg(const char* file_path, char* tag, char* value){
	char buf[BUF_SIZE];
	if(file_path == NULL || tag==NULL || value==NULL) {
		perror("params null");
		return -1;
	}

	int  nLen = 0;
        FILE *pF  = fopen(file_path, "r"); 
	if (pF == NULL) {
		printf("%s not found\n", file_path);
		return -1;
	}
	while (!feof(pF)) {
		memset(buf, 0, BUF_SIZE);
        	fgets(buf, BUF_SIZE, pF);
		if (strstr(buf, tag) != NULL) {
			print_replace_tag(buf, tag, value);
		} else {
			printf("%s", buf);
		}
	}

        fclose(pF);  
	return 0;
}


#endif
