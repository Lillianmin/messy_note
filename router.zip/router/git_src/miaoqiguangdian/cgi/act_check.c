#include <fcgi_stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include "commom.h"
#include "global.h"
#include "md5.h"
#define ACTIVATOR CGI_HTML_DIR"activator.html"
#define ADMIN CGI_HTML_DIR"admin.html"
#define BUFFER_SIZE 64
void md5fun(const char *src, char *dest)
{
	char *d = dest;
	unsigned char digest[16] = {0};
	unsigned int len = strlen(src);
	MD5_CTX context;
	MD5Init(&context);
	MD5Update(&context, (unsigned char *)src, len);
	MD5Final(digest, &context);
	int i = 0;
	for(i = 0; i < 16; i++)
	{	sprintf(d,"%02x", digest[i]);
		d += 2;
	}
}
int main(){
	long valid_time =31*24*60*60;
	while(FCGI_Accept()>=0){
	    int fd;
	    fd = open(ACTIVATOR_FILE, O_RDONLY, 666);
	    long act_time = 0;
	    if(fd<0){
		file_print(ERROR_FILE);
		}else{
		read(fd, &act_time, sizeof(act_time));
		close(fd);
	    }
		char *qs = getenv("QUERY_STRING");
		char *ip = getenv("REMOTE_ADDR");//TODO get mac
		if( qs == NULL || ip == NULL)
		   {
		        file_print(ERROR_FILE);
			continue;
		   }
		long time;
		int count = sscanf(qs,"%ld",&time);

		char * buf;
		buf = (char*) malloc(strlen(qs)+strlen(ip)+1);
		
		if( count != 1 || buf == NULL)
		{
		    file_print(ERROR_FILE);
		    free(buf);
		    continue;
		}

		strcpy(buf,qs);
		strcat(buf,ip);

		char md5[BUFFER_SIZE]={0};

		
		md5fun(buf, md5);
		char mac_code[BUFFER_SIZE]={0};
		int i = 0;
		int len = strlen(md5)/8;
	
		for(i = 0; i < len; i++){
			mac_code[i]=md5[i*8];
		}
		
		mac_code[(len-1)*8+1]='\0';

                printf("Content-type: text/html\r\n\r\n");
		if((time-act_time)>valid_time){
			file_print_arg(ACTIVATOR, "MACHINE CODE", mac_code);
		}else{
			file_print(ADMIN);

		}
	}

	return 0;
}
