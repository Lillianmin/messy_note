#include "commom.h"

int main(){
	const char* filename= "/media/mll/debian_data/RouterDev/git_src/miaoqiguangdian/html/admin/index.html";
	file_print(filename);
	file_print_arg(filename, "html", "Login");
}
