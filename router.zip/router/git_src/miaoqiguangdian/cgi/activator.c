#include <fcgi_stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include "generate_activate_number.h"
#include "commom.h"
#define ADMIN CGI_HTML_DIR"admin.html"
#define ACT_ERR CGI_HTML_DIR"act_err.html"

int write_time(long time){

        int fd;
        fd = open(ACTIVATOR_FILE, O_RDWR|O_CREAT, 0666);
        if(fd<0){
                perror("open file error");
                return;
        }
        write(fd,&time,sizeof(time));
	time = 0;
        lseek(fd, 0, SEEK_SET);
        read(fd, &time, sizeof(time));
        close(fd);
}
int main(){
	while(FCGI_Accept()>=0){

		char *mc;
		char *ac;
		long time;
		char* qs = getenv("QUERY_STRING");
		if(qs == NULL)
		{
		    file_print(ERROR_FILE);
		    continue;
		}
		int len = strlen(qs);
		mc = (char*)malloc(len);
		ac = (char*)malloc(len);
		if(mc == NULL || ac == NULL)
		{
		    free(mc);
		    free(ac);
		    file_print(ERROR_FILE);
		    continue;
		}
                int count = sscanf(qs, "mc=%[^&]&ac=%[^&]&t=%ld", mc, ac, &time);
		if(count != 3)
		{
		    file_print(ERROR_FILE);
		    free(mc);
		    free(ac);
		    continue;
		}
		long ltime;

		char* acl_ac = act_code(mc);
		if(strcmp(acl_ac, ac)==0){
		printf( "Content-Type: text/html\r\n\r\n" );
			file_print(ADMIN);
			write_time(time);	
		}else{
		printf( "Content-Type: text/html\r\n\r\n" );
			file_print(ACT_ERR);
			}
		free(acl_ac);
		free(mc);
		free(ac);
	}
	return 0;
}
