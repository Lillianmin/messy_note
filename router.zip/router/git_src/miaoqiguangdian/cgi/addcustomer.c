#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include "commom.h"

int main()
{
	struct customer cus;
	unsigned char mac[6]="cdsklf";
	int fd;
	fd = open(CUSTOMER_FILE, O_RDWR|O_CREAT, 0666);
	if(fd<0){
		perror("open file error");
		return;
	}
	cus.id=1;
	ustrncmp(cus.mac, mac, 6);
	cus.auth_status=0;
	write(fd,&cus,sizeof(cus));
	memset(&cus, 0, sizeof(cus));
	lseek(fd, 0, SEEK_SET);
	read(fd, &cus, sizeof(cus));
	close(fd);
	printf("id is  %d, auth_status %d, mac %s\n", cus.id, cus.auth_status, cus.mac);
}
