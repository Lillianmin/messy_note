#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<arpa/inet.h>
#define UDHCP_FILE "/home/zcc/download/udhcpd.leases"
struct dhcpOfferedAddr{
		unsigned char hostname[16];
		unsigned char mac[16];
		unsigned long ip;
		unsigned long expires;
}lease;

int main()
{
    int fdDhcp = open(UDHCP_FILE, O_RDONLY);
    char *str_ip = getenv("REMOTE_ADDR");
    unsigned long ip;
    inet_pton(AF_INET, str_ip, &ip);
    while(read(fdDhcp, &lease, sizeof(lease)) == sizeof(lease))
    {
	if(ip == lease.ip)
	{
	    int i;
	    printf("host name is %s,mac is ", lease.hostname);
	    for(i = 0; i < 6; i++)
	    {
		printf("%02X\n",lease.mac[i]);
		break;
	    }
	}
    }
}

