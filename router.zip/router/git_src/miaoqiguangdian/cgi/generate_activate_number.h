#include <string.h>
#include <stdio.h>

#include <stdlib.h>

//#define BUF_SIZE 512
static const char *serialNumber = "zeleisoft";
static void encodeHex(const char *data, int len, char *out);
static void decrypt(const char *key, char *decrypt_buf, int len);


static const char DIGITS[] = 
{
	'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
	'a', 'b', 'c', 'd', 'e', 'f'
};

//The out char size max be (len * 2);
static void encodeHex(const char *data, int len, char *out) 
{
	int i = 0;
	int j = 0;
	for (; i < len; i++) {
		out[j++] = DIGITS[(240 & data[i]) >> 4];
		out[j++] = DIGITS[15 & data[i]];
	}
}

static void decrypt(const char *key, char *decrypt_buf, int len) 
{
	int sn_len = strlen(serialNumber);
	int i, j;
	for (i=0; i<len; ++i) {
		decrypt_buf[i] = (key[i] * 4) & 0xff; 

		for (j=0; j<sn_len; ++j) {
			decrypt_buf[i]  ^= serialNumber[j]; 
		}
	}
}

char*  act_code(char * mac_code){
	int key_len;
	char *decrypt_buf;
	char *key;
	char *hex;
	
	key = mac_code;
	key_len = strlen(key);	
	decrypt_buf = (char *)malloc(key_len);
	hex = (char *)malloc(key_len * 2);

	decrypt(key, decrypt_buf, key_len);
	encodeHex(decrypt_buf, key_len, hex);

	//TODO substring the half value;
	memmove(hex, hex + key_len, key_len);
	memset(hex + key_len, 0, key_len);
	free(decrypt_buf);
	return hex;

}
/*
int main(int argc, char **argv) 
{
	if(argc != 2){
		printf("Usage:%s key\n", argv[0]);
		return -1;
	}
	char *key = argv[1];
	char *hex  = act_code(key);
	printf("key:%s activate code:%s  ok\n", key, hex);
	free(hex);
	return 0;
}*/

