#!/bin/sh
#spawn-fcgi -a 127.0.0.1 -p 7000 -f /home/mll/data/RouterDev/git_src/webepubreader/cgi/test_print.cgi
#spawn-fcgi -a 127.0.0.1 -p 7000 -f /home/mll/data/RouterDev/git_src/webepubreader/cgi/reader.cgi
spawn-fcgi -a 127.0.0.1 -p 7000 -f /usr/share/nginx/webepubreader/cgi/reader.cgi

