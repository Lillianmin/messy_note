#include "file_print.h"

int main(){
const char* file ="../html/index.html";
file_print(file);
file_print_arg(file, "YOUR_URL", "http://192.168.4.115/epub/The Adventures of Sherlock Holmes - Arthur Conan Doyle.epub");
}

