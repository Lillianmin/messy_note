#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUF_SIZE 32 * 1024

int file_print(const char* file_path)
{
        char buf[BUF_SIZE];
        int  nLen = 0;
        FILE *pF  = fopen(file_path, "r");
        if (pF == NULL) {
                printf("%s not found\n", file_path);
                return -1;
        }
        while (!feof(pF)) {
                memset(buf, 0, BUF_SIZE);
                nLen = fread(buf, BUF_SIZE, 1, pF);
                if (nLen >= 0) {
                        printf("%s", buf);
                } else {
                        //TODO  notify;         
                }
        }

        fclose(pF);
        return 0;
}

void print_replace_tag(const char *src, const char *tag, const char *value)
{
        char buf[BUF_SIZE];
        char *idx = strstr(src, tag);
        if (idx == NULL)
                return;
        int pos = (idx - src);
        int len = strlen(tag);
        memset(buf, 0, BUF_SIZE);
        memcpy(buf, src, pos);
        printf("%s", buf);
        printf("%s", value);
        printf("%s", (idx + len));
}

int file_print_arg(const char* file_path, char* tag, char* value){
        char buf[BUF_SIZE];
        if(file_path == NULL || tag==NULL || value==NULL) {
                perror("params null");
                return -1;
        }

        int  nLen = 0;
        FILE *pF  = fopen(file_path, "r");
        if (pF == NULL) {
                printf("%s not found\n", file_path);
                return -1;
        }
        while (!feof(pF)) {
                memset(buf, 0, BUF_SIZE);
                fgets(buf, BUF_SIZE, pF);
                if (strstr(buf, tag) != NULL) {
                        print_replace_tag(buf, tag, value);
                } else {
                        printf("%s", buf);
                }
        }

        fclose(pF);
        return 0;
}

