#include "fcgi_stdio.h"
#include "file_print.h"
#define ERROR_FILE "error.html"
int main(){
	while(FCGI_Accept() >= 0)
	{
		
//		printf("Content-type: text/html;charset=utf-8\r\n\r\n");
//		printf("hello");
//		continue;
/*	
		if (getenv("CONTENT_LENGTH")) {
			int n=atoi(getenv("CONTENT_LENGTH")); 	

			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			printf("n %d", n);
			continue;
		}else{
		
			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			printf("getenv CONTENT-LENGTH false");
			continue;
		}
*/
		char *url;
		char* qs = getenv("QUERY_STRING");

		if(qs == NULL)
		{
			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			printf("query null");
			continue;
		}
		int len = strlen(qs);
		url = (char*)malloc(len);
		if(url==NULL){
			free(url);
			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			printf("url null");
//			file_print(ERROR_FILE);
			continue;
		}

		int count = sscanf(qs, "url=%[^&]", url);//TODO handle special char like ' ' and so on
		if(count != 1){
			free(url);
			printf("Content-type: text/html;charset=utf-8\r\n\r\n");
			printf("count not right");
//			file_print(ERROR_FILE);
			continue;
		}

		printf("Content-type: text/html;charset=utf-8\r\n\r\n");
		//printf(url);
		const char* file ="index.html";
		file_print_arg(file, "YOUR_URL", url);
		free(url);

	}
	return 0;
}
