#!/bin/sh
umount /dev/sdd1
mkfs.ext4 /dev/sdd1
mount -t ext4 /dev/sdd1 /media/mll/mkdata/
cp /media/mll/debian_data/RouterDev/git_src/wxebookstudio/data/* -r /media/mll/mkdata/
ls /media/mll/mkdata/
sleep 1;
umount /media/mll/mkdata/
