#!/bin/sh
curl -i -H mac:0C:54:A5:16:4D:3E --data-binary @/var/log/nginx/access.log.1 http://218.22.25.181/logreceive.aspx
curl -i -H mac:0C:54:A5:16:4D:3E --data-binary @/var/log/nginx/access.log http://218.22.25.181/logreceive.aspx
