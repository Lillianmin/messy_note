#!/bin/sh
DEVICE=./getdevinfo.sh;

if [ $DEVICE="9344" ]; then
	echo "";
else
	USB_ROOT="/media/mmcblk0p1";
	export PATH=$USB_ROOT/bin:$PATH;
fi

cat_services(){
NTP_TCP="ntp.*123/tcp"
NTP_UDP="ntp.*123/udp"
#SERVICES="./services";
SERVICES="/etc/services";
hastcp=0;
hasudp=0;

if [ -f $SERVICES ]; then
	echo $SERVICES exists
else
	echo touch $SERVICES
	touch $SERVICES
fi

while read line; do
	echo $line
	tcp=`echo $line | grep $NTP_TCP`
	udp=`echo $line | grep $NTP_UDP`
	echo $hastcp
	echo $hasudp
	if [ XXX"$tcp" != XXX ]; then
		hastcp=1;
	fi
	if [ XXX"$udp" != XXX ]; then
		hasudp=1;
	fi
	if [ $hastcp = 1 -a $hasudp = 1 ]; then
		break;
	fi
done < $SERVICES

if [ $hastcp != 1 ]; then
	echo "ntp             123/tcp" >> $SERVICES;
fi
if [ $hasudp != 1 ]; then
	echo "ntp             123/udp" >> $SERVICES;
fi
}

if [ $DEVICE="9344" ]; then
        echo "";
else
	cat_services;
fi

TZ='Asia/Shanghai'; 
export TZ;
ntpdate pool.ntp.org

