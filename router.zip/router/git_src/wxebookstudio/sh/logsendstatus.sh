#!/bin/sh                                                                       
FOUND=""
FLAG="result-code:"                                                                          
while read -r line; do                                                         
    flag=`echo $line | cut -f 1 -d ' '`                          
    if [ "XXX$flag" = "XXX$FLAG" ]; then                              
	stat=`echo $line | cut -f 2 -d ' '`  
	FOUND="99"     
	break                                                           
    fi                                                              

done

if [ "xxx$FOUND" = "xxx" ]; then
    echo "$FOUND";
else
    echo "$stat";
fi
