#!/bin/sh


DEVICE=./getdevinfo.sh;
if [ $DEVICE="9344" ]; then
        USB_ROOT="/tmp/mounts/Disc-A1";
        SH_ROOT="/etc/config";
        BR_NAME="br-lan";
	WLAN_NAME="wlan0"
        export PATH=$SH_ROOT/sh:$PATH;
else
        USB_ROOT="/media/mmcblk0p1";
        BR_NAME="br0";
        export PATH=$USB_ROOT/sh:$PATH;
fi

if [ "$1" = DEBUG ]; then
	WORK_DIR="/user/wx"
	echo $1
else
	PS=`ps`
	HASNGINX=`echo $PS | grep nginx`
	if [ "XXX$HASNGINX" = "XXX" ]; then
		if [ $DEVICE="9344" ]; then
			echo mount -o remount,rw /dev/sda1 /tmp/run/mountd/sda1
			mount -o remount,rw /dev/sda1 /tmp/run/mountd/sda1
			/etc/init.d/nginx start
		else
			echo mount -o remount,rw /dev/mmcblk0p1 /media/mmcblk0p1
			mount -o remount,rw /dev/mmcblk0p1 /media/mmcblk0p1
			/bin/runnginx.sh
		fi
		exit
	else
		echo $PS has nginx
	fi
	if [ $DEVICE="9344" ]; then
		WORK_DIR="/tmp/mounts/Disc-A1";
	else
		WORK_DIR="/media/mmcblk0p1"
	fi
fi

DEST="/tmp/rsync_resources.xml"
ORIG="$WORK_DIR/rsync_resources.xml"
RSYNC_LOG="$WORK_DIR/rsync.log"

NGINX_DIR="$WORK_DIR/nginx"
HTML_DIR="$NGINX_DIR"/html
HTML_WORK_DIR_1="$NGINX_DIR"/html_1
HTML_WORK_DIR_2="$NGINX_DIR"/html_2

LOCK="/tmp/rsync.lock"

if [ -d "$WORK_DIR" ]; then
	echo WORK_DIR: "$WORK_DIR"
else
	echo mkdir $WORK_DIR
	mkdir $WORK_DIR
fi


if [ -d "$NGINX_DIR" ]; then
	echo NGINX_DIR: "$NGINX_DIR"
else
	echo mkdir $NGINX_DIR
	mkdir $NGINX_DIR
fi

downloaded=0
id="12345"
rsync_haserror=0

download() {
	LOG="/tmp/rsync_wget_log"
	#SERVER="http://218.22.25.186:8082/resources.xml"
	#SERVER="http://218.22.25.187/resource.xml"
	#SERVER="http://218.22.25.181:8889/resource.aspx"
	SERVER="http://218.22.25.181/resource.aspx"
	#echo wget --header=\'id: "$id"\' $SERVER -O $DEST
	#wget --header=\'id: "$id"\' $SERVER -O $DEST &> $LOG
	echo wget $SERVER -O $DEST
	wget $SERVER -O $DEST 1> $LOG 2>$LOG

	#fail_log=`cat $LOG | grep fail`
	fail_log=`cat $LOG | grep "Network is unreachable"`
	error_log=`cat $LOG | grep "Not Found"`

	echo $fail_log $error_log
	downloaded=0

	if [ XXX"$fail_log" = XXX -a  XXX"$error_log" = XXX ]; then
		downloaded=1
	fi
	
	server_err_log=`cat $LOG | grep "500 Internal Server Error"`
	
	echo $server_err_log
	if [ XXX"$server_err_log" = XXX ]; then
		download=1
	fi
}

check_rsync_error() {
	log=`cat "$RSYNC_LOG"`
	haserror=`echo $log | grep "Connection reset by peer"`
	if [ XXX"$haserror" != XXX ]; then
		rsync_haserror=1
		return;	
	fi

	haserror=`echo $log | grep "connection unexpectedly closed"`
	if [ XXX"$haserror" != XXX ]; then
		rsync_haserror=1
		return;	
	fi

	#TODO add check the timeout
	haserror=`echo $log | grep "timeout in data"`
#	haserror=`echo $log | grep "rsync error:"`
	if [ XXX"$haserror" != XXX ]; then
		rsync_haserror=1
		return;	
	fi
	
	haserror=`echo $log | grep "Connection timed out"`
	if [ XXX"$haserror" != XXX ]; then
		rsync_haserror=1
		return;	
	fi

	haserror=`echo $log | grep "rsync error"`                      
        if [ XXX"$haserror" != XXX ]; then                                      
                rsync_haserror=1                                                
                return;                                                                      
        fi 

#	error=`echo $log | grep "rsync error"`;
#	errorcode=`echo $error | sed "s/.*(code \([0-9]*\)).*/\1/g"`;
#	if [ $errorcode != '23' ]; then
#		 echo "has error" $errorcode;
#		 rsync_hasserror=1
#		 return;
#	fi

}


sync() {
	if [ -f $LOCK ]; then
		echo  $LOCK exists, is rsync now!!!!!!!!!
		return;
	fi

	touch $LOCK
	OUT="/tmp/rsync_out_log"
	HTML_CURRENT_DIR=`readlink $HTML_DIR`
	#`ls -l $HTML_DIR | awk '{print $11}'`
	HTML_DOWNLOAD_DIR="$HTML_WORK_DIR_1"
	echo HTML_CURRENT_DIR: $HTML_CURRENT_DIR
	if [ "$HTML_CURRENT_DIR" = "$HTML_WORK_DIR_1" ]; then
		HTML_DOWNLOAD_DIR=$HTML_WORK_DIR_2;
	fi
	echo HTML_DOWNLOAD_DIR: $HTML_DOWNLOAD_DIR

	host=""
	dir=""

	while read line; do
		echo $line
		#<rsync_host url="218.22.25.186" root="resources"/>
		hashost=`echo $line | grep rsync_host`
		echo $hashost
		if [ XXX"$hashost" = XXX ]; then
			echo "";
		else
			host=`echo "$line" | sed "s/.*\"\(.*\)\".*\"\(.*\)\".*/\1/g"`
			dir=`echo "$line" | sed "s/.*\"\(.*\)\".*\"\(.*\)\".*/\2/g"`
			echo host: $host dir: $dir
			break
		fi
	done < $DEST
	if [ -f  "$RSYNC_LOG" ]; then
		echo rm -rf $RSYNC_LOG
		rm -rf $RSYNC_LOG
	fi
	
	#echo rsync -av --chown=admin:admin --size-only --debug=RECV --delete --log-file=$RSYNC_LOG $host::$dir $HTML_DOWNLOAD_DIR
	echo time rsync -av --no-owner --no-group --delete --timeout=300 --log-file=$RSYNC_LOG $host::$dir $HTML_DOWNLOAD_DIR >> $OUT 
	time rsync -av --no-owner --no-group --delete --timeout=300 --log-file=$RSYNC_LOG $host::$dir $HTML_DOWNLOAD_DIR >> $OUT 2>&1
	
	check_rsync_error

	echo "rsync_haserror: " $rsync_haserror >> $OUT
	echo `date` >> $OUT

	if [ "$rsync_haserror" = 1 ]; then
		echo `date` rm -rf $LOCK >> $OUT

		rm -rf $LOCK

		echo "rsync has error, you need  reload the rsync!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" >> $OUT
		return;
		#only use to test;
		if [ "$1" = DEBUG ]; then
			./rsyncchecker.sh DEBUG
			exit 0;
		fi
		#exit
	fi

	#echo killall -9 nginx
	#killall -9 nginx


  	echo chmod 0777 $HTML_DOWNLOAD_DIR -R >> $OUT 
  	chmod 0777 $HTML_DOWNLOAD_DIR -R 

	echo rm -rf $HTML_DIR >> $OUT
	rm -rf $HTML_DIR

	echo ln -s $HTML_DOWNLOAD_DIR $HTML_DIR >> $OUT
	ln -s $HTML_DOWNLOAD_DIR $HTML_DIR
	
	ifconfig | getmac.sh $WLAN_NAME > $HTML_DIR/mac.txt
	chmod 755 $HTML_DIR/mac.txt

	echo cp -a -f $DEST $ORIG >> $OUT
	cp -a -f $DEST $ORIG

	#runnginx.sh

	echo rm -rf $LOCK >> $OUT
	rm -rf $LOCK
	echo "end " `date` >> $OUT
}

check() {
	downloaded=0;
	download;
	echo "check downloaded:" $downloaded
	if [ "$downloaded" = 1 ]; then
		destmd5=`md5sum $DEST | sed "s/\(.*\) .*/\1/g"`
		origmd5=`md5sum $ORIG | sed "s/\(.*\) .*/\1/g"`
		echo $destmd5
		echo $origmd5
		#if [ ! -f "$DEST" -a ! -f "$ORIG" ]; then
		#	echo "$DEST" not exists and $ORIG not exists
		#	sync	
		#else
			if [ "$destmd5" != "$origmd5" ]; then
				sync
			fi
		#fi
	fi
}
if [ $DEVICE="9344" ]; then 
	check;
else
	while [ 1 ]; do
		check;	
		sleep 300
	done
fi

