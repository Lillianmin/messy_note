#!/bin/sh

while [ 1 ]; do

	$PWD/rsyncchecker.sh DEBUG
	sleep 60;

done
