#!/bin/sh

DEVICE=./getdevinfo.sh;
if [ $DEVICE="9344" ]; then
	USB_ROOT="/tmp/mounts/Disc-A1";
	SH_ROOT="/etc/config";
	BR_NAME="br-lan";
	WLAN_NAME="wlan0"
	export PATH=$SH_ROOT/sh:$PATH;
else
	USB_ROOT="/media/mmcblk0p1";
	BR_NAME="br0";
	export PATH=$USB_ROOT/sh:$PATH;
	sentlog.sh &
	heartrate.sh &
	rsyncchecker.sh &
fi

if [ -h $USB_ROOT/www ]; then
	echo "";
else
	echo ln -s $USB_ROOT/nginx/html $USB_ROOT/www;
	ln -s $USB_ROOT/nginx/html $USB_ROOT/www;
fi

if [ -f $SH_ROOT/sh/predhcp.txt ]; then
	echo rm SH_ROOT/sh/predhcp.txt;
	rm SH_ROOT/sh/predhcp.txt;
fi
#use for display mac_addr
ifconfig | getmac.sh $WLAN_NAME > $USB_ROOT/www/mac.txt
cat $USB_ROOT/www/mac.txt
chmod 755 $USB_ROOT/www/mac.txt

synctime.sh &

#Port Redirect
#ip_addr=`ifconfig | getipfinp.sh $BR_NAME`
#
#ips="218.22.25.179 218.22.25.180 218.22.25.181 218.22.25.182 218.22.25.183 218.22.25.184 218.22.25.185 218.22.25.186 218.22.25.187 60.12.225.245 124.202.164.195 23.42.191.65" 
#
#for i in $ips; do
#	echo /usr/sbin/iptables -t nat -I PREROUTING  -d "$i"  -j ACCEPT
#	/usr/sbin/iptables -t nat -I PREROUTING  -d "$i"  -j ACCEPT
#done
#
#echo /usr/sbin/iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $ip_addr:80
#/usr/sbin/iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $ip_addr:80
