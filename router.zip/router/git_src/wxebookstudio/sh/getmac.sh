#!/bin/sh

INF=$1
mac=""
while read -r line; do
	if [ "XXX$found" = "XXX" ]; then
		inf=`echo $line | cut -f 1 -d' '`
		if [ "XXX$inf" = "XXX$INF" ]; then
			mac=`echo $line | cut -f 5 -d ' '`
		break
		fi
	fi
done
echo $mac
