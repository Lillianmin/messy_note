#/bin/sh
DEVICE=./getdevinfo.sh;

if [ $DEVICE="9344" ]; then
    USB_ROOT="/tmp/mounts/Disc-A1";
    SH_ROOT="/etc/config";
    export PATH=$SH_ROOT/sh:$PATH;
    NGINX_PID="/var/run/nginx.pid";
    LOG_DIR="/var/log/nginx";
    BR_NAME="br-lan";
    WLAN_NAME="wlan0"
else
    USB_ROOT="/media/mmcblk0p1";
    export PATH=$USB_ROOT/bin:$PATH;
    NGINX_PID="/var/nginx/logs/nginx.pid";
    LOG_DIR="/var/nginx/logs";
    BR_NAME="br0";

fi
sendlog(){
    max=0
    LOG_FILE=$LOG_DIR/access.log;
    for i in `ls $LOG_FILE*`; 
	do 
	num=`echo $i | cut -f 3 -d '.'`;
	if [ $max -lt $num ];then
	    max=$num;
	fi
    done

    target=$(($max+1));
    if [ -f $LOG_FILE ];then
	mv $LOG_FILE $LOG_FILE.$target;
    fi

    kill -USR1 `cat $NGINX_PID`;

    mac_addr=`ifconfig | getmac.sh $WLAN_NAME`

    for f in `ls $LOG_FILE.*`;
	do
	echo curl  -i -H "mac:$mac_addr" --data-binary @$f http://218.22.25.181/logreceive.aspx;
	sendstatus=`curl  -i -H "mac:$mac_addr" --data-binary @$f http://218.22.25.181/logreceive.aspx | logsendstatus.sh`
	if [ $sendstatus="0" ]; then
	    echo "send log $f sucess";
	    rm $f 
	fi
    done
}

if [ $DEVICE="9344" ]; then
        sendlog;                     
else                                           
        while [ 1 ]; do
                sendlog;                     
                sleep 3600
        done
fi

