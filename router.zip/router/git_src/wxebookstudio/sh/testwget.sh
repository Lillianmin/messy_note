#!/bin/sh
wget --header="user-id: 2" --header="Actio\
n: getDesktopConfig" --header="Client-Agent: Android" --header="APIVersion: 1.0.\
0" http://218.22.25.179/obookapi.aspx
