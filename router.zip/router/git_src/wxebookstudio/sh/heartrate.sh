#!/bin/sh
DEVICE=./getdevinfo.sh;

if [ $DEVICE="9344" ]; then
	USB_ROOT="/tmp/mounts/Disc-A1";
	SH_ROOT="/etc/config";
	DEVICE_PATH="/dev/sda1";
	export PATH=$SH_ROOT/sh:$PATH;
	BR_NAME="br-lan";
	WLAN_NAME="wlan0"
else 
	USB_ROOT="/media/mmcblk0p1";
	export PATH=$USB_ROOT/bin:$PATH
	DEVICE_PATH="/dev/mmcblk0p1";
	BR_NAME="br0";
fi

sendheart(){
mac_addr=`ifconfig | getmac.sh $WLAN_NAME`
ip_addr=`ifconfig | getipfinp.sh $BR_NAME`
if [ -b $DEVICE_PATH ]; then
	sd_vol=`df | avVolume $DEVICE_PATH`;
else
	sd_vol="NOT MOUNTED";
fi
echo curl -i -H "mac:$mac_addr" -H "ip:$ip_addr" -H "sd:$sd_vol" -d "mac:$mac_addr,ip:$ip_addr,sd:$sd_vol" http://218.22.25.181/heartrate.aspx;
curl -i -H "mac:$mac_addr" -H "ip:$ip_addr" -H "sd:$sd_vol" -d "mac:$mac_addr,ip:$ip_addr,sd:$sd_vol" http://218.22.25.181/heartrate.aspx
}

if [ $DEVICE="9344" ]; then
        sendheart;
else
        while [ 1 ]; do    
                sendheart;
                sleep 60
        done           
fi   
