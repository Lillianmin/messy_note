#!/bin/sh
DEVICE=./getdevinfo.sh;
HASODHCP=$1;
if [ $DEVICE="9344" ]; then
        USB_ROOT="/tmp/mounts/Disc-A1";
        SH_ROOT="/etc/config";
        BR_NAME="br-lan";
        export PATH=$SH_ROOT/sh:$PATH;
else
        USB_ROOT="/media/mmcblk0p1";
        BR_NAME="br0";
        export PATH=$USB_ROOT/sh:$PATH;
fi

hasdhcp=0;

setup_dnsmasq(){
	killall -9 dnsmasq;
	DNS_CONF="/etc/dnsmasq.conf";
	if [ -f  $DNS_CONF ];then
		rm $DNS_CONF;
	else
		echo "";
	fi
		wifiip=`ifconfig | getipfinp.sh $BR_NAME`
		echo "address=/bookbox.gw/$wifiip" > $DNS_CONF;
	if [ $hasdhcp = 0 ]; then
		echo "address=/#/$wifiip" >> $DNS_CONF;
	else
		echo "address=/#/$wifiip" >> $DNS_CONF;
		echo "address=/wx.obook.com.cn/$wifiip" >> $DNS_CONF;
		echo "server=/obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/www.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/s.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/m.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/epub.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/bbs.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/q.obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/obook.com.cn/#" >> $DNS_CONF;
		#echo "server=/e.obok.com.cn/#" >> $DNS_CONF;
		#echo "server=/itunes.apple.com/#" >> $DNS_CONF;
		echo "server=/wx.obook.com.cn/$wifiip" >> $DNS_CONF;
		echo "server=/apple.com/#" >> $DNS_CONF;
		echo "server=/pool.ntp.org/#" >> $DNS_CONF;
	fi
		/etc/init.d/dnsmasq start;
}

prehasdhcp=0;
PS=`ps`
PROGRESS="odhcp6c";
PREDHCP_FILE=$SH_ROOT/sh/"predhcp.txt";
HASODHCP=`echo $PS | grep $PROGRESS`

if [ "XXX$HASODHCP" = "XXX" ]; then
	hasdhcp=0;
else
	hasdhcp=1;
fi
if [ -f $PREDHCP_FILE ];then
	while read line; do
		prehasdhcp=$line;
	done < $PREDHCP_FILE;
	
	echo "prehasdhcp "$prehasdhcp;
	echo "hasdhcp "$hasdhcp;
	
	if [ $prehasdhcp != $hasdhcp ]; then
		setup_dnsmasq;	
	fi
else
	setup_dnsmasq;
fi

echo $hasdhcp > $PREDHCP_FILE;

