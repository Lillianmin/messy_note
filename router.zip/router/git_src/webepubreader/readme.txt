在html下建立链接ln -s book jsbook
将cgi目录拷贝至硬盘，并建立链接ln -s /tmp/run/mountd/sda1/cgi /tmp/run/mountd/sda1/www/cgi

